<?php
$sitelogo = $site_common['site_settings']->site_logo;
$sitehome = $this->session->userdata('site_home');
$user_id=$this->session->userdata('user_id');
$sitelan = $this->session->userdata('site_lang');
$last_uri = end($this->uri->segment_array());
?>
<header class="header_wrap fixed-top nav-fixed">
            <div class="container-fluid  tophead">
              <nav class="navbar navbar-expand-lg">
                <a class="navbar-brand page-scroll animation" href="<?php echo base_url()?>"  data-animation="fadeInDown" data-animation-delay="1s">
                        <img class="logo_light" src="<?php echo $sitelogo;?>" alt="logo" style="width: 100px;height: 100px;" width="100px">
                          
                      </a>
                      <button class="navbar-toggler animation" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" data-animation="fadeInDown" data-animation-delay="1.1s">
                          <span><i class="fa fa-bars" aria-hidden="true"></i>
          </span>
                      </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                          <ul class="navbar-nav m-auto">
                              <li class="dropdown animation" data-animation="fadeInDown" data-animation-delay="1.1s">
                                <a  class="nav-link page-scroll nav_item" href="<?=base_url('home')?>">Home</a>
                            </li>

                              <li class="animation" data-animation="fadeInDown" data-animation-delay="1.2s"><a class="nav-link page-scroll nav_item" href="<?=base_url('cms/about-us')?>">About Us</a></li>
                             
                              <li class="dropdown animation" data-animation="fadeInDown" data-animation-delay="1.1s">
                                <a  class="nav-link page-scroll nav_item" href="<?=base_url('market')?>">MARKET</a>
                            </li>
                            


                              <li class="dropdown animation" data-animation="fadeInDown" data-animation-delay="1.1s">
                      <a data-toggle="dropdown" class="nav-link dropdown-toggle" href="#">EXCHANGE</a>
                        <div class="dropdown-menu">
                              <ul class="list_none">
                                             <li><a class="dropdown-item nav-link nav_item" href="<?=base_url()?>exchange">Basic</a></li>
                                   <li><a class="dropdown-item nav-link nav_item" href="<?=base_url()?>exchange/#/trade_advance">Advanced</a></li>
                                      </ul>
                                    </div>
                              </li>

                          </ul>
                          <ul class="navbar-nav nav_btn align-items-center">
                             
                                                   <?php
                                if(isset($user_id) && !empty($user_id)){
                                ?>
                    <li class="animation" data-animation="fadeInDown" data-animation-delay="1.4s"><a class="nav-link page-scroll nav_item" href="<?php echo base_url();?>dashboard">Dashboard</a></li>
                    <li class="animation" data-animation="fadeInDown" data-animation-delay="1.5s"><a class="nav-link page-scroll nav_item" href="<?php  echo base_url();?>logout">Logout </a></li>
                    <?php } else { ?>
                    <li class="animation" data-animation="fadeInDown" data-animation-delay="1.6s"><a class="btn btn-default btn-radius nav_item" href="<?php echo base_url();?>signup">Register</a></li>
                     <li class="animation" data-animation="fadeInDown" data-animation-delay="1.7s"><a class="btn btn-default btn-radius nav_item" href="<?php echo base_url();?>login">Login</a></li>
                    <?php } ?>
                                              </ul>

                </div>
              </nav>
            </div>
          </header>