<?php $slug = $this->uri->segment(1);  ?>
 <ul class="list-unstyled components">
    <li class="<?php echo ($slug=='dashboard')?'active':''?>"><a href="<?=base_url();?>dashboard"><i class="fa fa-window-maximize"></i> <?php echo $this->lang->line('Dashboard')?></a></li>
    <li><a href="<?=base_url();?>trade"><i class="fa fa-random"></i><?php echo $this->lang->line('Exchange')?></a></li>
    <li  class="<?php echo ($slug=='wallet')?'active':''?>"><a href="<?=base_url();?>wallet"><i class="fa fa-database"></i><?php echo $this->lang->line('Balances')?></a></li>
    <li class="<?php echo ($slug=='history')?'active':''?>"><a href="<?=base_url();?>history"><i class="fa fa-history"></i><?php echo $this->lang->line('History')?></a></li>
   
    <li class="<?php echo ($slug=='kyc')?'active':''?>"><a href="<?=base_url();?>kyc"><i class="fa fa-shield-alt"></i> <?php echo $this->lang->line('KYC Verification')?></a></li>

    <?php if($users->profile_status==0)
    { ?>
    	<li class="<?php echo ($slug=='transaction')?'active':''?>"><a id="profile_check" href="javascript:void(0)"><i class="fa fa-money-bill-wave"></i> <?php echo $this->lang->line('Transaction')?></a></li>
   <?php } 
   else if($users->kyc_status==0)
   {
   	 ?>
   	 	<li class="<?php echo ($slug=='transaction')?'active':''?>"><a id="kyc_check" href="javascript:void(0)"><i class="fa fa-money-bill-wave"></i> <?php echo $this->lang->line('Transaction')?></a></li>
   	 <?php 
   }
   else
   {
   	?>
   
    <li class="<?php echo ($slug=='transaction')?'active':''?>"><a href="<?=base_url();?>transaction"><i class="fa fa-money-bill-wave"></i> <?php echo $this->lang->line('Transaction')?></a></li>
<?php } ?>

    <li class="<?php echo ($slug=='support' || $slug=='support_reply')?'active':''?>"><a href="<?=base_url();?>support"><i class="fa fa-headphones"></i> <?php echo $this->lang->line('Support')?></a></li>
    <li><a href="./login.html"><i class="fa fa-sign-out-alt"></i> <?php echo $this->lang->line('Logout')?></a></li>
</ul>