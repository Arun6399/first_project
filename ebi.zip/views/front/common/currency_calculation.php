<?php $this->load->view('front/common/inner_header');?>

<div class="coin-exchang-area short-spacing section" id="coin-exchange">
<div class="container">
<div class="coin-exchange-wrapper">
<div class="sec-title text-center mb-lg-0">
<h1 data-watermark=""><span><?php echo $this->lang->line('Coin')?></span> <?php echo $this->lang->line('Exchange')?></h1>
</div>


<div class="exchange-wrap">
<div class="exchange-currency">
<div class="exchange-currency-left">
<label><?php echo $this->lang->line('Crypto Digital')?></label>
<div class="exchange-box">
<div class="currency">
<input type="number" id="amount-one" placeholder="0" value="1"/>
<select class="select-country select" id="currency-one">
<?php if(isset($digital_currency_1) && !empty($digital_currency_1)){ foreach($digital_currency_1 as $digital_cur1){?>
<option value="<?=$digital_cur1->currency_symbol?>"><?=$digital_cur1->currency_symbol?></option>
<?php } }?>
</select>
</div>
</div>
</div>
<div class="exchange-currency-middle">
<div class="swap-rate-container">
<button class="btn" id="swap">
<img src="<?php echo front_img()?>home_two/short-code-img/icon/exchange.svg" alt="exchange">
</button>
</div>
</div>
<div class="exchange-currency-right">
<label><?php echo $this->lang->line('Crypto')?></label>
<div class="exchange-box">
<div class="currency">
<input type="number" id="amount-two" placeholder="0"/>
<select class="select-country select" id="currency-two" >
<?php if(isset($digital_currency_2) && !empty($digital_currency_2)){ foreach($digital_currency_2 as $digital_cur2){?>
<option value="<?=$digital_cur2->currency_symbol?>"><?=$digital_cur2->currency_symbol?></option>
<?php } }?>
</select>
</div>
</div>
</div>
</div>
<div class="change-button">
<div class="rate" id="rate"></div>
<button class="r-button r-promary semi-rounded" id="exchange"><?php echo $this->lang->line('Exchange Currency')?></button>
</div>
</div>

</div>
</div>
</div>
 <?php $this->load->view('front/common/inner_footer');?>       