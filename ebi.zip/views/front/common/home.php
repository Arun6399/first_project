<link rel="stylesheet" type="text/css" href="<?php echo front_css();?>style_trade.css" />

<?php $this->load->view('front/common/header');
$lang_id = $this->session->userdata('site_lang');
$user_id = $this->session->userdata('user_id');
// $content = $sitelan."_content";
// echo 'lang '.$sitelan;
// echo $home_section->$sitelan.'_content';
if($lang_id!=''){
$title = $lang_id.'_name';
$content = $lang_id.'_content';
$question = $lang_id.'_question';
$description = $lang_id.'_description';
}else{
$title = $site_lang.'_name';
$content = $site_lang.'_content';
$question = $site_lang.'_question';
$description = $site_lang.'_description';
}
?>
<?php
$user_id = $this->session->userdata('user_id');
$all_currency = $this->common_model->getTableData("currency",array("status"=>1))->result();
if(count($all_currency))
{
  $tot_balance = 0;
  foreach($all_currency as $cur)
  {
      $balance = getBalance($user_id,$cur->id);
      $usd_balance = $balance * $cur->online_usdprice;

      $tot_balance += $usd_balance;
  }
}
$theme_mode = $_COOKIE['theme-mode'];
?>
    <!--welcome area start-->
    <div class="welcome-area wow fadeInUp" id="home">
        <div id="particles-js"></div>
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-12 align-self-center header_banner">
                    <div class="welcome-right">
                        <div class="welcome-text">
                             <h1>The Leading Cryptocurrency Trading Platform</h1>
                            <h4>Xabits Invest for Future</h4>
                        </div>
                        <div class="welcome-btn">
                            <a href="#" class="gradient-btn v2 mr-20"> Join Now
                            </a>

                        </div>
                    </div>
                </div>
              
            </div>
        </div>
    </div>
    <!--welcome area end-->
   

    <!--about area start-->
    <div class="about-area wow fadeInUp" id="about">
        <div class="space-30"></div>
        <div class="container">

            <div class="row">
                <div class="col-lg-12">
                    <div class="logo-carousel owl-carousel text-center">
                        <div class="single-logo-wrapper">
                            <div class="single-item">
                                <img src="<?php echo front_img();?>oof1.jpg" alt="">
                            </div>
                        </div>
                        <div class="single-logo-wrapper">
                            <div class="single-item">
                                <img src="<?php echo front_img();?>oof2.jpg" alt="">
                            </div>
                        </div>
                        <div class="single-logo-wrapper">
                            <div class="single-item">
                                <img src="<?php echo front_img();?>oof3.jpg" alt="">
                            </div>
                        </div>
                        <div class="single-logo-wrapper">
                            <div class="single-item">
                                <img src="<?php echo front_img();?>oof4.jpg" alt="">
                            </div>
                        </div>
                        <div class="single-logo-wrapper">
                            <div class="single-item">
                                <img src="<?php echo front_img();?>oof5.jpg" alt="">
                            </div>
                        </div>
                        <div class="single-logo-wrapper">
                            <div class="single-item">
                                <img src="<?php echo front_img();?>oof1.jpg" alt="">
                            </div>
                        </div>
                        <div class="single-logo-wrapper">
                            <div class="single-item">
                                <img src="<?php echo front_img();?>oof2.jpg" alt="">
                            </div>
                        </div>
                        <div class="single-logo-wrapper">
                            <div class="single-item">
                                <img src="<?php echo front_img();?>oof3.jpg" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="space-90"></div>
            <div class="row">
                <div class="col-12 col-md-6">
                    <div class="about-mid-img">
                        <img src="<?php echo front_img();?>about-left.png" alt="">
                    </div>
                </div>
                <div class="col-12 col-md-6 align-self-center">
                    <div class="heading">
                        <h5>We are featured in</h5>
                    </div>
                    <div class="about-mid-text">
                        <h1><?php echo $home_section->english_title;?></h1>
                        <div class="space-10"></div>
                       <?php echo $home_section->$content;?>
                    </div>
                    <div class="space-30"></div>
                    <a href="https://www.telegram.com" class="gradient-btn v2 about-btn">Join Us in Telegram <i class="fa fa-telegram"></i></a>
                </div>
            </div>
        </div>
        <div class="space-90"></div>
    </div>
    <!--about area end-->
<div class="section-title">
    <h2 style="text-align: center;">Markets</h2>
</div>

    <div class="col-md-12">
          <div class="markets-pair-list-1">
            <ul class="nav nav-pills" style="width: auto;" id="pills-tab" role="tablist">

             <li class="nav-item" style="width:50px;">
                <a style="color: #4a4a4a" class="nav-link active" data-toggle="pill" href="#ALL" role="tab" aria-selected="false"><i class=""></i> All</a>
              </li>
              <?php if(count($pairs)>0)
              $arr_pair = array();
               { foreach($pairs as $pair_details) {
                $to_currency_det = getcryptocurrencydetail($pair_details->to_symbol_id);
                $to_symbol = strtoupper($to_currency_det->currency_symbol);
                $arr_pair[] =  $to_symbol;
                
                if($to_symbol !="")
                {

                  } }
                  }
                  $unique_symbol_array = array_unique($arr_pair);
                if($unique_symbol_array): foreach($unique_symbol_array as $unique_sym){
          ?>
          <li class="nav-item" style="width:50px;">
              <a style="color: #4a4a4a" href="<?php echo '#'.$unique_sym.'_pair';?>" data-toggle="tab" 
                  class="nav-link "><?php echo $unique_sym;?></a>
          </li>
          <?php } endif; ?>
            </ul>
            <div class="tab-content" style="overflow: auto;">
              <div class="tab-pane fade show active" id="ALL" role="tabpanel">
                <table class="table">
                  <thead>
                    <tr>
                      <th>Pair</th>
                      <th>Coin</th>
                      <th>Last Price</th>
                      <th>Change</th>
                      <th>24H High</th>
                      <th>24H Low</th>
                      <th>24h Volume</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php
                  if(isset($pairs) && !empty($pairs)){
                  foreach($pairs as $pair_details){
                  $from_currency = $this->common_model->getTableData('currency',array('id' => $pair_details->from_symbol_id))->row();
                  $to_currency = $this->common_model->getTableData('currency',array('id' => $pair_details->to_symbol_id))->row();
                  $pair_symbol = $from_currency->currency_symbol.'/'.$to_currency->currency_symbol;
                  $pair_url = $from_currency->currency_symbol.'_'.$to_currency->currency_symbol;
                  $currency = getcryptocurrencydetail($from_currency->id);
                  if(isset($from_currency) && isset($to_currency)){
                    ?>  
                    <tr>
                      <td><a href="<?php echo base_url()?>exchange/#/<?=$pair_url?>" style="color: #646464;"><i class=""></i> <?=$pair_symbol?></a></td>
                      <td><img src="<?=$from_currency->image?>" width="50px" alt="coin"><?=$from_currency->currency_symbol?></td>
                      <td><?php echo TrimTrailingZeroes($pair_details->lastPrice);?> </td>
                      <td class="<?php echo($pair_details->priceChangePercent>0)?'green':'red';?>"><?php echo number_format($pair_details->priceChangePercent,2);   ?>%</td>
                      <td><?php echo TrimTrailingZeroes($pair_details->change_high);?></td>
                      <td><?php echo TrimTrailingZeroes($pair_details->change_low);?></td>
                      <td><?php echo TrimTrailingZeroes($pair_details->volume);?></td>
                    </tr>
                    <?php } } }?>
                  </tbody>
                </table>
              </div>
      <?php if(count($pairs)>0) { foreach($pairs as $pair_details) { 
                    $to_cur_det  = getcryptocurrencydetail($pair_details->to_symbol_id);
                    $to_sym = strtoupper($to_cur_det->currency_symbol);
                    $to_id = $to_cur_det->id;

                  ?>
             <div class="tab-pane fade show" id="<?php echo $to_sym.'_pair';?>" role="tabpanel">
                <table class="table">
                  <thead>
                    <tr>
                    <th>Pair</th>
                      <th>Coin</th>
                      <th>Last Price</th>
                      <th>Change</th>
                      <th>24H High</th>
                      <th>24H Low</th>
                      <th>24h Volume</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php                
                     $pairs_from = $this->common_model->customQuery("select * from xabits_trade_pairs where to_symbol_id='".$to_id."' or from_symbol_id='".$to_id."'  and status = 1")->result();
                     $i=1;
                    if(count($pairs_from)>0) { foreach($pairs_from as $pairss) {
                    $pairs_id = $pairss->id;
                    $coin_price = tradeprice($pairs_id);
                    $from_curr_dets = getcryptocurrencydetail($pairss->from_symbol_id);
                    $to_curr_dets = getcryptocurrencydetail($pairss->to_symbol_id);
                    $per_24hrs = pricechangepercent($pairs_id);
                    $page_url = $from_curr_dets->currency_symbol.'_'.$to_curr_dets->currency_symbol;
                    $volumes = volume($pairs_id);
                   ?>

                    <tr>
                      <td><a href="<?php echo base_url()?>exchange"><i class=""></i> <?php echo $from_curr_dets->currency_symbol.'/'.$to_curr_dets->currency_symbol;?></a></td>


                      <td><img src="<?=$from_curr_dets->image?>" alt="coin" width="50px"> 
                      <?=$from_curr_dets->currency_symbol?></td>
                      <td><?php echo TrimTrailingZeroes($pairss->lastPrice);?></td>
                      <td class="<?php echo($pairss->priceChangePercent>0)?'green':'red';?>"><?php echo number_format($pairss->priceChangePercent,2);   ?>%</td>
                      <td><?php echo TrimTrailingZeroes($pairss->change_high);?></td>
                      <td><?php echo TrimTrailingZeroes($pairss->change_low);?></td>
                      <td><?php echo TrimTrailingZeroes($pairss->volume);?></td>
                    </tr>
                    <?php $i++; } } ?>
                  </tbody>
                </table>
              </div>
              <?php } } ?>
            </div>
            <!-- <div class="text-center">
              <a href="#" class="load-more btn">Load More <i class="icon ion-md-arrow-down"></i></a>
            </div> -->
          </div>
        </div>

            <!--team-bg-->
    <div class="team-bg">
        <div class="getstart section-padding">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-8">
                <div class="section-title">
                    <h2 style="text-align: center;"><?php echo $mobil->english_title;?></h2>
                </div>
            </div>
        </div>
        <div class="apps-area wow fadeInUp section-padding" id="apps">
            <div class="container">
                <div class="row">

                
                    <div class="col-12 col-lg-12 align-self-center">
                        <div class="heading" style="border: 2px solid #fff;padding: 20px;border-radius: 20px;" >
                            <div class="appss-content" style="text-align: center;">
                                <h1 style="padding-bottom:20px"><?php echo $mobil->english_page;?> </h1>
                                <a href="<?php echo base_url();?>signup" class="gradient-btn">Register Now</a>
                                <h4 style="padding-top:40px"><?php echo $mobil->english_content;?></h4>

                            </div>


                        </div>
                        <div class="space-30"></div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

        <!--apps area start-->
        <div class="apps-area wow fadeInUp section-padding" id="apps">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-lg-6 offset-1 align-self-center">
                        <div class="heading">
                            <div class="appss-content" style="text-align: center;">
                                <h1 style="padding-bottom:40px">Start your CryptoCurrency Journey Today</h1>
                               

                                <div class="col-12">
                                    <div class="row">
                                    <div class="col-6 faci-text" >
                                        <svg xmlns="http://www.w3.org/2000/svg" version="1.0" width="100px" height="100px" viewBox="0 0 512.000000 512.000000" preserveAspectRatio="xMidYMid meet">

                                            <g transform="translate(0.000000,512.000000) scale(0.100000,-0.100000)" fill="#fff" stroke="none">
                                            <path d="M4722 5027 c-43 -13 -116 -78 -132 -117 l-12 -30 -187 0 -186 0 -186 -186 -187 -187 -113 66 c-325 186 -645 282 -1036 310 l-43 3 0 -323 0 -323 39 0 c78 0 289 -43 411 -83 509 -168 899 -559 1069 -1072 39 -117 81 -329 81 -406 l0 -39 323 0 323 0 -8 98 c-22 283 -98 568 -221 824 -136 280 -359 571 -584 758 -48 41 -92 78 -98 82 -5 5 54 71 145 163 l155 155 151 0 152 0 12 -30 c17 -42 90 -104 138 -118 91 -28 167 -8 237 63 98 97 101 222 8 325 -64 72 -159 97 -251 67z m133 -172 c16 -15 25 -36 25 -55 0 -19 -9 -40 -25 -55 -15 -16 -36 -25 -55 -25 -19 0 -40 9 -55 25 -16 15 -25 36 -25 55 0 19 9 40 25 55 15 16 36 25 55 25 19 0 40 -9 55 -25z m-1850 -177 c151 -30 355 -101 501 -173 447 -221 809 -591 1021 -1043 80 -171 155 -426 179 -609 l7 -53 -162 0 c-88 0 -161 3 -161 6 0 3 -9 52 -20 107 -72 355 -230 659 -475 915 -295 308 -621 480 -1057 556 l-38 7 0 161 0 161 53 -7 c28 -4 97 -16 152 -28z"/>
                                            <path d="M2440 4884 c-298 -28 -490 -69 -696 -148 -420 -161 -772 -426 -1043 -786 -278 -369 -429 -781 -464 -1267 l-3 -43 323 0 323 0 0 39 c0 77 42 289 81 406 199 600 698 1029 1318 1134 68 12 141 21 162 21 l39 0 0 325 c0 179 -1 324 -2 323 -2 0 -19 -3 -38 -4z m-120 -334 c0 -88 -2 -160 -4 -160 -2 0 -39 -7 -82 -15 -43 -8 -78 -14 -79 -12 -2 2 -57 284 -59 302 -1 9 145 42 197 44 l27 1 0 -160z m-380 77 c0 -2 14 -71 30 -152 17 -82 28 -151 25 -153 -11 -12 -145 -59 -149 -53 -18 31 -117 283 -113 288 4 3 46 20 94 39 81 31 113 39 113 31z m-296 -290 c32 -77 55 -141 53 -143 -11 -11 -120 -74 -128 -74 -9 0 -167 230 -171 250 -3 14 174 121 183 111 3 -3 32 -68 63 -144z m-299 -182 c48 -69 85 -130 83 -134 -2 -5 -28 -29 -59 -54 l-56 -46 -111 112 -112 112 78 67 c42 37 80 68 84 68 4 0 46 -56 93 -125z m-192 -404 c-25 -31 -48 -57 -52 -59 -7 -2 -223 139 -250 164 -12 11 -3 25 54 94 l69 81 112 -112 113 -112 -46 -56z m-270 -113 c64 -43 117 -82 117 -87 0 -4 -16 -36 -37 -70 -26 -44 -41 -60 -52 -56 -67 22 -276 116 -274 124 2 5 25 48 53 96 33 56 55 83 63 78 7 -3 65 -42 130 -85z m-214 -287 c53 -22 117 -49 143 -60 l46 -20 -27 -70 c-15 -39 -30 -73 -32 -75 -2 -3 -69 8 -149 25 -79 16 -148 29 -153 29 -5 0 -6 12 -2 27 11 45 66 183 73 183 3 0 49 -18 101 -39z m88 -386 c2 -1 -4 -36 -12 -79 -8 -43 -15 -80 -15 -82 0 -2 -72 -4 -160 -4 -150 0 -160 1 -160 19 0 19 28 177 35 197 2 8 51 2 157 -19 84 -17 154 -31 155 -32z"/>
                                            <path d="M2665 3874 c-55 -75 -104 -138 -109 -141 -4 -3 -54 40 -110 95 l-101 101 -222 -56 c-123 -30 -223 -59 -223 -64 0 -5 54 -153 120 -329 66 -176 120 -326 119 -333 0 -6 -50 -55 -111 -107 -252 -217 -312 -283 -391 -438 -206 -400 -133 -867 182 -1183 214 -213 479 -311 801 -296 152 7 262 33 386 92 122 57 204 114 295 204 315 316 388 783 182 1183 -79 154 -141 224 -400 448 l-109 95 123 370 c68 203 123 373 123 376 0 5 -440 120 -452 119 -2 -1 -48 -62 -103 -136z m268 -69 c42 -10 77 -24 77 -29 0 -6 -42 -137 -93 -291 l-94 -280 -264 -3 -264 -2 -94 250 c-51 138 -92 252 -90 254 2 2 44 13 93 25 l90 22 137 -137 137 -137 133 177 c72 97 137 175 143 173 6 -2 46 -12 89 -22z m75 -903 c245 -216 316 -304 376 -463 186 -496 -122 -1045 -643 -1143 -164 -31 -370 -15 -511 41 -391 156 -615 564 -531 969 48 234 124 341 436 618 l130 115 293 0 293 1 157 -138z"/>
                                            <path d="M2480 2640 c0 -67 -3 -80 -16 -80 -77 0 -189 -88 -212 -166 -28 -94 -8 -169 63 -239 63 -64 100 -75 244 -75 105 0 113 -1 136 -25 16 -15 25 -36 25 -55 0 -19 -9 -40 -25 -55 -23 -24 -29 -25 -160 -25 l-135 0 0 40 0 40 -80 0 -80 0 0 -120 0 -120 120 0 120 0 0 -80 0 -80 80 0 80 0 0 80 c0 67 3 80 16 80 77 0 189 88 212 166 28 94 8 169 -63 239 -63 64 -100 75 -244 75 -105 0 -113 1 -136 25 -33 32 -33 78 0 110 23 24 29 25 160 25 l135 0 0 -40 0 -40 80 0 80 0 0 120 0 120 -120 0 -120 0 0 80 0 80 -80 0 -80 0 0 -80z"/>
                                            <path d="M242 2383 c49 -640 378 -1257 878 -1645 l35 -28 -155 -155 -155 -155 -151 0 -152 0 -12 30 c-28 68 -129 130 -210 130 -124 0 -240 -116 -240 -240 0 -124 116 -240 240 -240 81 0 182 62 210 130 l12 30 187 0 186 0 185 185 c102 102 187 185 191 185 3 0 44 -23 90 -51 292 -176 649 -290 997 -317 l102 -8 0 322 0 321 -76 6 c-572 49 -1098 410 -1353 931 -90 182 -171 481 -171 627 l0 39 -323 0 -323 0 8 -97z m488 -69 c0 -23 45 -224 66 -293 133 -441 443 -828 849 -1062 106 -61 263 -129 376 -163 69 -21 270 -66 293 -66 3 0 6 -73 6 -161 l0 -162 -52 7 c-204 27 -456 104 -651 200 -450 222 -812 590 -1024 1044 -80 171 -155 426 -179 610 l-7 52 162 0 c88 0 161 -3 161 -6z m-355 -1939 c50 -49 15 -135 -55 -135 -41 0 -80 39 -80 80 0 41 39 80 80 80 19 0 40 -9 55 -25z"/>
                                            <path d="M4240 2441 c0 -21 -9 -94 -21 -162 -120 -708 -670 -1258 -1378 -1378 -68 -12 -141 -21 -162 -21 l-39 0 0 -323 0 -323 43 3 c485 35 891 184 1265 463 536 400 878 1018 930 1678 l8 102 -323 0 -323 0 0 -39z m465 -173 c-78 -606 -434 -1166 -965 -1519 -252 -168 -592 -296 -887 -335 l-53 -7 0 161 0 161 38 7 c178 31 300 66 449 130 240 103 418 227 608 426 245 256 403 560 475 915 11 55 20 104 20 107 0 3 72 6 161 6 l161 0 -7 -52z"/>
                                            </g>
                                            </svg><br>
                                        <span style="color: white;">Manage Assets</span>
                                    </div>
                                    <div class="col-6 faci-text">
                                        <svg xmlns="http://www.w3.org/2000/svg" version="1.0" width="100px" height="100px" viewBox="0 0 512.000000 512.000000" preserveAspectRatio="xMidYMid meet">

                                            <g transform="translate(0.000000,512.000000) scale(0.100000,-0.100000)" fill="#fff" stroke="none">
                                            <path d="M2380 4954 c-19 -2 -78 -9 -130 -15 -442 -50 -908 -248 -1265 -536 -127 -102 -319 -300 -412 -424 -239 -319 -386 -662 -454 -1060 -33 -194 -33 -544 0 -738 68 -397 213 -738 453 -1060 95 -127 348 -379 475 -474 359 -265 756 -427 1203 -488 124 -18 506 -18 630 0 447 61 844 223 1203 488 129 96 380 347 478 478 240 323 393 687 455 1085 25 161 25 519 0 680 -78 504 -298 945 -651 1309 -391 402 -885 653 -1450 737 -96 14 -462 27 -535 18z m375 -144 c566 -49 1056 -269 1452 -653 369 -358 592 -790 669 -1297 24 -157 24 -463 0 -620 -77 -508 -300 -939 -671 -1298 -635 -616 -1567 -820 -2420 -530 -564 191 -1059 624 -1320 1153 -161 327 -229 619 -229 985 0 217 16 346 64 542 197 789 842 1433 1645 1643 283 74 539 98 810 75z"/>
                                            <path d="M3539 4015 c-5 -4 -201 -58 -384 -105 -38 -9 -131 -34 -205 -55 -74 -20 -175 -48 -225 -60 -49 -13 -151 -40 -225 -60 -74 -20 -166 -45 -205 -55 -38 -10 -131 -34 -205 -55 -74 -20 -225 -61 -335 -90 -110 -29 -303 -81 -430 -115 -126 -34 -268 -72 -315 -84 -127 -34 -175 -65 -199 -129 -19 -49 -12 -101 34 -280 l45 -174 0 -758 c0 -825 -2 -790 56 -849 60 -60 -19 -56 1280 -56 1093 0 1189 1 1206 16 22 20 24 63 4 90 -14 19 -39 19 -1199 22 l-1184 2 -19 21 c-18 20 -19 49 -19 749 0 702 1 729 19 749 l19 21 1507 0 1507 0 21 -23 22 -23 0 -725 c0 -716 0 -726 -20 -747 -20 -21 -29 -22 -178 -22 -180 0 -202 -7 -202 -64 0 -62 17 -68 205 -67 198 0 234 12 288 89 l32 47 3 743 c1 486 -1 757 -8 782 -14 52 -78 116 -132 131 -24 7 -46 15 -50 19 -8 6 -70 225 -89 310 -5 25 -18 74 -29 110 -10 36 -48 178 -85 315 -36 138 -71 262 -76 276 -13 34 -66 85 -102 98 -28 11 -119 15 -128 6z m95 -144 c16 -18 56 -140 56 -172 0 -12 -17 -21 -57 -32 -32 -8 -161 -42 -288 -76 -126 -35 -329 -89 -450 -121 -121 -32 -229 -62 -240 -66 -55 -20 -73 -75 -35 -109 26 -24 55 -19 320 53 312 84 463 125 620 167 74 19 142 38 151 41 12 3 19 -6 28 -38 31 -109 71 -264 71 -274 0 -6 -26 -16 -57 -23 -32 -7 -68 -19 -80 -27 -43 -27 -20 -114 30 -114 10 0 46 7 79 16 33 8 63 13 65 10 9 -9 61 -201 56 -208 -6 -10 -843 -10 -843 0 0 4 24 13 53 20 168 40 435 117 450 130 20 18 22 61 4 86 -18 25 -64 23 -172 -7 -49 -14 -193 -53 -320 -87 -126 -34 -295 -80 -375 -103 l-145 -42 -637 -3 c-351 -1 -638 1 -638 6 0 4 39 18 88 30 48 12 179 47 292 77 113 31 306 82 429 115 123 33 234 66 247 75 16 11 24 25 24 45 0 29 -29 70 -49 70 -9 0 -621 -162 -1021 -271 -246 -66 -310 -82 -317 -76 -9 10 -43 140 -43 168 0 38 26 56 115 78 44 10 139 35 210 54 72 20 222 60 335 90 190 51 480 129 795 213 72 19 173 47 225 60 52 14 145 39 205 55 61 17 151 41 200 54 50 13 151 40 225 60 74 21 177 48 229 61 52 13 97 26 99 29 12 12 50 4 66 -14z"/>
                                            <path d="M2505 2544 c-11 -2 -45 -9 -75 -15 -180 -37 -349 -201 -406 -394 -23 -78 -23 -210 0 -290 41 -140 150 -278 273 -343 72 -38 196 -72 262 -72 73 0 180 27 251 62 80 41 194 151 239 232 39 71 71 189 71 266 0 77 -33 200 -72 269 -66 117 -207 230 -329 265 -57 16 -180 28 -214 20z m136 -134 c224 -42 379 -266 341 -492 -41 -238 -277 -397 -512 -344 -219 48 -368 266 -331 482 42 240 267 398 502 354z"/>
                                            <path d="M2550 2245 c-7 -18 -17 -25 -36 -25 -17 0 -40 -14 -66 -40 -38 -37 -40 -43 -35 -82 7 -55 35 -90 88 -109 l44 -17 3 -61 c3 -70 -1 -73 -62 -40 -47 25 -80 22 -84 -8 -4 -26 24 -46 95 -72 40 -14 49 -22 53 -46 7 -42 43 -42 50 0 4 23 12 31 38 39 43 12 89 55 98 91 4 17 1 45 -7 69 -12 34 -23 45 -71 69 l-58 28 0 59 0 59 44 -16 c49 -18 76 -13 76 16 0 22 -37 49 -81 58 -17 3 -33 13 -37 22 -13 37 -39 40 -52 6z m0 -140 c0 -59 -4 -63 -38 -39 -26 18 -29 56 -6 78 31 31 44 20 44 -39z m110 -205 c0 -26 -29 -60 -52 -60 -5 0 -8 27 -8 60 l0 61 30 -16 c23 -12 30 -22 30 -45z"/>
                                            </g>
                                            </svg><br>
                                        <span style="color: white;">Payments</span>
                                    </div>
                                    <div class="col-6 faci-text">
                                        <svg xmlns="http://www.w3.org/2000/svg" version="1.0" width="100px" height="100px" viewBox="0 0 512.000000 512.000000" preserveAspectRatio="xMidYMid meet">

                                            <g transform="translate(0.000000,512.000000) scale(0.100000,-0.100000)" fill="#fff" stroke="none">
                                            <path d="M2380 4954 c-19 -2 -78 -9 -130 -15 -442 -50 -908 -248 -1265 -536 -127 -102 -319 -300 -412 -424 -239 -319 -386 -662 -454 -1060 -33 -194 -33 -544 0 -738 68 -397 213 -738 453 -1060 95 -127 348 -379 475 -474 359 -265 756 -427 1203 -488 124 -18 506 -18 630 0 447 61 844 223 1203 488 129 96 380 347 478 478 240 323 393 687 455 1085 25 161 25 519 0 680 -78 504 -298 945 -651 1309 -391 402 -885 653 -1450 737 -96 14 -462 27 -535 18z m375 -144 c566 -49 1056 -269 1452 -653 369 -358 592 -790 669 -1297 24 -157 24 -463 0 -620 -77 -508 -300 -939 -671 -1298 -635 -616 -1567 -820 -2420 -530 -564 191 -1059 624 -1320 1153 -161 327 -229 619 -229 985 0 217 16 346 64 542 197 789 842 1433 1645 1643 283 74 539 98 810 75z"/>
                                            <path d="M2549 4335 c-3 -2 -81 -31 -175 -63 -589 -206 -1390 -504 -1411 -525 -37 -36 -58 -289 -58 -682 0 -328 9 -456 51 -702 108 -640 379 -1131 802 -1451 248 -189 594 -325 822 -324 209 1 563 138 792 309 574 427 866 1137 877 2128 3 282 -25 650 -54 706 -10 19 -32 34 -72 49 -282 107 -1178 433 -1432 521 -111 38 -133 44 -142 34z m458 -390 c883 -318 974 -352 982 -361 5 -5 14 -89 20 -186 77 -1238 -269 -2088 -994 -2447 -211 -105 -392 -151 -513 -130 -232 40 -500 173 -697 348 -422 373 -647 957 -671 1741 -7 223 10 658 25 673 6 6 101 43 213 84 307 112 1155 416 1205 432 2 1 195 -69 430 -154z"/>
                                            <path d="M2400 3451 c-109 -12 -218 -89 -270 -191 -27 -52 -39 -170 -40 -367 l0 -143 -42 0 c-54 0 -119 -38 -150 -87 l-23 -38 0 -405 0 -405 23 -32 c12 -18 37 -43 55 -55 l32 -23 590 0 590 0 32 23 c17 12 42 39 55 60 l23 37 0 400 0 400 -23 38 c-31 49 -96 87 -150 87 l-42 0 -1 98 c0 53 -4 158 -8 232 -7 123 -10 141 -36 189 -38 69 -112 135 -183 162 -48 18 -82 22 -217 24 -88 1 -185 0 -215 -4z m371 -247 c44 -22 51 -57 52 -261 l2 -188 -254 -3 -253 -2 4 192 c6 289 8 291 278 281 92 -3 155 -10 171 -19z m-114 -709 c77 -51 85 -175 14 -239 -19 -18 -21 -30 -21 -161 0 -96 -4 -145 -12 -153 -7 -7 -35 -12 -63 -12 -28 0 -56 5 -63 12 -8 8 -12 56 -12 151 l0 139 -30 34 c-16 19 -34 52 -40 75 -10 36 -8 46 12 87 33 67 79 95 142 88 27 -3 59 -12 73 -21z"/>
                                            </g>
                                            </svg><br>
                                        <span style="color: white;">Secured Storage</span>
                                    </div>
                                    <div class="col-6 faci-text" >
                                        <svg xmlns="http://www.w3.org/2000/svg" version="1.0" width="100px" height="100px" viewBox="0 0 512.000000 512.000000" preserveAspectRatio="xMidYMid meet">

                                            <g transform="translate(0.000000,512.000000) scale(0.100000,-0.100000)" fill="#fff" stroke="none">
                                            <path d="M2380 4954 c-19 -2 -78 -9 -130 -15 -442 -50 -908 -248 -1265 -536 -127 -102 -319 -300 -412 -424 -239 -319 -386 -662 -454 -1060 -33 -194 -33 -544 0 -738 68 -397 213 -738 453 -1060 95 -127 348 -379 475 -474 359 -265 756 -427 1203 -488 124 -18 506 -18 630 0 447 61 844 223 1203 488 129 96 380 347 478 478 240 323 393 687 455 1085 25 161 25 519 0 680 -78 504 -298 945 -651 1309 -391 402 -885 653 -1450 737 -96 14 -462 27 -535 18z m375 -144 c566 -49 1056 -269 1452 -653 369 -358 592 -790 669 -1297 24 -157 24 -463 0 -620 -77 -508 -300 -939 -671 -1298 -635 -616 -1567 -820 -2420 -530 -564 191 -1059 624 -1320 1153 -161 327 -229 619 -229 985 0 217 16 346 64 542 197 789 842 1433 1645 1643 283 74 539 98 810 75z"/>
                                            <path d="M1164 4331 c-44 -27 -60 -77 -40 -124 19 -46 49 -61 174 -82 56 -10 102 -21 102 -25 0 -4 -34 -36 -77 -71 -320 -268 -530 -697 -550 -1127 l-6 -133 28 -29 c15 -16 40 -32 56 -35 33 -8 89 16 107 45 7 12 17 80 22 153 24 322 135 587 354 841 49 57 197 188 204 182 2 -2 -9 -60 -23 -129 -23 -114 -24 -129 -11 -160 7 -19 24 -42 37 -51 49 -34 131 -9 153 47 7 18 35 143 62 278 42 218 46 249 35 277 -7 17 -23 38 -35 46 -21 13 -498 116 -541 116 -11 0 -34 -9 -51 -19z"/>
                                            <path d="M2741 4322 c-17 -17 -31 -39 -32 -49 -4 -59 12 -92 54 -115 10 -5 75 -14 144 -18 309 -22 587 -138 822 -341 72 -62 205 -208 197 -216 -2 -2 -60 8 -129 22 -115 24 -129 24 -161 11 -36 -15 -66 -59 -66 -96 0 -36 30 -81 63 -94 18 -7 143 -35 278 -62 218 -42 249 -46 277 -35 17 7 38 24 47 38 17 26 115 484 115 539 0 69 -78 118 -143 90 -46 -19 -60 -48 -86 -175 -12 -58 -23 -106 -25 -108 -2 -2 -22 21 -46 52 -71 92 -232 238 -345 314 -249 167 -511 254 -802 268 l-132 6 -30 -31z"/>
                                            <path d="M2400 3809 c-353 -45 -684 -250 -884 -548 -104 -154 -175 -335 -203 -516 -19 -125 -12 -332 16 -455 84 -374 329 -687 673 -861 79 -40 231 -92 323 -110 93 -18 377 -19 470 0 433 85 802 400 950 809 69 191 93 433 61 624 -46 279 -166 511 -369 711 -267 262 -662 394 -1037 346z m349 -294 c56 -51 181 -252 181 -293 0 -10 -30 -12 -132 -10 l-133 3 -2 175 c-1 96 1 178 4 183 5 8 20 -2 82 -58z m-291 -122 l-3 -178 -132 -3 c-88 -2 -133 1 -133 8 0 20 72 155 116 217 46 65 118 133 141 133 11 0 13 -34 11 -177z m-405 35 c-20 -40 -48 -104 -63 -143 l-26 -70 -107 -3 c-59 -1 -107 1 -107 6 0 14 127 139 190 187 45 34 139 95 147 95 1 0 -14 -33 -34 -72z m1144 -35 c72 -55 173 -156 173 -174 0 -6 -44 -9 -107 -7 l-107 3 -31 80 c-17 44 -46 109 -64 144 l-33 64 49 -28 c26 -15 81 -52 120 -82z m-1290 -415 c-11 -42 -26 -152 -33 -236 l-7 -82 -176 2 -176 3 3 40 c5 47 46 193 72 253 l19 42 152 0 151 0 -5 -22z m551 -145 l-3 -168 -189 -3 -189 -2 7 77 c3 43 14 119 23 170 l16 93 169 0 168 0 -2 -167z m547 145 c13 -64 25 -147 31 -228 l7 -90 -189 2 -189 3 -3 168 -2 167 170 0 c168 0 170 0 175 -22z m537 -45 c29 -75 56 -179 60 -233 l3 -35 -174 0 -175 0 -17 137 c-10 76 -20 151 -24 168 l-7 30 154 0 154 0 26 -67z m-1659 -625 c10 -79 20 -155 24 -171 l5 -28 -152 3 -153 3 -27 71 c-25 66 -53 169 -63 237 l-4 27 176 0 177 0 17 -142z m575 -25 l-3 -168 -165 0 -164 0 -17 83 c-10 46 -21 122 -24 168 l-7 84 191 0 191 0 -2 -167z m578 80 c-8 -95 -33 -233 -45 -246 -4 -4 -79 -6 -167 -5 l-159 3 -3 168 -2 167 191 0 192 0 -7 -87z m567 45 c-7 -57 -46 -191 -73 -250 l-21 -48 -146 0 -146 0 6 48 c4 26 12 102 19 170 l12 122 177 0 177 0 -5 -42z m-1609 -580 c16 -40 43 -101 61 -135 18 -35 29 -63 24 -63 -12 0 -108 58 -154 93 -54 41 -132 116 -156 150 l-20 27 108 0 109 0 28 -72z m466 -108 c0 -128 -3 -180 -11 -180 -7 0 -44 33 -83 73 -67 67 -117 146 -160 250 l-15 37 135 0 134 0 0 -180z m459 153 c-36 -95 -98 -193 -166 -261 -40 -41 -77 -71 -83 -67 -6 4 -10 71 -10 181 l0 174 135 0 135 0 -11 -27z m401 -39 c-75 -76 -154 -139 -229 -183 -28 -17 -54 -31 -56 -31 -3 0 11 28 30 63 19 34 46 93 60 132 15 38 29 73 31 77 3 4 55 8 117 8 l111 0 -64 -66z"/>
                                            <path d="M4181 2382 c-26 -25 -29 -36 -35 -132 -25 -356 -152 -657 -379 -897 -83 -87 -175 -169 -182 -161 -2 2 7 60 21 127 14 68 23 134 20 146 -26 104 -164 112 -200 11 -9 -23 -36 -148 -62 -278 -42 -211 -45 -241 -34 -268 7 -18 23 -38 35 -46 23 -15 488 -114 536 -114 39 0 92 40 103 78 12 42 -12 95 -51 115 -15 8 -75 24 -132 36 -58 12 -106 23 -108 24 -1 2 19 20 46 40 53 41 202 190 252 252 205 257 339 628 339 938 0 96 -1 102 -27 129 -38 40 -103 40 -142 0z"/>
                                            <path d="M912 1780 c-18 -11 -36 -30 -41 -43 -13 -34 -102 -482 -103 -518 -3 -96 108 -141 175 -71 21 22 31 50 47 132 12 58 23 111 26 118 2 9 20 -7 46 -40 270 -344 761 -588 1185 -588 118 0 145 11 163 65 14 43 4 80 -30 109 -24 19 -44 24 -131 30 -298 21 -556 114 -779 282 -93 70 -211 185 -259 253 l-25 34 25 -6 c13 -4 73 -16 132 -28 103 -21 110 -21 143 -5 49 23 71 75 52 124 -7 19 -24 43 -38 53 -22 15 -492 119 -540 119 -8 0 -30 -9 -48 -20z"/>
                                            </g>
                                            </svg><br>
                                        <span style="color: white;">Anywhere Access</span>
                                    </div>
                                </div>
                                </div>
                            </div>
                      </div>
                        <div class="space-30"></div>

                    </div>
                    <div class="col-12 col-lg-4 offset-1">
                        <div class="apps-img">
                            <img src="<?php echo front_img();?>Mobile.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--apps area end-->


    </div>
  
    <?php $this->load->view('front/common/footer') ?>

    <script src="https://cdn.datatables.net/1.11.1/js/jquery.dataTables.min.js"></script>

  <script src="https://cdn.datatables.net/1.11.1/js/dataTables.bootstrap4.min.js"></script>

<script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>

<script src="https://cdn.datatables.net/responsive/2.2.9/js/responsive.bootstrap4.min.js"></script>
<!--datatables-->
<script type="text/javascript" src="<?php echo front_js();?>datatables.min.js"></script>