<?php
$user_id=$this->session->userdata('user_id');
$site_common = site_common();
$sitelogo = $site_common['site_settings']->site_logo;
$sitephone = $site_common['site_settings']->contactno;
 $lang_id = $this->session->userdata('site_lang');
  if($lang_id!=''){
  //$title = $lang_id.'_name';
  $content = $lang_id.'_content';
  }else{
 // $title = $site_lang.'_name';
  $content = $site_lang.'_content';
  }
?>
  <!-- ---------------------footer---------------------------- -->

<!-- START FOOTER SECTION -->
<footer>
	<div class="top_footer blue_dark_bg">
		<div class="container">
			<div class="row">
				<div class="col-lg-4 col-md-12">
                    <div class="footer_logo mb-3 animation" data-animation="fadeInUp" data-animation-delay="0.2s"> 
                        <a href="#home_section" class="page-scroll">
                            <img alt="logo" src="<?php echo $sitelogo;?>" style="width: 100px;">
                        </a> 
                    </div>
                    <div class="footer_desc" style="font-weight: bold;">
                      <p><i class=" fa fa-envelope"></i> support@xabitschange.nl</p>
                        <p><i class=" fa fa-phone"></i> <?=$sitephone;?></p>
                        <p><i class=" fa fa-address-book"></i> <a style="color: #fff;" href="<?php echo base_url();?>contact_us">Contact</a></p>
          				<!-- <p class="animation" data-animation="fadeInUp" data-animation-delay="0.4s"><?php echo $footer->$content;?></p> -->
                    </div>
         		</div>
                <div class="col-xl-6 col-lg-5 col-sm-8 res_md_mt_30 res_sm_mt_20">
                	<div class="newsletter_form newslattter_small text-md-center">
                        <h4 class="footer_title animation" data-animation="fadeInUp" data-animation-delay="0.2s">SUBSCRIBE OUR NEWSLETTER</h4>
                         <?php
                        $action = base_url().'reg_subscribe';
                        $attributes = array('id'=>'subscribe_form',"method"=>"post","class"=>"subscribe_form animation","data-animation"=>"fadeInUp","data-animation-delay"=>"0.4s"); 
                        echo form_open_multipart($action,$attributes);
                    ?>
                            <input class="input-rounded" type="email" name="email" required placeholder="Enter Your Email Address"/>
                          <button  style="border-radius: 1rem;" type="submit" title="Subscribe" class="btn-info" name="submit" value="Submit">Subscribe </button>
                        <?php echo form_close();?>
                        <div id="email-error" class="error"></div>
                    </div>
                    <div class="footer_social_s2">
                    	<h4 class="footer_title animation text-md-center" data-animation="fadeInUp" data-animation-delay="0.2s">Follow Us</h4>
                        <ul class="list_none social_icon d-md-flex justify-content-center text-center">
                            <li class="animation" data-animation="fadeInUp" data-animation-delay="0.4s"><a href="<?php echo $site_common['site_settings']->facebooklink; ?>"><i class=" fa fa-facebook"></i></a></li>
                            <li class="animation" data-animation="fadeInUp" data-animation-delay="0.5s"><a href="<?php echo $site_common['site_settings']->twitterlink; ?>"><i class=" fa fa-twitter"></i></a></li>
                            <li class="animation" data-animation="fadeInUp" data-animation-delay="0.6s"><a href="<?php echo $site_common['site_settings']->googlelink; ?>"><i class=" fa fa-google-plus"></i></a></li>
                            <!-- <li class="animation" data-animation="fadeInUp" data-animation-delay="0.7s"><a href="<?php echo $site_common['site_settings']->pinterest_link; ?>"><i class=" fa fa-pinterest"></i></a></li> -->
                            <li class="animation" data-animation="fadeInUp" data-animation-delay="0.8s"><a href="<?php echo $site_common['site_settings']->linkedin_link; ?>"><i class=" fa fa-linkedin"></i></a></li>
                         </ul>
                     </div>
                </div>
                <div class="col-xl-2 col-lg-3 col-sm-4 res_md_mt_30 res_sm_mt_20">
                	<h4 class="footer_title animation" data-animation="fadeInUp" data-animation-delay="0.2s">Quick Links</h4>
                    <ul class="footer_link list_arrow">
                    	<li class="animation" data-animation="fadeInUp" data-animation-delay="0.2s"><a href="<?=base_url('exchange')?>">Buy / Sell</a></li>
                      <li class="animation" data-animation="fadeInUp" data-animation-delay="0.3s"><a href="<?=base_url('public_api')?>">Public Api</a></li> 
                        <!-- <li class="animation" data-animation="fadeInUp" data-animation-delay="0.4s"><a href="#">Services</a></li>
                        <li class="animation" data-animation="fadeInUp" data-animation-delay="0.5s"><a href="#">Tokens</a></li> -->
                        <li class="animation" data-animation="fadeInUp" data-animation-delay="0.6s"><a href="<?php echo base_url();?>faq">FAQ</a></li>
                        <!-- <li class="animation" data-animation="fadeInUp" data-animation-delay="0.7s"></li> -->
                    </ul>
                </div>
      		</div>
    	</div>
    </div>
    <div class="bottom_footer">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <p class="copyright">Copyright &copy; 2022 xabits All Rights Reserved.</p>
        </div>
        <div class="col-md-6">
          <ul class="list_none footer_menu">
            <li><a href="<?php echo base_url();?>cms/privacy-policy">Privacy Policy</a></li>
            <li><a href="<?php echo base_url();?>cms/terms-and-conditions">Terms & Conditions</a></li>
          </ul>
        </div>
      </div>
    </div>
    </div>
</footer>
<!-- END FOOTER SECTION --> 

<a href="#" class="scrollup btn-default"><i class="ion-ios-arrow-up"></i></a> 

<!-- Latest jQuery --> 
<!-- <script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script> -->
<script src="<?php echo front_js();?>jquery-1.12.4.min.js"></script> 
<script src="<?php echo front_js();?>toastr.min.js"></script>

<!-- Latest compiled and minified Bootstrap --> 
<script src="<?php echo front_js();?>bootstrap/js/bootstrap.min.js"></script> 
<!-- owl-carousel min js  --> 
<script src="<?php echo front_js();?>owlcarousel/js/owl.carousel.min.js"></script> 
<!-- magnific-popup min js  --> 
<!-- parallax js  --> 
<script src="<?php echo front_js();?>parallax.js"></script> 
<!-- countdown js  --> 
 <script src="<?php echo front_js();?>jquery.countdown.min.js"></script> 
 <!-- particles min js  --> 
<!-- <script src="<?php echo front_js();?>particles.min.js"></script>  -->
<!-- scripts js --> 
<script src="<?php echo front_js();?>jquery.dd.min.js"></script> 
<!-- scripts js --> 
<script src="<?php echo front_js();?>scripts_home.js"></script>

    <script src="<?php echo front_js();?>home_two/app.min.js"></script> 
    <script src="<?php echo front_js();?>home_two/scripts.js"></script>
    <script src="<?php echo front_js();?>jquery.validate.min.js"></script>

<script>

    function googleTranslateElementInit() {
        new google.translate.TranslateElement(
            {pageLanguage: 'en',
            includedLanguages : 'en,es'

          },
            'google_translate_element'
        );
    }
</script>
<script src="http://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
 <script src="https://cdn.datatables.net/1.11.1/js/jquery.dataTables.min.js"></script>

  <script src="https://cdn.datatables.net/1.11.1/js/dataTables.bootstrap4.min.js"></script>

<script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>

<script src="https://cdn.datatables.net/responsive/2.2.9/js/responsive.bootstrap4.min.js"></script>




<script type="text/javascript">
//   $('#coin_table').DataTable( {
// // "bPaginate": false,
// // "bFilter": false,
// // "bInfo": false,
// responsive: true
// } );
   $('#coin_table').DataTable({responsive: true });

</script>
    <?php
    $error      = $this->session->flashdata('error');
    $success    = $this->session->flashdata('success');
    $user_id    = $this->session->userdata('user_id');
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $get_os     = $_SERVER['HTTP_USER_AGENT'];
?>

<script type="text/javascript">        
    function choose_lang(obj){
        var selct_lang = obj.value;
        //console.log(selct_lang); 
                window.location.href="<?php echo base_url()?>switchLang/"+selct_lang;
    }
    </script>
 <script>
    // ----------------navbar--------------------------------

function openNavbar(){
  var o = document.getElementById("slideNavbar")

  o.style.right = '0';
  o.style.transition = "1.5s ease";
}
function closeNavbar(){
  var c = document.getElementById("slideNavbar")

  c.style.right = '-115%';
  c.style.transition = "1.5s ease";
}
 
    
var base_url='<?php echo base_url();?>';
var front_url='<?php echo front_url();?>';
var user_id='<?php echo $user_id;?>';
var ip_address = '<?php echo $ip_address;?>';
var get_os     = '<?php echo $get_os;?>';
var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';
var success = "<?php echo $this->session->flashdata('success')?>";
var error = "<?php echo $this->session->flashdata('error')?>";
$(document).ready(function() {
if(success!=''){
toastr.success('xabits! '+success);
}
if(error!=''){
    toastr.error('xabits! '+error);
}
});


  </script>
  <script>
   
        $("#subscribe_form").validate({
             rules: {
            email: {
                required: true,
                email:true
            },
        },
        messages: {
            email: {
                required:"Please enter email address",
                email: "Please enter valid email address",
                remote: "Entered Email Address Already Exists"
            }
        },
        errorElement : 'div',
    errorLabelContainer: '#email-error'
        
        });
  </script>



    <script>
   
        $("#subscribe_form").validate({
             rules: {
            email: {
                required: true,
                email:true
            },
        },
        messages: {
            email: {
                required:"Please enter email address",
                email: "Please enter valid email address",
                remote: "Entered Email Address Already Exists"
            }
        },
        errorElement : 'div',
    errorLabelContainer: '#email-error'
        
        });
  </script>
    <script>
            function choose_lang(obj){
        var selct_lang = obj.value; 
                window.location.href="<?php echo base_url()?>switchLang/"+selct_lang;
    }
 
        </script>


</body>

<!-- Mirrored from bestwebcreator.com/cryptocash/demo/index-royal-blue-particle.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 28 Jul 2021 12:55:16 GMT -->
</html>