<?php $this->load->view('front/common/inner_header');
$lang_id = $this->session->userdata('site_lang');
$user_id = $this->session->userdata('user_id');
// $content = $sitelan."_content";
// echo 'lang '.$sitelan;
// echo $home_section->$sitelan.'_content';
if($lang_id!=''){
//$title = $lang_id.'_name';
$question = $lang_id.'_question';
$description = $lang_id.'_description';
}else{
//$title = $site_lang.'_name';
$question = $site_lang.'_question';
$description = $site_lang.'_description';
}
// echo $faq_id;
?>

<!-- START SECTION FAQ -->
<div class="pb-50">
    <div class="container">
        <div class="sec-title text-center">
            <h1 data-watermark="">
                <?php if($faq_id){
                    $faq_category = $this->common_model->getTableData('xabits_faq_category',array('id'=>$faq_id))->row();
                    ?>
                    <span><?php echo $this->lang->line($faq_category->category_name);?></span>
                <?php } else{?>
                <span><?php echo $this->lang->line('Some')?></span> <?php echo $this->lang->line('FAQ')?>
            <?php } ?>
            </h1>
            <p><?php echo $this->lang->line('Frequently Asked Questions')?></p>
        </div>
        <div class="w900 mx-auto">
            <div class="accordion-list">
            <?php
            if($faq_id):
             $faq_data = $this->common_model->getTableData('xabits_faq',array('status'=>1,'category_id'=>$faq_id))->result();
         else:
              $faq_data = $this->common_model->getTableData('xabits_faq',array('status'=>1))->result();
         endif;
                if($faq_data): $j=0; foreach($faq_data as $faq_da){ $j++; ?>
                <div class="accordion-item">
                    <h5 class="accordion-title">
                        <span><?php echo $faq_da->$question;?></span>
                    </h5>
                    <div class="accordion-content">
                        <p><?php echo $faq_da->$description;?></p>
                    </div>
                </div>
                <?php } endif;?>
            </div>
        </div>
    </div>
</div>





<!-- END SECTION FAQ -->
<?php $this->load->view('front/common/inner_footer');?>
