<?php 
    $this->load->view('front/user/login_header');
    $user_id = $this->session->userdata('user_id');
    $settings = $site_common['site_settings']; 
    $sitelan = $this->session->userdata('site_lang');
    $heading = $sitelan."_heading";
    $meta_description = $sitelan."_meta_description";
    $meta_keywords = $sitelan."_meta_keywords";
    $title = $sitelan."_title";
    $copy_right_text = $sitelan."_copy_right_text";
    $cms_title = $sitelan."_title";
    $content_description = $sitelan."_content_description";
?>
      <section class="container-fluid p-0 mt-5">
         <div class="container">
            <div class="row">
               <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                  <div class="coin-box text-center">
                  <h2><?php echo $cms->$cms_title;?></h2>
                  </div>
                
               </div>
            </div>
         </div>
                  <div class="container">
            <div class="row">
               <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
 <?php echo $cms->$content_description;?>
     </div>
            </div>
         </div>
</section>
   <?php 
    $this->load->view('front/common/footer');
    ?>

