<?php
$user_id=$this->session->userdata('user_id');
$sitelan = $this->session->userdata('site_lang');
$theme_mode = $_COOKIE['theme-mode'];
$currency = $this->common_model->getTableData('currency',array('status'=>'1','type'=>'digital'),'','','','','','', array('sort_order', 'ASC'))->result();
$favicon = $site_common['site_settings']->site_favicon;
$sitelogo = $site_common['site_settings']->site_logo;
$users = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
 $pairs = $this->common_model->getTableData('trade_pairs',array('status'=>'1'),'','','','','','', array('id', 'ASC'))->result();
 $meta_description = $sitelan."_meta_description";
 $meta_keywords = $sitelan."_meta_keywords";
 $title = $sitelan."_title";
 $uri = $this->uri->segment(1);

?>
<!DOCTYPE html>
<html lang="en">

<head>
<!-- Meta -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="xabitschange.nl | Buy / Sell and store your crypto" />
<!-- SITE TITLE -->
<title><?php if($meta_content): echo $meta_content->$title; else: echo 'xabitschange.nl'; endif;?></title>

 <link rel="icon" type="image/png" href="<?php echo $favicon;?>" />

<!-- Animation CSS -->
<link rel="stylesheet" href="<?php echo front_css();?>animate.css" >
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
<link rel="stylesheet" href="<?php echo front_css();?>font-awesome.min.css" >
<link rel="stylesheet" href="<?php echo front_css();?>ionicons.min.css">
<link rel="stylesheet" href="<?php echo front_css();?>owlcarousel/css/owl.carousel.min.css">
<link rel="stylesheet" href="<?php echo front_css();?>owlcarousel/css/owl.theme.default.min.css">
<link rel="stylesheet" href="<?php echo front_css();?>magnific-popup.css">
<link rel="stylesheet" href="<?php echo front_css();?>spop.min.css">
<!-- Style CSS -->
<link rel="stylesheet" href="<?php echo front_css();?>style_home.css">
<link rel="stylesheet" href="<?php echo front_css();?>responsive.css">
<link rel="stylesheet" href="<?php echo front_css();?>dataTables.bootstrap4.min.css">
<!-- Color CSS -->
<link id="layoutstyle" rel="stylesheet" href="<?php echo front_css();?>theme.css">

<link rel="stylesheet" href="https://cdn.datatables.net/1.11.1/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.bootstrap4.min.css">

    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>toastr.min.css" />
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-106310707-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
 gtag('config', 'UA-106310707-1', { 'anonymize_ip': true });
</script>

<!-- Start of StatCounter Code -->
<script>
  <!--
  var sc_project=11921154;
  var sc_security="6c07f98b";
    var scJsHost = (("https:" == document.location.protocol) ?
    "https://secure." : "http://www.");
      //-->
      
document.write("<sc"+"ript src='" +scJsHost +"statcounter.com/counter/counter.js'></"+"script>");
</script>
<noscript><div class="statcounter"><a title="web analytics" href="https://statcounter.com/"><img class="statcounter" src="https://c.statcounter.com/11921154/0/6c07f98b/0/" alt="web analytics" /></a></div></noscript>
<!-- End of StatCounter Code -->

</head>

<body class="v_royal_blue" data-spy="scroll" data-offset="110">


<div class="<?=$class;?>">


<header class="header_wrap fixed-top nav-fixed">
            <div class="container-fluid">
              <nav class="navbar navbar-expand-lg">
                <a class="navbar-brand page-scroll animation" href="<?=base_url()?>" data-animation="fadeInDown" data-animation-delay="1s">
                        <img class="logo_light" src="<?php echo $sitelogo;?>" alt="logo" width="100px">
                          
                      </a>
                      <button class="navbar-toggler animation" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" data-animation="fadeInDown" data-animation-delay="1.1s">
                          <span><i class="fa fa-bars" aria-hidden="true"></i>
          </span>
                      </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                          <ul class="navbar-nav m-auto">
                              <li class="dropdown animation" data-animation="fadeInDown" data-animation-delay="1.1s">
                                <a  class="nav-link page-scroll nav_item" href="<?=base_url('home')?>">Home</a>
                            </li>

                              <li class="animation" data-animation="fadeInDown" data-animation-delay="1.2s"><a class="nav-link page-scroll nav_item" href="<?=base_url('cms/about-us')?>">About Us</a></li>
                             
                              <li class="dropdown animation" data-animation="fadeInDown" data-animation-delay="1.1s">
                                <a  class="nav-link page-scroll nav_item" href="<?=base_url('market')?>">MARKET</a>
                            </li>
                            


                              <li class="dropdown animation" data-animation="fadeInDown" data-animation-delay="1.1s">
                      <a data-toggle="dropdown" class="nav-link dropdown-toggle" href="#">EXCHANGE</a>
                        <div class="dropdown-menu">
                              <ul class="list_none">
                                             <li><a class="dropdown-item nav-link nav_item" href="<?=base_url()?>exchange">Basic</a></li>
                                   <li><a class="dropdown-item nav-link nav_item" href="<?=base_url()?>exchange/#/trade_advance">Advanced</a></li>
                                      </ul>
                                    </div>
                              </li>
 
                          </ul>
                          <ul class="navbar-nav nav_btn align-items-center">
                             
                                                   <?php
                                if(isset($user_id) && !empty($user_id)){
                                ?>
                    <li class="animation" data-animation="fadeInDown" data-animation-delay="1.4s"><a class="nav-link page-scroll nav_item" href="<?php echo base_url();?>dashboard">Dashboard</a></li>
                    <li class="animation" data-animation="fadeInDown" data-animation-delay="1.5s"><a class="nav-link page-scroll nav_item" href="<?php  echo base_url();?>logout">Logout </a></li>
                    <?php } else { ?>
                    <li class="animation" data-animation="fadeInDown" data-animation-delay="1.6s"><a class="btn btn-default btn-radius nav_item" href="<?php echo base_url();?>signup">Register</a></li>
                     <li class="animation" data-animation="fadeInDown" data-animation-delay="1.7s"><a class="btn btn-default btn-radius nav_item" href="<?php echo base_url();?>login">Login</a></li>
                    <?php } ?>
                                              </ul>

                </div>
              </nav>
            </div>
          </header>
</div>          