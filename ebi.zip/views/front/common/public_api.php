<?php $this->load->view('front/common/inner_header');
$lang_id = $this->session->userdata('site_lang');
$user_id = $this->session->userdata('user_id');
// $content = $sitelan."_content";
// echo 'lang '.$sitelan;
// echo $home_section->$sitelan.'_content';
if($lang_id!=''){
//$title = $lang_id.'_name';
$question = $lang_id.'_question';
$description = $lang_id.'_description';
}else{
//$title = $site_lang.'_name';
$question = $site_lang.'_question';
$description = $site_lang.'_description';
}
// echo $faq_id;
?>

<style type="text/css">
    
 .sec-title 
 {
    margin-bottom: 14px !important;
 }   
.nav-pills .nav-link.active, .nav-pills .show>.nav-link
{
  color: #fff;  
}
.nav-pills-custom a.nav-link
{
  color: #000 !important;
}
.card-body a
{
  color: #fff;
  font-weight: bold;
}
</style> 

<!-- START SECTION FAQ -->
<div class="pb-50">
    <div class="container">
        <div class="sec-title text-center">
            <h1 data-watermark="">
               
                    <span>Public Api</span>
                
             
            </h1>
            <p>Public Api</p>
        </div>
        
        <div class="container-xl">
        <div class="row">

         <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-2">
            <!-- Tabs nav -->
            <div class="nav flex-column nav-pills nav-pills-custom" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                <a class="nav-link mb-3 p-3 shadow active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="false">

                    <span class="font-weight-bold small text-uppercase">Assets</span></a>

                <a class="nav-link mb-3 p-3 shadow" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">

                    <span class="font-weight-bold small text-uppercase">Order Book</span></a>

                <a class="nav-link mb-3 p-3 shadow" id="v-pills-messages-tab" data-toggle="pill" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false">

                    <span class="font-weight-bold small text-uppercase">Ticker Info</span></a>

                <a class="nav-link mb-3 p-3 shadow" id="v-pills-settings-tab" data-toggle="pill" href="#v-pills-settings" role="tab" aria-controls="v-pills-settings" aria-selected="false">

                    <span class="font-weight-bold small text-uppercase">Trade History</span></a>

                <a class="nav-link mb-3 p-3 shadow " id="v-pills-settings-tab" data-toggle="pill" href="#v-pills-pairs" role="tab" aria-controls="v-pills-settings" aria-selected="true">

                  <span class="font-weight-bold small text-uppercase">Trade Pairs</span></a>

                </div>
        </div>

        <div class="col-md-9">
            <!-- Tabs content -->
            <div class="tab-content" id="v-pills-tabContent" style="/* height: 350px; */overflow: auto;">
                <div class="tab-pane fade shadow bg-white active show" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                    <div class="card-header" style="display: block;padding: 10px;">
                        <h3 class="card-title" style="    color: #001a5b;">xabits - Rest Api</h3>
                        <p style="color: black;"> xabits provides API solutions for automated trading based on needs of individuals and institutions.</p>
                      </div>
                    <div class="col-md-12">
                        <div class="card-trans">
                         <div class="card-body" style="    padding: 0.25rem;">
                         <h3 style="color: black;">Read all available assets from xabits exchange
                        </h3>
                        <pre style="margin: 0;"><i class="fa fa-circle"></i> 200 OK</pre>
                        <p></p>
                        <p></p>

                        <?php
                        $url_rev =  base_url()."api/v1/assets";
                        $jsonData = json_decode(file_get_contents(base_url()."api/v1/assets"), true);
                        ?>

                        <pre style="background-color: #2D2D2D;padding: 20px 0px 25px 50px;"><font color="#fff">--request GET \  <code>
                          <a href="<?php echo base_url();?>api/v1/assets" target="_blank"><?php echo base_url();?>api/v1/assets</a></code><br><br><code>Sample response :

                          <?php
                          echo "<pre>";
                          print_r($jsonData);
                          echo "<pre>";
                        ?>

                                                      </code></font>
                                                     </pre>
                          </div>
                        </div>
                      </div>




                </div>

                <div class="tab-pane fade shadow rounded bg-white" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
                  <div class="card-header" style="display: block;padding: 10px;">
                    <h3 class="card-title" style="color: #001a5b;">xabits - Rest Api</h3>
                    <p style="color: black;"> xabits provides API solutions for automated trading based on needs of individuals and institutions.</p>
                  </div>
                <div class="col-md-12">
                    <div class="card-trans">
                     <div class="card-body" style="    padding: 0.25rem;">
                     <h3 style="color: black;">Lists orders for provided pair
                    </h3>

                    <pre style="margin: 0;"><i class="fa fa-circle"></i> 200 OK</pre>
                    <p></p>
                    <p></p>
                     <?php
                        $listorders = json_decode(file_get_contents(base_url()."api/v1/orderbook/BTC_EUR"), true);
                        ?>

                    <pre style="background-color: #2D2D2D;padding: 20px 0px 25px 50px;"><font color="#fff">--request GET \  <code> <a href="<?php echo base_url();?>api/v1/orderbook/BTC_EUR" target="_blank"><?php echo base_url();?>api/v1/orderbook/BTC_EUR</a></code><br><br><code>Sample response :
                      
                      <?php
                          echo "<pre>";
                          print_r($listorders);
                          echo "<pre>";
                      ?>

                  </code></font>
                                                 </pre>
                      </div>

                    </div>
                  </div>
                      </div>


                        <div class="tab-pane fade shadow rounded bg-white" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
                            <div class="tab-pane fade shadow  bg-white show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                              <div class="card-header" style="display: block;padding: 10px;">
                                <h3 class="card-title" style="    color: #001a5b;">xabits - Rest Api</h3>
                                <p style="color: black;">  xabits provides API solutions for automated trading based on needs of individuals and institutions.</p>
                              </div>
                            <div class="col-md-12">
                                <div class="card-trans">
                                 <div class="card-body" style="    padding: 0.25rem;">
                                 <h3 style="color: black;">The ticker api is to provide a 24-hour pricing and volume summary for each market pair available on the exchange.</h3>

                                <pre style="margin: 0;"><i class="fa fa-circle"></i> 200 OK</pre>
                                <p></p>
                                <p></p>
                                <pre style="background-color: #2D2D2D;padding: 20px 0px 25px 50px;"><font color="#fff">--request GET \  <code><a  href="<?php echo base_url();?>api/v1/ticker" target="_blank"><?php echo base_url();?>api/v1/ticker</a></code><br><br><code>
                                  <?php
                        $tickers = json_decode(file_get_contents(base_url()."api/v1/ticker"), true);
                        ?>

        Sample response :
        <?php
            echo "<pre>";
            print_r($tickers);
            echo "<pre>";
        ?>
          

                                                              </code></font>
                                                             </pre>
                                  </div>
                                  <div class="card-body" style="    padding: 0.25rem;">
                                    <h3 style="color: black;">The ticker api is to provide a 24-hour pricing and volume summary for single pair available on the exchange.</h3>

                                   <pre style="margin: 0;"><i class="fa fa-circle"></i> 200 OK</pre>
                                   <p></p>
                                   <p></p>
                                   <pre style="background-color: #2D2D2D;padding: 20px 0px 25px 50px;"><font color="#fff">--request GET \  <code><a href="<?php echo base_url();?>api/v1/ticker" target="_blank"><?php echo base_url();?>api/v1/ticker</a></code><br><br><code>

        Sample response :

           <?php
            echo "<pre>";
            print_r($tickers);
            echo "<pre>";
        ?>

                                                                 </code></font>
                                                                </pre>
                                     </div>
                                </div>
                              </div>




                            </div>



                        </div>

                        <div class="tab-pane fade shadow rounded bg-white" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">
                            <div class="tab-pane fade shadow  bg-white show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                              <div class="card-header" style="display: block;padding: 10px;">
                                <h3 class="card-title" style="    color: #001a5b;">xabits - Rest Api</h3>
                                <p style="color: black;"> xabits provides API solutions for automated trading based on needs of individuals and institutions.</p>
                              </div>
                            <div class="col-md-12">
                                <div class="card-trans">
                                 <div class="card-body" style="    padding: 0.25rem;">
                                 <h3 style="color: black;">Lists orders for provided pair. </h3>
                                <pre style="margin: 0;"><i class="fa fa-circle"></i> 200 OK</pre>
                                <p></p>
                                <p></p>
                                <pre style="background-color: #2D2D2D;padding: 20px 0px 25px 50px;"><font color="#fff">--request GET \  <code><a href="<?php echo base_url();?>api/v1/trades/BTC_EUR" target="_blank"><?php echo base_url();?>api/v1/trades/BTC_EUR</a></code><br><br><code>
                                  
                                  <?php
                                    $trades = json_decode(file_get_contents(base_url()."api/v1/trades/BTC_EUR"), true);
                                    ?>
      Sample response :

               <?php
            echo "<pre>";
            print_r($trades);
            echo "<pre>";
            ?>

                                                              </code></font>
                                                             </pre>
                                  </div>
                                </div>
                              </div>




                            </div>

                        </div>

                        <div class="tab-pane fade shadow rounded bg-white " id="v-pills-pairs" role="tabpanel" aria-labelledby="v-pills-settings-tab">
                          <div class="tab-pane fade shadow  bg-white show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                            <div class="card-header" style="display: block;padding: 10px;">
                              <h3 class="card-title" style="    color: #001a5b;">xabits - Rest Api</h3>
                              <p style="color: black;"> xabits provides API solutions for automated trading based on needs of individuals and institutions.</p>
                            </div>
                          <div class="col-md-12">
                              <div class="card-trans">
                               <div class="card-body" style="    padding: 0.25rem;">
                               <h3 style="color: black;">Read all available trade pairs from xabits exchange
                              </h3>
                              <pre style="margin: 0;"><i class="fa fa-circle"></i> 200 OK</pre>
                              <p></p>
                              <p></p>
                              <pre style="background-color: #2D2D2D;padding: 20px 0px 25px 50px;"><font color="#fff">--request GET \  <code><a href="<?php echo base_url();?>api/v1/trade_pairs" target="_blank"><?php echo base_url();?>api/v1/trade_pairs</a></code><br><br><code>
                                 <?php
                                    $pairss = json_decode(file_get_contents(base_url()."api/v1/trade_pairs"), true);
                                    ?>


            Sample response :

                     <?php
                     echo "<pre>";
                     print_r($pairss); 
                     echo "<pre>";
                     ?>

                                                            </code></font>
                                                           </pre>
                                </div>
                              </div>
                            </div>




                          </div>

                      </div>

                        </div>
            </div>
        </div>
        </div>
        </div>
        </div>



    </div>
</div>





<!-- END SECTION FAQ -->
<?php $this->load->view('front/common/inner_footer');?>
