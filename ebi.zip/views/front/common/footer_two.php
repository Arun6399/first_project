<?php
$user_id=$this->session->userdata('user_id');
$site_common = site_common();
?>
<footer class="bg-secondary-gradient">
    <div class="footer-sec pt-50">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 py-4">
                    <div class="footer-widget">
                        <a href="#" class="footer-logo mb-4">
                            <img src="assets/img/logo-white.svg" alt="">
                        </a>
                        <p><?php echo $footer->english_content;?></p>
                        <div class="social-icons">
                            <a href="<?php echo $site_common['site_settings']->facebooklink; ?>">
                                <i class="icofont-facebook"></i>
                            </a>
                            <a href="<?php echo $site_common['site_settings']->twitterlink; ?>">
                                <i class="icofont-twitter"></i>
                            </a>
                            <a href="<?php echo $site_common['site_settings']->instagram_link; ?>">
                                <i class="icofont-instagram"></i>
                            </a>
                            <a href="<?php echo $site_common['site_settings']->youtube_link; ?>">
                                <i class="icofont-youtube-play"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 py-4">
                    <div class="footer-widget">
                        <h4 class="footer-widget-title"><?php echo $this->lang->line('Sitemap')?></h4>
                        <ul class="footer-widget-menu column-2">
                            <li><a href="<?php echo base_url();?>cms/about-us"><?php echo $this->lang->line('About')?></a></li>
                            <li><a href="<?=base_url('trade')?>"><?php echo $this->lang->line('Buy / Sell')?></a></li>
                            <li><a href="<?=base_url('currency_calculation')?>"><?php echo $this->lang->line('Calculator')?></a></li>
                            <!-- <li><a href="roadmap.html">Roadmap</a></li> -->
                            <!-- <li><a href="team.html">Team</a></li>
                            <li><a href="blog.html">Blog</a></li> -->
                            <li><a href="<?php echo base_url();?>contact_us"><?php echo $this->lang->line('Contact')?></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-2 col-sm-6 py-4">
                    <div class="footer-widget">
                        <h4 class="footer-widget-title"><?php echo $this->lang->line('Link')?></h4>
                        <ul class="footer-widget-menu mb-4">
                            <li><a href="<?php echo base_url();?>faq"><?php echo $this->lang->line('FAQ')?></a></li>
                            <li><a href="<?php echo base_url();?>cms/terms-and-conditions"><?php echo $this->lang->line('Terms & Conditions')?></a></li>
                            <li><a href="<?php echo base_url();?>cms/privacy-policy"><?php echo $this->lang->line('Privacy Policy')?></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 py-4 col-md-6">
                    <div class="footer-widget">
                        <h4 class="footer-widget-title"><?php echo $this->lang->line('Newsletter')?></h4>
                        <p><?php echo $this->lang->line('Subscribe our newsletter for get Update')?></p>
                        <div class="newsletter-widget mb-4">
                            
                                <?php
                        $action = base_url().'reg_subscribe';
                        $attributes = array('id'=>'subscribe_form',"method"=>"post"); 
                        echo form_open_multipart($action,$attributes);
                    ?>
                            <input type="email" placeholder="<?php echo $this->lang->line('Enter Your Email Address')?>" name="email">
                            <input type="submit" value="<?php echo $this->lang->line('Send')?>">
                       <?php echo form_close();?>
                       
                        </div>
                        <div id="email-error" class="error"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="copyright-sec border-top border-white">
        <div class="container">
            <div class="copyright-inner text-center d-block">
                <p><?php echo $this->lang->line('Copyright © 2021 Cripyic All Rights Reserved.')?></p>
            </div>
        </div>
    </div>
</footer>


    <script src="<?php echo front_js();?>home_two/app.min.js"></script>
    <script src="<?php echo front_js();?>home_two/scripts.js"></script>
    <script src="<?php echo front_js();?>jquery.validate.min.js"></script>
    <script src="<?php echo base_url();?>assets/front/js/toastr.min.js"></script>     

 

<script type="text/javascript">        
    function choose_lang(obj){
        var selct_lang = obj.value; 
                window.location.href="<?php echo base_url()?>switchLang/"+selct_lang;
    }
    </script>
    <script>
   
        $("#subscribe_form").validate({
             rules: {
            email: {
                required: true,
                email:true
            },
        },
        messages: {
            email: {
                required:"Please enter email address",
                email: "Please enter valid email address",
                remote: "Entered Email Address Already Exists"
            }
        },
        errorElement : 'div',
    errorLabelContainer: '#email-error'
        
        });
  </script>
  <script type="text/javascript">
      var success = "<?php echo $this->session->flashdata('success')?>";
var error = "<?php echo $this->session->flashdata('error')?>";
$(document).ready(function() {
if(success!=''){
    toastr.success('Cripyic! '+success);
}
if(error!=''){
    toastr.error('Cripyic! '+error);
}
});
  </script>
<style type="text/css">
    .error{
   color: red;
 }
</style>
</body>

</html>