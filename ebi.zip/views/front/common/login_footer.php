       <div class="footer">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-xl-6 col-md-6">
                        <div class="copy_right">
                            Copyright © 2022 xabits. All Rights Reserved.
                        </div>
                    </div>
                    <div class="col-xl-6 col-md-6 text-lg-right text-center">
                        <div class="social">
                            <a href="#"><i class="fa fa-youtube-play"></i></a>
                            <a href="#"><i class="fa fa-instagram"></i></a>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                            <a href="#"><i class="fa fa-facebook"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--**********************************
            Right sidebar end
        ***********************************-->
        <!--endRemoveIf(production)-->
    

<script src="<?php echo front_js();?>jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/front/js/toastr.min.js"></script>

<!--bootstrap-->
<script src="<?php echo front_js();?>bootstrap.min.js"></script>
<!-- <script src="https://cheaphostings.net/html/tf/coincap-demo/coincap/assets/js/particles.min.js"></script> -->
<script src="https://cheaphostings.net/html/tf/coincap-demo/coincap/assets/js/app.js"></script>
<!-- jQuery Custom Scroller CDN -->
<!-- <script src="<?php echo front_js();?>jquery.mCustomScrollbar.concat.min.js"></script> -->
<script type="text/javascript">
    $(document).ready(function () {
        // $("#sidebar").mCustomScrollbar({
        //     theme: "minimal"
        // });
        $('#sidebarCollapse').on('click', function () {
            $('#sidebar, #content').toggleClass('active');
            // $('.collapse.in').toggleClass('in');
            // $('a[aria-expanded=true]').attr('aria-expanded', 'false');
        });
    });
</script>

<script type="text/javascript">        
        $(".lang_switch").on('change',function(){
            var selct_lang = $(this).val(); 
                window.location.href="<?php echo base_url()?>switchLang/"+selct_lang;
        });
    </script>



    <!-- <script src="<?php echo front_js();?>bootstrap.bundle.min.js"></script> -->
    <!-- <script src="<?php echo front_js();?>waves.min.js"></script> -->


       <!-- <script src="<?php echo front_js();?>scripts.js"></script> -->

<!--datatables-->
<script type="text/javascript" src="https://cdn.datatables.net/w/bs4/dt-1.10.18/datatables.min.js"></script>

<script src="<?php echo front_js();?>jquery-3.2.1.min.js"></script>
<script src="<?php echo front_js();?>jquery.validate.min.js"></script>


<script type="text/javascript">

var base_url='<?php echo base_url();?>';
var front_url='<?php echo front_url();?>';
var user_id='<?php echo $user_id;?>';
var ip_address = '<?php echo $ip_address;?>';
var get_os     = '<?php echo $get_os;?>';
var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';
var success = "<?php echo $this->session->flashdata('success')?>";
var error = "<?php echo $this->session->flashdata('error')?>";
if(success!=''){
    toastr.success('xabits! '+success);

}
if(error!=''){
toastr.error('xabits! '+error);
}


</script>



</body>

</html>