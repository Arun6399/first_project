<?php $this->load->view('front/common/header');
$lang_id = $this->session->userdata('site_lang');
$user_id = $this->session->userdata('user_id');
// $content = $sitelan."_content";
// echo 'lang '.$sitelan;
// echo $home_section->$sitelan.'_content';
if($lang_id!=''){
$title = $lang_id.'_name';
$content = $lang_id.'_content';
$question = $lang_id.'_question';
$description = $lang_id.'_description';
}else{
$title = $site_lang.'_name';
$content = $site_lang.'_content';
$question = $site_lang.'_question';
$description = $site_lang.'_description';
}
?>
<style>
div.dataTables_wrapper div.dataTables_paginate{
        margin-top: 10px; 
}
</style>
<!-- END HEADER --> 

<!-- START SECTION BANNER -->
<section id="home_section" class="section_banner gradient_box2 pb-0" data-image-src="<?php echo front_img();?>banner_bg3.png" data-parallax="scroll" data-z-index="1">
    <div id="banner_bg_effect" class="banner_effect"></div>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 col-md-12 col-sm-12 order-lg-first">
                <div class="banner_text text_md_center">
                <?php echo $home_section->$content;?>
                    <div class="btn_group animation" data-animation="fadeInUp" data-animation-delay="1.4s"> 
                    <?php if(empty($user_id)) { ?> 
                        <a href="<?=base_url()?>signup" class="btn btn-border-white btn-radius">GET STARTED<i class="ion-ios-arrow-thin-right"></i></a> 
                    <?php }else{?>
                        <a href="<?=base_url()?>dashboard" class="btn btn-border-white btn-radius">GET STARTED<i class="ion-ios-arrow-thin-right"></i></a> 
                    <?php }  ?>
                                        </div>
                   
                </div>
            </div>
            <div class="col-lg-6 col-md-12 col-sm-12 order-first">
                <div class="banner_image_right res_md_mb_50 res_xs_mb_20 animation" data-animation-delay="1.5s" data-animation="fadeInRight">
                    <img alt="banner_vector6" src="<?php echo $home_section->image;?>">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="divider small_divider"></div>
            </div>
        </div>
     
    </div>
</section>
<!-- END SECTION BANNER --> 

<!-- START SECTION TOKEN SALE -->
<section id="token" class="section_token">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 offset-lg-3 col-md-12 col-sm-12">
                <div class="title_default_light text-center">
                    <h4 class="animation" data-animation="fadeInUp" data-animation-delay="0.2s">Live Coin Chart</h4>
                    <!-- <p class="animation" data-animation="fadeInUp" data-animation-delay="0.4s"><?php echo $token->english_content;?></p> -->
                </div>
            </div>
        </div>
        <div class="row align-items-center small_space">
            <div class="col-xl-12 col-lg-5 col-md-12">
                <div class="token_info_table_s2 h-100" style="color:#fff;">
                    <table class="table table-blue m-0 h-100" id="coin_table">
                        <thead>
                                        <tr>
                                            <!-- <th></th> -->
                                            <th>Name</th>
                                            <th>Last Price</th>
                                            <th>24H Change</th>
                                            <th>24H High</th>
                                            <th>24H Low</th>
                                            <th>Volume</th>
                                        </tr>
                                    </thead>
                        <tbody>
                            <?php
                                if(isset($pairs) && !empty($pairs)){   foreach($pairs as $pair_details){

                                    $from_currency = $this->common_model->getTableData('currency',array('id' => $pair_details->from_symbol_id))->row();
                                    $to_currency = $this->common_model->getTableData('currency',array('id' => $pair_details->to_symbol_id))->row();
                                    $pair_symbol = $from_currency->currency_symbol.'/'.$to_currency->currency_symbol;
                                    $pair_url = $from_currency->currency_symbol.'_'.$to_currency->currency_symbol;
                                    $currency = getcryptocurrencydetail($from_currency->id);
                                    if(isset($from_currency) && isset($to_currency)){?>
                            <tr class="animation" data-animation="fadeInUp" data-animation-delay="0.2s">
                              <td><img src="<?php echo $currency->image;?>" style="height: 50px;width: 50px;" alt="" class="table-cryp"> <?=$pair_symbol?></td>
                              <td><?php echo TrimTrailingZeroes($pair_details->lastPrice);?> </td> 
                              <td><span class="<?php echo($pair_details->priceChangePercent>0)?'grn':'rdn';?>"><?php echo number_format($pair_details->priceChangePercent,2);   ?>%</span></td>
                              <td><?php echo TrimTrailingZeroes($pair_details->change_high);?></td>
                              <td><?php echo TrimTrailingZeroes($pair_details->change_low);?></td>
                              <td><?php echo TrimTrailingZeroes($pair_details->volume);?></td>

                            </tr>
                            <?php }} }?>
                                        
                         </tbody>
                    </table>
                </div>
            </div>
            
           
        </div>
    </div>
</section>
<!-- END SECTION TOKEN SALE --> 

<!-- START SECTION SERVICES -->
<section id="service" class="gradient_box2">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8 offset-lg-2 col-md-12 col-sm-12">
                <div class="title_default_light title_border text-center">
                  <!-- <h4 class="animation" data-animation="fadeInUp" data-animation-delay="0.2s">
                    <?php echo $services->$title;?></h4> -->
                  <?php echo $services->$content;?>
                </div>
            </div>
        </div>
        <div class="row">
            <?php 
              foreach($service as $services){
            ?>
            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="box_wrap text-center box_shadow_none p-0 animation" data-animation="fadeInUp" data-animation-delay="0.2s">
                <img src="<?php echo $services->image;?>">
                    <!-- <h4><?php echo $services->$title;?></h4> -->
                    <?php echo $services->$content;?>
                </div>
            </div>
        <?php }?>
         </div>
    </div>
</section>
<!-- END SECTION SERVICES --> 



<!-- SECTION MOBILE APP -->
<section id="mobileapp" class="gradient_box2">
    <div class="container">
        <div class="row">   
            <div class="col-lg-8 offset-lg-2">
                <div class="title_default_light text-center">
                   <!--  <h4 class="animation" data-animation="fadeInUp" data-animation-delay="0.2s"><?php echo $mobile->$title;?></h4> -->
                    <?php echo $mobile->$content;?>
                  </div>
            </div>
        </div>
        <div class="row align-items-center small_space">
            <div class="col-lg-4 col-md-12 col-sm-12">
                <div class="res_md_mt_40 res_md_mb_40 res_sm_mt_20 res_sm_mb_20 text-center animation" data-animation="zoomIn" data-animation-delay="0.2s"> 
                    <img class="bounceimg" src="<?php echo $mobile->image;?>" alt="mobile_app5"/> 
                </div>
            </div>
            <div class="col-lg-8">
                <div class="row">
                    <div class="col-md-6">
                        <ul class="list_none app_content">
                             <?php 
                                 foreach($mobiles as $mobile){
                                ?>
                            <li class="animation" data-animation="fadeInUp" data-animation-delay="0.4s">
                               
                                <div class="app_icon">
                                   <img src="<?php echo $mobile->image;?>">
                                </div>
                                <div class="app_desc">
                                    <!-- <h6><?php echo $mobile->$title;?></h6> -->
                                    <?php echo $mobile->$content;?>
                                </div>
                            </li>
                            <?php }?>
                         </ul>
                    </div>
                    <div class="col-md-6">
                        <ul class="list_none app_content">
                           
                            <li class="animation" data-animation="fadeInUp" data-animation-delay="0.4s">
                                 <?php 
                              foreach($mobiles1 as $mobile){
                            ?>
                                <div class="app_icon">
                                <img src="<?php echo $mobile->image;?>"> 
                                </div>
                                <div class="app_desc">
                                    <!-- <h6><?php echo $mobile->$title;?></h6> -->
                                    <?php echo $mobile->$content;?>
                                </div>
                                 <?php }?> 
                            </li>
                          
                        </ul>
                    </div>
                </div>
                <!-- <div class="row">
                    <div class="col-md-12">
                        <div data-animation-delay="0.8s" data-animation="fadeInUp" class="btn_group text_md_center mt-4 pt-2 mt-lg-0 pt-lg-0 animation"> 
                            <a class="btn btn-default btn-radius" href="#"><em class="ion-social-android"></em>Google Store </a> 
                            <a class="btn btn-default btn-radius" href="#"><em class="ion-social-apple"></em>Apple Store</a> 
                        </div>
                    </div>
                </div> -->
            </div>
        </div>
    </div>
</section>
<!-- END SECTION MOBILE APP --> 
<section id="faq" class="blue_bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-12 offset-lg-2">
              <div class="title_default_light text-center">
                <h4 class="animation" data-animation="fadeInUp" data-animation-delay="0.2s"><?php echo $this->lang->line('Frequently Asked Questions')?></h4>
                <p class="animation" data-animation="fadeInUp" data-animation-delay="0.4s"><?php echo $this->lang->line('Frequently asked questions (FAQ) or Questions and Answers (Q&A), are listed questions and answers, all supposed to be commonly asked in some context')?></p>
              </div>
            </div>
        </div>
        <?php if($faq_category):?>
        <div class="row small_space">
            <div class="col-lg-3 col-md-12">
                <ul class="nav nav-pills d-block tab_s2" id="pills-tab" role="tablist">
                    <?php $i=0; foreach($faq_category as $faq_cat){$i++;?>
                      <li class="nav-item animation" data-animation="fadeInUp" data-animation-delay="0.<?=$i+5?>s">
                        <a class="tab-link <?=($i==1)?'active':''?>" data-toggle="tab" href="#tab<?=$i?>"><?=$faq_cat->category_name?></a>
                      </li>
                      <?php } ?>
                    </ul>
            </div>
            <div class="col-lg-9 col-md-12">
                <div class="tab-content res_md_mt_30 res_sm_mt_20">
                <?php $i=0; foreach($faq_category as $faq_cat){ $i++;?>
                    <div class="tab-pane fade show <?=($i==1)?'active':''?>" id="tab<?=$i?>" role="tabpanel">
                        <div id="accordion<?=$i?>" class="faq_content2">
                        <?php $faq_data = $this->common_model->getTableData('xabits_faq',array('category_id'=>$faq_cat->id))->result();
                           if($faq_data): $j=0; foreach($faq_data as $faq_da){ $j++; ?>
                            <div class="card animation" data-animation="fadeInUp" data-animation-delay="0.<?=$j*2?>s">
                              <div class="card-header" id="heading<?=$j?>">
                                <h6 class="mb-0"> <a data-toggle="collapse" href="#collapse<?=$i.$j?>" aria-expanded="<?=($j==1)?'true':'false'?>" aria-controls="collapse<?=$j?>"><?php echo $faq_da->$question;?></a> </h6>
                              </div>
                              <div id="collapse<?=$i.$j?>" class="collapse <?=($j==1)?'show':''?>" aria-labelledby="heading<?=$j?>" data-parent="#accordion<?=$i?>">
                                <div class="card-body"><?php echo $faq_da->$description;?></div>
                              </div>
                            </div>
                            <?php } endif;?>
                      </div>
                    </div>
                    <?php } ?>
                </div>
            </div> 
        </div>
        <?php endif;?>
    </div>
</section>
<!-- END SECTION FAQ -->

<?php  $this->load->view('front/common/footer');?>
