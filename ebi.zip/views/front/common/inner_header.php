<?php
$user_id=$this->session->userdata('user_id');
$sitelan = $this->session->userdata('site_lang');
$sitehome = $this->session->userdata('site_home');
$theme_mode = $_COOKIE['theme-mode'];
$currency = $this->common_model->getTableData('currency',array('status'=>'1','type'=>'digital'),'','','','','','', array('sort_order', 'ASC'))->result();
$favicon = $site_common['site_settings']->site_favicon;
$sitelogo = $site_common['site_settings']->site_logo;
$users = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
$meta_description = $sitelan."_meta_description";
$meta_keywords = $sitelan."_meta_keywords";
$title = $sitelan."_title";
?>
<!DOCTYPE html>
<html class="no-js" lang="zxx">
<!-- Mirrored from electronthemes.com/html/cryptohouse/token.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 28 Jul 2021 13:07:05 GMT -->
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="icon" type="image/png" href="<?php echo $favicon;?>" />

    <title><?php if($meta_content): echo $meta_content->$title; else: echo 'xabits'; endif;?></title>
    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>home_two/base-style.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>home_two/style.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>toastr.min.css" />
    <link rel="stylesheet" href="<?php echo front_css();?>style_home.css">
    <link rel="stylesheet" href="<?php echo front_css();?>ionicons.min.css">
    <link rel="stylesheet" href="<?php echo front_css();?>font-awesome.min.css" >



</head>


<!-- <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="icon" type="image/png" href="<?php echo $favicon;?>" />

    <title><?php if($meta_content): echo $meta_content->$title; else: echo 'xabits'; endif;?></title>
  <link rel="stylesheet" href="<?php echo front_css();?>animate.css" >
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
<link rel="stylesheet" href="<?php echo front_css();?>font-awesome.min.css" >
<link rel="stylesheet" href="<?php echo front_css();?>ionicons.min.css">
<link rel="stylesheet" href="<?php echo front_css();?>owlcarousel/css/owl.carousel.min.css">
<link rel="stylesheet" href="<?php echo front_css();?>owlcarousel/css/owl.theme.default.min.css">
<link rel="stylesheet" href="<?php echo front_css();?>magnific-popup.css">
<link rel="stylesheet" href="<?php echo front_css();?>spop.min.css">
<link rel="stylesheet" href="<?php echo front_css();?>style_home.css">
<link rel="stylesheet" href="<?php echo front_css();?>responsive.css">
<link rel="stylesheet" href="<?php echo front_css();?>dataTables.bootstrap4.min.css">
<link id="layoutstyle" rel="stylesheet" href="<?php echo front_css();?>theme.css">

<link rel="stylesheet" href="https://cdn.datatables.net/1.11.1/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.bootstrap4.min.css">

    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>toastr.min.css" />


</head> -->

<body >


<!-- <div class="ch-preloader-sec">
    <div id="ch-preloader">

        <div id="chp-top" class="mask">
        <div class="plane"></div>
        </div>
        <div id="chp-middle" class="mask">
        <div class="plane"></div>
        </div>

        <div id="chp-bottom" class="mask">
        <div class="plane"></div>
        </div>
        
        <p><i>LOADING...</i></p>
        
    </div>
</div> -->
<div class="innerpage-header-sec<?=($sitehome=='home' || $sitehome=='')?'-home':'-home-2'?> header-one">
<?php $this->load->view('front/common/nav_menu_two');?> 
</div>