<?php
    $this->load->view('front/common/header');
    $user_id = $this->session->userdata('user_id');
     $all_currency = $this->common_model->getTableData("currency",array("status"=>1))->result();
      if(count($all_currency))
      {
        $tot_balance = 0;
        foreach($all_currency as $cur)
        {
            $balance = getBalance($user_id,$cur->id);
            $usd_balance = $balance * $cur->online_usdprice;

            $tot_balance += $usd_balance;
        }
      }
?>
<link rel="stylesheet" type="text/css" href="<?php echo front_css();?>innerpage.css">

      <section class="container-fluid p-0"  >
         <div class="header-bg" style="
            border-top-style:solid;
            border-width: 6px;
            border-image: conic-gradient(#cf7b29, purple, lime, DarkSlateBlue, blue,#e4bb00 , #cf7b29) 1;
            " >
            <span class="bubble"></span>
            <div class="container">
               <!-- ---------------------header content---------------------------- -->
               <div class="row">
                  <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 mt-3">
                     <div class="navbar breadcrumb-bar">
                        <nav aria-label="breadcrumb">
                           <ol class="breadcrumb">
                              <li class="breadcrumb-item"><a href="<?php echo base_url();?>"><?php echo $this->lang->line('Home'); ?></a></li>
                              <li class="breadcrumb-item active" aria-current="page"><?php echo $this->lang->line('COIN'); ?></li>
                           </ol>
                        </nav>
                     </div>
                  </div>
               </div>
               <!-- ---------------------header content end---------------------------- -->
            </div>
         </div>
      </section>



  <section class="container-fluid p-0 login-warp innerpage-warp">
    <div class="container">
        <div class="row">
          <?php
          $i=1;
           if(count($allcurrency)>0) { foreach($allcurrency as $currency) { ?>
                  <div class="col-md-6 col-lg-3">
                     <div class="job-item">
                        <div class="item-overlay">
                           <div class="job-info">
                              
                              <span class="tr-title">
                                 <a><?php echo $currency->currency_name;?></a>
                                
                              </span>
                              <ul class="tr-list job-meta">
                                
                               
                                 <li><i class="fa fa-money" aria-hidden="true"></i><strong>Value:</strong> <?php echo $currency->online_usdprice;?></li>
                              </ul>
                            <ul class="job-social tr-list">
                                 <li><a href="javascript:;"  data-toggle="modal" data-target="#<?php echo $currency->currency_symbol;?>" data-dismiss="modal" aria-label="Close"><i class="fa fa-envelope" aria-hidden="true"></i></a></li>
                                 
                              </ul>
                           </div>                              
                        </div>
                        <div class="job-info">
                           <div class="company-logo">
                              <img src="<?php echo $currency->image;?>" alt="images" class="img-fluid">
                           </div>
                           <div class="tr-title">
                              <a ><?php echo $currency->currency_name;?></a>
                             
                           </div>
                           <ul class="tr-list job-meta">
                             
                    
                              <li><span><i class="fa fa-money" aria-hidden="true"></i></span><strong>Value:</strong> <?php echo $currency->online_usdprice;?></li>
                           </ul>
                                                                                     
                        </div>
                     </div>
                  </div>


<!--Coin Details -->
<div class="modal fade right" id="<?php echo $currency->currency_symbol;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true"> 

  <div class="modal-dialog modal-full-height modal-right iks-popup" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title w-100" id="myModalLabel"><?php echo $this->lang->line('Coin Details');?></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
      </div>
      <div class="modal-body">
        <div class="col-sm-12">
              <div class="row">
                 <div class="job-info">

                  <div class="company-logo">
                              <img src="<?php echo $currency->image;?>" alt="images" class="img-fluid">
                           </div>

       <ul  class="tr-list job-meta" style="font-weight: bold;">

                  <li style="font-size: 16px;"> <i class="fa fa-money" aria-hidden="true"></i> <?php echo $this->lang->line('Currency')?> : <?php echo $currency->currency_name;?></li>
                  <li style="font-size: 16px;"> <i class="fa fa-money" aria-hidden="true"></i> <?php echo $this->lang->line('Coin Symbol')?> : <?php echo $currency->currency_symbol;?></li>
                  <li style="font-size: 16px;"> <i class="fa fa-money" aria-hidden="true"></i> <?php echo $this->lang->line('Type')?> : <?php echo ucfirst($currency->type);?></li>
                  <li style="font-size: 16px;"> <i class="fa fa-money" aria-hidden="true"></i> <?php echo $this->lang->line('ASSET')?> : <?php echo ucfirst($currency->coin_type);?></li>
                  <li style="font-size: 16px;"> <i class="fa fa-money" aria-hidden="true"></i>  <?php echo $this->lang->line('Value in USD')?> : <?php echo $currency->online_usdprice;?></li>

                </ul>
                </div>

              </div>
            </div>
       </div>
    
    </div>
  </div>
</div>
   <?php $i++; } } ?>
               </div><!-- /.row -->
    </div>
</section>





<?php 
    $this->load->view('front/common/footer');
    ?>
</body>
</html>