<?php $this->load->view('front/common/inner_header');?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">
<!-- Live Chart Area Start Here -->
        <section class="live-chart-area short-spacing section">
<div class="container">
<div class="live-chart-wrapper">
<div class="section-title text-center">
<h3><?php echo $this->lang->line('Live Coin Chart')?></h3>
<!-- <p>Tellus vulputate habitasse ut diam. Auctor sit elementum. Lorem ipsum dolor sit amet, interdum fringilla euismod odio vitae nam pulvinar elementum.</p> -->
</div>
<div class="live-chart-wrap">
<div class="table-title">
<h6><?php echo $this->lang->line('Last Coin Update')?></h6>


</div>
<div class="live-coin-find">
<table id="example" class="live-coin-chart responsive nowrap live-coin-chart-table" style="width:100%">
<thead class="table-header">
<tr>
<th><?php echo $this->lang->line('Name')?></th>
<th><?php echo $this->lang->line('Last Price')?></th>
<th><?php echo $this->lang->line('24H Change')?></th>
<th><?php echo $this->lang->line('24H High')?></th>
<th><?php echo $this->lang->line('24H Low')?></th>
<th><?php echo $this->lang->line('Volume')?></th>
</tr>
</thead>
<tbody class="table-body">
<?php if(isset($pairs) && !empty($pairs)){ foreach($pairs as $pair_details){ $from_currency = $this->common_model->getTableData('currency',array('id' => $pair_details->from_symbol_id))->row(); $to_currency = $this->common_model->getTableData('currency',array('id' => $pair_details->to_symbol_id))->row(); $pair_symbol = $from_currency->currency_symbol.'/'.$to_currency->currency_symbol; $pair_url = $from_currency->currency_symbol.'_'.$to_currency->currency_symbol; $currency = getcryptocurrencydetail($from_currency->id); 
if(isset($from_currency) && isset($to_currency)){?>
<tr>
<td>
<div class="table-currenct">
<img src="<?php echo $currency->image;?>" width="29%" alt="logo">
<h6><?=$pair_symbol?></h6>
</div>
</td>
<td>
<div class="country">
<h6><?php echo TrimTrailingZeroes($pair_details->lastPrice);?> / 0$</h6>
</div>
</td>
<td>
<div class="change">
<h6><span class="<?php echo($pair_details->priceChangePercent>0)?'':'span-red';?>"><?php echo number_format($pair_details->priceChangePercent,2); ?>%</span></h6>
</div>
</td>
<td>
<div class="date-time">
<h6><?php echo TrimTrailingZeroes($pair_details->change_high);?></h6>
</div>
</td>
<td>
<div class="amount">
<h6><?php echo TrimTrailingZeroes($pair_details->change_low);?></h6>
</div>
</td>
<td>
<div class="gain">
<h6><?php echo TrimTrailingZeroes($pair_details->volume);?></h6>
</div>
</td>
</tr>
<?php } } }?>
</tbody>
</table>
</div>
</div>
</div>
</div>
</section>

        <!-- Live Chart Area End Here -->
       
  <?php $this->load->view('front/common/inner_footer');?>  
   <script type="text/javascript" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>    
<script>
  var language = '<?php echo  $lang_id = $this->session->userdata('site_lang'); ?>';
         $(document).ready( function () {
        //   $('#example').DataTable({
        //     destroy: true,
        //     searching: false
        // //   "pagingType": "full_numbers"
        //   });
        if(language=='spanish')
  {

    $('#example').DataTable( {

       "language": {
              
            "sProcessing": "Procesando ...",
            "sLengthMenu": "Show _MENU_ registros",
            "sZeroRecords": "No se han encontrado resultados",
            "sEmptyTable": "No hay datos disponibles en esta tabla.",
            "sInfo": "Showing registros from _START_ to _END_ of a total of _TOTAL_ registros",
            "sInfoEmpty": "Mostrando registros de 0 to 0 out of a total of 0 registros",
            "sInfoFiltered": "(filtrando un total de _MAX_ registros)",
            "sInfoPostFix": "",
            "sSearch": "búsqueda:",
            "sUrl": "",
            "sInfoThousands": ",",
            "sLoadingRecords": "Cargando ...",
            "oPaginate": {
              "sFirst": "Primera",
              "sLast": "Última",
              "sNext": "Próxima",
              "sPrevious": "Previa"
            },
            "oAria": {
              "sSortAscending": ": Activate to sort the column in ascending order",
              "sSortDescending": ": Activate to sort the column in descending order"
            }


        },
        destroy: true,
        searching: false
    } );

  }
  else if(language=='italic')
  {
     $('#example').DataTable( {
       "language": {
              
            "sProcessing": "in lavorazione ...",
            "sLengthMenu": "Mostra _MENU_ inserimenti",
            "sZeroRecords": "nessun risultato trovato",
            "sEmptyTable": "Nessun dato disponibile in questa tabella",
            "sInfo": "Visualizzazione del inserimenti da _START_ a _END_ di un totale di _TOTAL_ inserimenti",
            "sInfoEmpty": "Mostra inserimenti da 0 a 0 su un totale di 0 inserimenti",
            "sInfoFiltered": "(filtrando un totale di _MAX_ inserimenti)",
            "sInfoPostFix": "",
            "sSearch": "ricerca:",
            "sUrl": "",
            "sInfoThousands": ",",
            "sLoadingRecords": "Caricamento in corso ...",
            "oPaginate": {
              "sFirst": "Primo",
              "sLast": "Ultimo",
              "sNext": "Prossimo",
              "sPrevious": "Precedente"
            },
            "oAria": {
              "sSortAscending": ": Activate to sort the column in ascending order",
              "sSortDescending": ": Activate to sort the column in descending order"
            }


        },
        destroy: true,
        searching: false

    });

  }
  else
  {

    $('#example').DataTable(
      {

        destroy: true,
        searching: false
        
      });


  }
          } );
      </script>