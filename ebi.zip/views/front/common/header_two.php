<?php 
$user_id=$this->session->userdata('user_id');
$sitelan = $this->session->userdata('site_lang');
$theme_mode = $_COOKIE['theme-mode'];
$currency = $this->common_model->getTableData('currency',array('status'=>'1','type'=>'digital'),'','','','','','', array('sort_order', 'ASC'))->result();
$favicon = $site_common['site_settings']->site_favicon;
$users = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
$meta_description = $sitelan."_meta_description";
$meta_keywords = $sitelan."_meta_keywords";
$title = $sitelan."_title";
?>
<!DOCTYPE html>
<html class="no-js" lang="zxx">
<!-- Mirrored from electronthemes.com/html/cryptohouse/homepage2.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 28 Jul 2021 13:06:50 GMT -->
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="icon" type="image/png" href="<?php echo $favicon;?>" />


    <title><?php if($meta_content): echo $meta_content->$title; else: echo 'Cripyic'; endif;?></title>
    <!-- CSS Files -->
    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>home_two/base-style.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>home_two/style.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>toastr.min.css" />
</head>

<body class="v_royal_blue loaded">
<!-- START LOADER -->
<div id="loader-wrapper">
    <div id="loading-center-absolute">
        <div class="object" id="object_four"></div>
        <div class="object" id="object_three"></div>
        <div class="object" id="object_two"></div>
        <div class="object" id="object_one"></div>
    </div>
    <div class="loader-section section-left"></div>
    <div class="loader-section section-right"></div>

</div>
<!-- END LOADER --> 
<div class="ch-banner-sec">
<?php $this->load->view('front/common/nav_menu_two');?>


