<?php  $this->load->view('front/common/header_two');
$user_id = $this->session->userdata('user_id');
?>
<div class="hero-banner-sec">
        <div class="container-fluid">
            <div class="row align-items-center">
            <div class="ico-animation-img-wrapper">
            <!-- <img class="ico-ani1" src="<?php echo front_img()?>home_two/cripto/bit-coin/circle.png" alt="image"> -->
            <img class="ico-ani2" src="<?php echo front_img()?>home_two/cripto/bit-coin/coin-sm.png" alt="image">
            <img class="ico-ani3" src="<?php echo front_img()?>home_two/cripto/bit-coin/coin-lg.png" alt="image">
        </div>
                <!-- <div class="col-lg-6 col-md-5 d-none d-md-block">
                    <div class="hero-banner-img pe-md-5">
                        <img src="<?php echo front_img()?>home_two/bitcoin.png" alt="">
                    </div>
                </div> -->
                <div class="col-lg-6 col-md-7">
                    <div class="hero-banner-text pt-5">
                        <h2><?php echo $this->lang->line('Invest Money Right Way')?></h2>
                        <h1><span><?php echo $this->lang->line('with')?></span><?php echo $this->lang->line('CryptoHouse')?></h1>
                        <p><?php echo $this->lang->line('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Non, lobortis in in tortor  nam pulvinar elementum.')?> </p>
                        
                        <?php if(empty($user_id)) { ?> 
                        <a href="<?=base_url()?>signup" class="btn btn-success"><?php echo $this->lang->line('GET STARTED')?> <i class="icofont-long-arrow-right"></i></a> 
                    <?php }else{?>
                        <a href="<?=base_url()?>dashboard" class="btn btn-success"><?php echo $this->lang->line('GET STARTED')?> <i class="icofont-long-arrow-right"></i></a> 
                    <?php }  ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<div class="coin-exchang-area short-spacing section" id="coin-exchange">
            <div class="container">
                <div class="coin-exchange-wrapper">
                    <div class="sec-title text-center mb-lg-0">
            <h1 data-watermark=""><span><?php echo $this->lang->line('Coin')?></span> <?php echo $this->lang->line('Exchange')?></h1>
        </div>

                    <div class="exchange-wrap">
                        <div class="exchange-currency">
                            <div class="exchange-currency-left">
                                <label><?=$this->lang->line('Crypto Digital')?></label>
                                <div class="exchange-box">
                                    <div class="currency">
                                        <input type="number" id="amount-one" placeholder="0" value="1"/>
                                        <select class="select-country select" id="currency-one">
                                            <?php  if(isset($digital_currency_1) && !empty($digital_currency_1)){
                                                foreach($digital_currency_1 as $digital_cur1){?>
                                                <option value="<?=$digital_cur1->currency_symbol?>"><?=$digital_cur1->currency_symbol?></option>
                                                <?php } }?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="exchange-currency-middle">
                                <div class="swap-rate-container">
                                    <button class="btn" id="swap">
                                        <img src="<?php echo front_img()?>home_two/short-code-img/icon/exchange.svg" alt="exchange">
                                    </button>
                                </div>
                            </div>
                            <div class="exchange-currency-right">
                                <label><?php echo $this->lang->line('Crypto')?></label>
                                <div class="exchange-box">
                                    <div class="currency">
                                        <input type="number" id="amount-two" placeholder="0"/>
                                        <select class="select-country select" id="currency-two" >
                                        <?php  if(isset($digital_currency_2) && !empty($digital_currency_2)){
                                                foreach($digital_currency_2 as $digital_cur2){?>
                                                <option value="<?=$digital_cur2->currency_symbol?>"><?=$digital_cur2->currency_symbol?></option>
                                                <?php } }?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="change-button">
                            <div class="rate" id="rate"></div>
                            <button class="r-button r-promary semi-rounded" id="exchange"><?php echo $this->lang->line('Exchange Currency')?></button>
                        </div>
                    </div>
             
                </div>
            </div>
        </div>
        <!-- Coin Exchange Area End Here -->
    </div>
</div>

<div class="roadmap-sec pt-5 pt-lg-0">
    <div class="container">
        <div class="sec-title text-center" data-aos="fade-up">
            <h1 data-watermark=""><span><?php echo $this->lang->line('FAQ')?></span></h1>
            <!-- <p>The road map of our business system</p> -->
        </div>
        <div class="card-wrap">
                        <div class="card-top-section">
                        <?php  if(isset($faq_category) && !empty($faq_category)){
                             foreach($faq_category as $faq_cat){?>
                        <div class="seingl-card">
                            <div class="card-content text-center">
                            <div class="card-thumb">
                                <a href="<?php echo base_url('faq/'.$faq_cat->id);?>"><i class="icofont-bitcoin"></i></a>
                                </div>
                                <h4><?=$faq_cat->category_name?></h4>
                          
                            </div>
                            </div>
                            <?php } }?>
                        </div>
                        
                    
                    </div>
    </div>
</div>

<div class="counter-sec py-100">
    <div class="container">
        <div class="counter">
            <div class="counter-img text-center" data-aos="zoom-in">
                <img src="<?php echo front_img()?>home_two/counter.png" alt="">
            </div>
            <div class="counter-wrap">
                <div class="row text-center">
                    <div class="col-lg-3 col-sm-6 py-3">
                        <div class="counter-item" data-aos="fade-up">
                            <h2>
                                <span class="counter-value" data-count="165567">0</span>
                            </h2>
                            <p><?php echo $this->lang->line('Daily Batch User')?></p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 py-3">
                        <div class="counter-item" data-aos="fade-up" data-aos-delay="100">
                            <h2>
                                <span class="counter-value" data-count="0.759">0</span>
                            </h2>
                            <p><?php echo $this->lang->line('Average Rate')?></p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 py-3">
                        <div class="counter-item" data-aos="fade-up" data-aos-delay="200">
                            <h2>
                                <span class="counter-value" data-count="5.87">0</span>
                            </h2>
                            <p><?php echo $this->lang->line('Total Batches')?></p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 py-3">
                        <div class="counter-item" data-aos="fade-up" data-aos-delay="300">
                            <h2>
                                <span class="counter-value" data-count="70">0</span>%
                            </h2>
                            <p><?php echo $this->lang->line('Success Rate')?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<div class="video-sec" data-aos="fade-up">
    <div class="container">

        <div class="bg-primary-gradient px-3 home1-block-wrap">
            <div class="row">
                <div class="col-lg-11 mx-auto">
                    <div class="row text-center text-white">
                        <div class="col-md-4 py-3">
                            <div class="">
                                <div class="mb-3">
                                    <img src="<?php echo front_img()?>home_two/icon/1.svg" alt="">
                                </div>
                                <div class="">
                                    <h4><?php echo $this->lang->line('Exchange Balance')?></h4>
                                    <p><?php echo $this->lang->line('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Non, lobortis in in tortor  nam pulvinar elementum.')?> </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 py-3">
                            <div class="">
                                <div class="mb-3">
                                    <img src="<?php echo front_img()?>home_two/icon/2.svg" alt="">
                                </div>
                                <div class="">
                                    <h4><?php echo $this->lang->line('Block Chain')?></h4>
                                    <p><?php echo $this->lang->line('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Non, lobortis in in tortor  nam pulvinar elementum.')?> </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 py-3">
                            <div class="">
                                <div class="mb-3">
                                    <img src="<?php echo front_img()?>home_two/icon/3.svg" alt="">
                                </div>
                                <div class="">
                                    <h4><?php echo $this->lang->line('Mining Currency')?></h4>
                                    <p><?php echo $this->lang->line('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Non, lobortis in in tortor  nam pulvinar elementum.')?> </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php  $this->load->view('front/common/footer_two');?>

