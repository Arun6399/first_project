<?php
$user_id=$this->session->userdata('user_id');
$site_common = site_common();
$sitelogo = $site_common['site_settings']->site_logo;
$sitephone = $site_common['site_settings']->contactno;
 $lang_id = $this->session->userdata('site_lang');
  if($lang_id!=''){
  //$title = $lang_id.'_name';
  $content = $lang_id.'_content';
  }else{
 // $title = $site_lang.'_name';
  $content = $site_lang.'_content';
  }
?>
<style>
    .error{
        color: #ba1114;
    }
  ::placeholder {
  color: #000 !important;
  opacity: 1; 
}

</style>
 <div class="community-area wow fadeInUp section-padding" id="contact">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="heading">
                        <h5>Great Community</h5>
                        <div class="space-10"></div>
                        <h5>Our Community </h5>
                    </div>
                <div class="space-40"></div>
                </div>
            </div>
            <div class="row">

                <div class="col-12 col-lg d-flex justify-content-center">
                    <div class="single-community mid-social">
                        <a class="linkedin" href="https://www.linkedin.com"><i class="fa fa-linkedin"></i></a>
                    </div>

                    <div class="single-community mid-social">
                        <a class="twitter" href="https://www.twitter.com"><i class="fa fa-twitter"></i></a>
                    </div>
                    <div class="single-community mid-social">
                        <a class="youtube" href="https://www.youtube.com"><i class="fa fa-youtube"></i></a>
                    </div>
                    <div class="single-community mid-social">
                        <a class="facebook" href="https://www.facebook.com"><i class="fa fa-facebook"></i></a>
                    </div>
                    <div class="single-community mid-social">
                        <a class="telegram" href="https://www.telegram.com"><i class="fa fa-telegram"></i></a>
                    </div>


                  
                </div>

            </div>
        </div>
    </div>


<!--footer area start-->
    <div class="footera-area section-padding wow fadeInDown">
        <div class="container">
            <div class="row">
                <div class="col-6 col-sm-6 col-lg-3">
                    <div class="single-footer">
                       
                        <ul>
                            <li><a href="#"><h5>Menu</h5></a></li>
                            <li><a href="<?php echo base_url();?>h5">Home</a></li>
                            <li><a href="<?php echo base_url();?>market">Market</a></li>
                            <li><a href="#">Exchange</a></li>
                            <!-- <li><a href="#">Announcements</a></li> -->
                            <!-- <li><a href="#">Apply to List</a></li> -->
                            <li><a href="<?php echo base_url();?>contact_us">Contact us</a></li>
                        </ul>


                    </div>
                </div>
                <div class="col-6 col-sm-6 col-lg-3">
                    <div class="single-footer">
                        <ul>
                            <li><a href="#"><h5>Legal</h5></a></li>
                            <li><a href="<?php echo base_url();?>cms/terms-and-conditions">Terms & Conditions</a></li>
                            <li><a href="<?php echo base_url();?>cms/privacy-policy">Privacy policy</a></li>
                            <li><a href="<?php echo base_url();?>kyc_new">AMC KYC</a></li>
                            <!-- <li><a href="#">Refund Policy</a></li> -->
                        </ul>
                    </div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="single-footer">
                        <ul>
                            <li><a href="#"><h5>Connect With us</h5></a></li>
                            <li> <a class="twitter" href="https://www.twitter.com"><i class="fa fa-twitter" style="padding-right: 10px;"></i> Twitter</a></li>
                            <li> <a class="facebook" href="https://www.facebook.com"><i class="fa fa-facebook" style="padding-right: 10px;"></i>Facebook</a></li>
                            <li> <a class="telegram" href="https://www.telegram.com"><i class="fa fa-telegram" style="padding-right: 10px;"></i>Telegram</a></li>
                            <li> <a class="youtube" href="https://www.youtube.com"><i class="fa fa-youtube" style="padding-right: 10px;"></i> youtube</a></li>
                            <li> <a class="linkedin" href="https://www.linkedin.com"><i class="fa fa-linkedin" style="padding-right: 10px;"></i> LinkedIn</a></li>

                        </ul>
                    </div>
                </div>
                <div class="col-6 col-sm-6 col-lg-3">
                    <div class="single-footer">
                        <h5>Subscribe to our Newsletter</h5>
                        <div class="space-20"></div>
                        <div class="footer-form">
                           <?php
                        $action = base_url().'reg_subscribe';
                        $attributes = array('id'=>'subscribe_form',"method"=>"post","class"=>"subscribe_form animation","data-animation"=>"fadeInUp","data-animation-delay"=>"0.4s"); 
                        echo form_open_multipart($action,$attributes);
                    ?>
                                <input type="email" name="email" class="sub" required placeholder="Email Address">

                                <button name="submit" value="Submit" class="gradient-btn-1 subscribe" type="submit">GO</button>
                            <?php echo form_close();?>
                        </div>
                    </div>
                </div>
            </div>
            <p style="margin-top: 20px;color: white;">
                Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved
            
                </p>
        </div>
    </div>
    <!--footer area end-->

    <!-- jquery 2.2.4 js-->
    <script src="<?php echo front_js();?>jquery-2.2.4.min.js"></script>
    <!-- popper js-->
    <script src="<?php echo front_js();?>popper.js"></script>
    <!-- carousel js-->
    <script src="<?php echo front_js();?>owl.carousel.min.js"></script>
    <!-- wow js-->
    <script src="<?php echo front_js();?>wow.min.js"></script>
    <!-- bootstrap js-->
    <script src="<?php echo front_js();?>bootstrap.min.js"></script>
    <!--skroller js-->
    <script src="<?php echo front_js();?>skrollr.min.js"></script>
    <!--mobile menu js-->
    <script src="<?php echo front_js();?>jquery.slicknav.min.js"></script>
    <!--particle s-->
    <script src="<?php echo front_js();?>particles.min.js"></script>
    <!-- main js-->
    <!-- <script src="<?php echo front_js();?>main.js"></script> -->

    <script src="<?php echo front_js();?>tabler.js"></script>
    <script src="<?php echo front_js();?>toastr.min.js"></script>


    <script src="<?php echo front_js();?>tabler.min.js"></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.js"></script>
   
 
     <script type="text/javascript">
//   $('#coin_table').DataTable( {
// // "bPaginate": false,
// // "bFilter": false,
// // "bInfo": false,
// responsive: true
// } );
   // $('#coin_table').DataTable({responsive: true });

</script>
    <?php
    $error      = $this->session->flashdata('error');
    $success    = $this->session->flashdata('success');
    $user_id    = $this->session->userdata('user_id');
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $get_os     = $_SERVER['HTTP_USER_AGENT'];
?>

<script type="text/javascript">        
    function choose_lang(obj){
        var selct_lang = obj.value;
        //console.log(selct_lang); 
                window.location.href="<?php echo base_url()?>switchLang/"+selct_lang;
    }
    </script>
 <script>
    // ----------------navbar--------------------------------

function openNavbar(){
  var o = document.getElementById("slideNavbar")

  o.style.right = '0';
  o.style.transition = "1.5s ease";
}
function closeNavbar(){
  var c = document.getElementById("slideNavbar")

  c.style.right = '-115%';
  c.style.transition = "1.5s ease";
}
 
    
var base_url='<?php echo base_url();?>';
var front_url='<?php echo front_url();?>';
var user_id='<?php echo $user_id;?>';
var ip_address = '<?php echo $ip_address;?>';
var get_os     = '<?php echo $get_os;?>';
var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';
var success = "<?php echo $this->session->flashdata('success')?>";
var error = "<?php echo $this->session->flashdata('error')?>";
$(document).ready(function() {
if(success!=''){
toastr.success('xabits! '+success);
}
if(error!=''){
    toastr.error('xabits! '+error);
}
});


  </script>
  <script>
   
        $("#subscribe_form").validate({
             rules: {
            email: {
                required: true,
                email:true
            },
        },
        messages: {
            email: {
                required:"Please enter email address",
                email: "Please enter valid email address",
                remote: "Entered Email Address Already Exists"
            }
        },
        errorElement : 'div',
    errorLabelContainer: '#email-error'
        
        });
  </script>



    <script>
   
        $("#subscribe_form").validate({
             rules: {
            email: {
                required: true,
                email:true
            },
        },
        messages: {
            email: {
                required:"Please enter email address",
                email: "Please enter valid email address",
                remote: "Entered Email Address Already Exists"
            }
        },
        errorElement : 'div',
    errorLabelContainer: '#email-error'
        
        });
  </script>
    <script>
            function choose_lang(obj){
        var selct_lang = obj.value; 
                window.location.href="<?php echo base_url()?>switchLang/"+selct_lang;
    }
 
        </script>

  </body>
</html>