<?php $this->load->view('front/user/wallet_header');
   $settings = $site_common['site_settings'];
  $user_id = $this->session->userdata('user_id');
    $all_currency = $this->common_model->getTableData("currency",array("status"=>1))->result();
     if(count($all_currency))
     {
       $tot_balance = 0;
       $getbal =0;
       foreach($all_currency as $cur)
       {

         $convert = $this->common_model->conveter($cur->currency_symbol);
           $balance = getBalance($user_id,$cur->id);
           $usd_balance = $balance * $convert;

           $getbal += $balance;
           $tot_balance += $usd_balance;
       }
     }
       ?>
       <div class="navbar-expand-md">
        <div id="navbar-menu">
          <div class="navbar navbar-expand-md navbar-light sticky-top d-print-none">
            <div class="container-xl" style="display: block;">
              <ul class="navbar-nav">
                <li class="nav-item"> <a class="nav-link" href="<?php echo base_url();?>account" ><span class="nav-link-title"> Account </span> </a> </li>
                <li class="nav-item active "> <a class="nav-link" href="<?php echo base_url();?>wallet" ><span class="nav-link-title"> Assets </span> </a> </li>
                <li class="nav-item"> <a class="nav-link" href="<?php echo base_url();?>history" > <span class="nav-link-title"> Fund History </span> </a> </li>
                <!-- <li class="nav-item "> <a class="nav-link" href="trade.html" > <span class="nav-link-title"> Trade History </span> </a> </li> -->
              </ul>

            </div>
          </div>
        </div>
      </div>
      <div class="page-body">
        <div class="container-xl">
          <div class="row row-deck row-cards">

            <div class="col-12">
            <div class="card" style="border: none;box-shadow: none;">
                <div class="card-body border-bottom py-3" style="padding-left: 115px;">
                  <div class="row">
                    <div class="col-12 col-lg-3">
                      <div class="heading">
                        <p>Estimated Value:<span> <?=number_format($tot_balance, 2);?> USD</span></p>
                    </div>
                    <a  href="<?php echo base_url();?>request" class="btn btn-primary waves-effect gradient-btn trade">Request</a>
                    </div>
                    <div class="col-12 col-lg-3">
                     

                    </div>

                  </div>
                  <hr>


                      <div  class="table-responsive" style="overflow: auto;">
                        <table class="table table-hover mb-0">
                           <thead>
                                    <tr>
                                        <th>COIN</th>
                                        <th>Name</th>
                                        <th>Balance</th>
                                        <th>Value in USD</th>
                                        <th>Xabits account balance</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                            <tbody>
                                 <?php
                                    if(count($dig_currency) >0)
                                    {

                                       foreach ($dig_currency as $digital) 
                                     {
                                    if($digital->type=="fiat")
                                    {
                                        $format = 2;
                                    }
                                   
                                    else
                                    {
                                        $format = 6;
                                    }
                                    $coin_price_val = to_decimal($wallet['Exchange AND Trading'][$digital->id], $format);
                                    $coin_price = $coin_price_val * $digital->online_usdprice;
                                    $user_id=$this->session->userdata('user_id');
                                     $userbalance = getBalance($user_id,$digital->id);
                                    // $USDT_Balance = $userbalance *  $digital->online_usdprice;
                                     $USD_Bal = $this->common_model->conveter($digital->currency_symbol);
                                     $USD_Balance = $userbalance * $USD_Bal;


                                    $pairing = $this->common_model->getTableData('trade_pairs',array('from_symbol_id'=>$digital->id,'status'=>1))->row();
                                                if(!empty($pairing))
                                                {
                                                    $fromid = $pairing->from_symbol_id;
                                                    $fromcurr = $this->common_model->getTableData('currency',array('id'=>$fromid,'status'=>1))->row();
                                                    $fromSYM = $fromcurr->currency_symbol;
                                                    $toid = $pairing->to_symbol_id;
                                                    $tocurr = $this->common_model->getTableData('currency',array('id'=>$toid,'status'=>1))->row();
                                                    $toSYM = $tocurr->currency_symbol;

                                                    $traDepair = $fromSYM."_".$toSYM; 

                                                }
                                                else
                                                {
                                                   $pairing = $this->common_model->getTableData('trade_pairs',array('to_symbol_id'=>$digital->id,'status'=>1))->row();
                                                   if(!empty($pairing))
                                                {
                                                    $fromid = $pairing->to_symbol_id;
                                                    $fromcurr = $this->common_model->getTableData('currency',array('id'=>$fromid,'status'=>1))->row();
                                                    $fromSYM = $fromcurr->currency_symbol;

                                                    $toid = $pairing->from_symbol_id;
                                                    $tocurr = $this->common_model->getTableData('currency',array('id'=>$toid,'status'=>1))->row();
                                                    $toSYM = $tocurr->currency_symbol;

                                                    $traDepair = $toSYM."_".$fromSYM;
                                                }

                                                }
                                        ?>
                                    <tr>
                                         <!-- <td><i class="cc <?php echo strtoupper($digital->currency_symbol);?> mr-3"></i>  <?php echo $digital->currency_symbol;?></td> -->
                                         <td><img src="<?php echo $digital->image;?>" width="30" height="30">  <?php echo $digital->currency_symbol;?></td>
                                        <td><?php echo $digital->currency_name;?></td>

                                        
                                        <td><?php echo ($userbalance > 0) ? $userbalance : '0'; ?></td>
                                        <td><?php echo  ($userbalance > 0) ? number_format($USD_Balance,2) : '0';   ?></td>

                                        <?php  
                                        if($digital->type=='fiat')
                                        {
                                         $xabit_amt = getBalance_amount($user_id,$digital->id);

                                        }
                                        else
                                        {
                                           $xabit_amt = ' - ';
                                          
                                        }
                                        ?>

                                        <td> <?php echo $xabit_amt;  ?></td>
                                        <td>
                                            <a href="<?php echo base_url(); ?>deposit/<?=$digital->currency_symbol;?>" class="btn btn-primary waves-effect gradient-btn trade">Deposit</a>
                                            <a href="<?php echo base_url(); ?>withdraw/<?=$digital->currency_symbol;?>" class="btn btn-danger waves-effect gradient-btn trade">Withdraw</a>
                                            <?php 
                                            if($digital->currency_symbol=='EUR')
                                            $link =  base_url().'exchange/#/';
                                            else
                                            $link = base_url().'exchange/#/trade/'.$digital->currency_symbol."_EUR";
                                            
                                            ?> 

                                            <a href="<?php echo $link;?>" class="btn btn-success waves-effect gradient-btn trade">Trade</a>
                                             
                                        </td>
                                    </tr>
                                    <?php 
                                                
                                            }      
                                            }
                                    ?>

                            </tbody>
                          </table>
                         </div>
                    </div>




              </div>

            </div>
          </div>
        </div>
      </div>

    <!--community area start-->
    <?php $this->load->view('front/common/footer') ?>
    
  </body>
</html>