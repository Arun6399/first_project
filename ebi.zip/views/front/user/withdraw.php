<?php $this->load->view('front/user/login_header') ?>



      <div class="page-body" >
        <div class="container-xl">
         
<style>
    .form-control:not([size]):not([multiple]) {
    height: calc(2.25rem + 7px) !important;
}
.ap_log_frm_input{
  width: 60%;
}

</style>

<div class="row">
  <div class="col-md-12 col-lg-4">
   
    <div class="ap_pnl">
      <div class="ap_log_h1  ">Withdraw</div>
      <div class="row">
            <?php 
                                $action = '';
                                $attributes = array('id'=>'withdrawcoin','autocomplete'=>"off",'class'=>'deposit_form'); 
                                echo form_open($action,$attributes); ?>
        <div class="col-12">
          <div class="ap_log_frm">
            <div class="ap_log_frm_txt">Coin</div>
             <input type="hidden" name="fees" id="fees" value="<?php echo $fees;?>">
              <input type="hidden" name="fees_type" id="fees_type" value="<?php echo $fees_type;?>">
          <select class="custom-select" onchange="getcurrency(this.value,this);" name="ids" class="form-control">
                                            

                                           <?php if(count($currency)>0)
                                                  {
                                                    $h =1;
                                                    foreach($currency as $cur)
                                                    {
                                                      // print_r($currency);exit();
                                                        ?>
                        <option <?php if($selcur_id==$cur->id) { echo 'selected';} ?> value="<?=$cur->id?>_<?=$cur->currency_name?>_<?php echo $wallet['Exchange AND Trading'][$cur->id]?>_<?php echo $cur->type?>"><?=$cur->currency_symbol?> </option>

                                                        <?php $h++;
                                                    }
                                                  } ?>
                                        </select>
            
            </div>
        </div>
        <div class="col-12">
          <div class="ap_log_frm digital-div">
            <div class="ap_log_frm_txt">Address</div>
           <input type="text" class="ap_log_frm_input" name="address" id="address">
            </div>
        </div>
        <div class="col-md-12">
          <div class="ap_log_frm digital-div">
            <div class="ap_log_frm_txt" id="balsym" class="sym">Amount In <span><?=$selcsym?></span></div>
               <input type="text" class="ap_log_frm_input " name="amount" id="amount" placeholder="Amount" onkeyup="calculate();" value="">
              <div class="ap_with_am2_txt">Withdraw Fees:<span>0.03BTC</span></div>
              <div class="ap_with_am_set">
              <div class="ap_with_am_set_li">Min : <span>230</span></div>
              <div class="ap_with_am_set_li">Max : <span>550</span></div>

              </div>
            
            </div>
        </div>
        <div class="col-6">
          <div class="ap_depo_qr_stxt2">Total Balance <span class="totbal" id="tot_balance"><?php 
                                                
                                                    echo number_format($currency_balance,8);
                                                ?></span> <span id="balsym" class="sym"><?=$selcsym?></span>  </div>
        </div>
        <div class="col-6">
          <div class="ap_depo_qr_stxt2">Available Balanc  <span class="totbal" id="tot_balance"><?php 
                                                
                                                    echo number_format($currency_balance,8);
                                                ?></span> <span id="balsym" class="sym"><?=$selcsym?></span>  </div>
        </div>

        <div class="fiat_payment" style="display: none;">

                                                <?php
                                                if(trim($users->verify_level2_status)=='Completed') {
                                                ?>

                                                <div class="text-center mt-3 mb-4">
                                               

                                                 <a  style="margin-right:20px;"  class="btn btn-success waves-effect waves-light button" href="javascript:;" data-toggle="modal" data-target="#bankwire" data-dismiss="modal" aria-label="Close">Bankwire</a>

                                               

                                             <?php } else { ?> 

                                                    <p><?php echo $this->lang->line('Please Complete KYC');?></p>
                                                 <a class="btn btn-danger waves-effect waves-light button"  href="<?php echo base_url();?>kyc"> Click here</a>

                                             <?php } ?> 


                                                </div>

                                            </div>
        <div class="col-12 digital-div">

              <label class="lap">Amount You will receive : <span id="amount_receive"></span> <span class="sym" ><?=$selcsym?></span></label>
               <label>Fee : <span id="fees_p"></span> <span class="sym"><?=$selcsym?></span></label>
               <br>
                        <div class="ap_log_frm digital-div">
                    <div class="ap_log_frm_txt">2FA</div>
                   <input type="text" class="ap_log_frm_input" name="code" id="code" value="">

                   <!-- <a  onclick="enable();">click</a> -->
                    </div>


                <?php
                            //echo $user->verify_level2_status; 
                            if(trim($user->verify_level2_status)=='Completed')
                                            {
                                    ?>

         <button   name="withdrawcoin" id="with_btn"  class="ap_btn">Withdraw Now</button>
          <?php } else {  ?>
            <div class="text-center mt-3 mb-2">Please Complete KYC<a class="btn btn-danger" style="margin-left: 30px;" href="<?php echo base_url();?>kyc_new"> Click here</a></div><?php } ?>
             <?php
                        echo form_close();
                        ?>
  
        </div>
       
      </div>
    
    </div>
  </div>
  <div class="col-md-12 col-lg-8">
 
    <dv class="table_panel" style="padding-top20px">
                        <div class="table_panel_heading justify-content-between align-items-center disp">
                            <h2>Withdraw History</h2>
                            <input type="text" class="form-control search_input input-wid" id="search" placeholder="Search">
                        </div>
                        <div class="table_panel_body">
                            <div class="table-responsive">
                                <table class="table table-borderless" id="table"  >
                                    <thead>
                                        <tr>
                                           <th>SNo</th>
                                            <th>Date &amp; Time</th>
                                            <th>Currency</th>
                                            <th>Sent Amount</th>
                                            <th>Fees</th>
                                            <th>Received Amount</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody class="table_scroll">
                                        <?php
                                    if(isset($withdraw_history) && !empty($withdraw_history)){
                                    $b=0;
                                    foreach($withdraw_history as $withdraw){
                                    $b++;
                                    ?>
                                                   <tr>
                                            <td><?php echo $b;?></td>
                                            <td><?php 
                                            if($withdraw->payment_method=='crypto'){
                                            echo date('Y-m-d H:i A',strtotime($withdraw->datetime));
                                          }
                                          else{
                                            echo date('Y-m-d H:i A',$withdraw->datetime);
                                          }

                                            ?></td>
                                            <td><?php echo strtoupper(getcryptocurrency($withdraw->currency_id));?></td>
                                            <td><?php echo number_format($withdraw->amount,8);?></td>
                                            <td><?php echo number_format($withdraw->fee,8);?></td>
                                            <td><?php echo number_format($withdraw->transfer_amount,8);?></td>
                                             <?php 
                                              if($withdraw->status =='Completed')
                                              {
                                                $elmt_class = 'green';

                                              }
                                              else
                                              {
                                                $elmt_class = 'red';
                                              } ?> 
                                                <td><span class="<?php echo $elmt_class; ?>"><?php echo $withdraw->status;?></span></td>
                                          </tr>
                                      <?php } }else{ ?>
                                                  <tr>
                                                <td colspan="7" style="text-align: center;">No records found !!!</td>
                                            </tr>
                                             <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
  </div>
</div>




          </div>
        </div>
      </div>


<div class="modal fade right" id="bankwire" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true"> 
  
  <!-- Add class .modal-full-height and then add class .modal-right (or other classes from list above) to set a position to the modal -->
  <div class="modal-dialog modal-full-height modal-right iks-popup" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background: #d3d6f3;">
        <h4 class="modal-title w-100" id="myModalLabel">Bankwire Withdraw</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
      </div>
      <div class="modal-body" style="background: #d3d6f3;"> 
        <div class="col-sm-12">
              <div class="row">
                <div class="col-sm-12 deposit-address bank_wire">
                  <?php  $action = base_url()."withdraw";
       $attributes = array('id'=>'deposit_fiat','autocomplete'=>"off"); 
        echo form_open($action,$attributes); 
                                        ?>     
                  <input type="hidden" name="currency" id="banwire_id" class="currency" value="<?php echo $sel_currency->id;?>" >
                  <div class="form-row">
                  <table class="table popup">
                      <tr>
                        <th>Account Number</th>
                        <td><strong><?=$user_bankdetails->bank_account_number?></strong></td>
                      </tr>
                      <tr>
                        <th>Account CODE</th>
                        <td><strong><?=$user_bankdetails->bank_swift?></strong></td>
                      </tr>
                      <tr>
                        <th>Account Name</th>
                        <td><strong><?=$user_bankdetails->bank_account_name?></strong></td>
                      </tr>
                      <tr>
                        <th>Account Number</th>
                        <td><strong><?=$user_bankdetails->bank_account_number?></strong></td>
                      </tr>
                      <tr>
                        <th>Bank Name</th>
                        <td><strong><?=$user_bankdetails->bank_name?></strong></td>
                      </tr>
                      <tr>
                        <th>POSTAL Code</th>
                        <td><strong><?=$user_bankdetails->bank_postalcode?></strong></td>
                      </tr>
                    </table> 

                    
                     <input type="hidden"  name="account_number" value="<?=$user_bankdetails->bank_account_number ;?>">
                      <input type="hidden"  name="account_name" value="<?=$user_bankdetails->bank_account_name;?>">
                       <input type="hidden"  name="bank_name" value="<?=$user_bankdetails->bank_name;?>">
                        <input type="hidden"  name="bank_swift_code" value="<?=$user_bankdetails->bank_swift;?>">
                         <input type="hidden"  name="bank_country" value="<?=$user_bankdetails->bank_country;?>">
                         <input type="hidden"  name="bank_city" value="<?=$user_bankdetails->bank_city;?>">
                         <input type="hidden"  name="bank_postalcode" value="<?=$user_bankdetails->bank_postalcode;?>">
                          <input type="hidden"  name="bank_address" value="<?=$user_bankdetails->bank_address;?>">
                    <?php if(count($user_bankdetails) > 0){?>
                     <div class="row">
                        <div class="col-12 col-md-12">
                          <label for="basic-url">Enter amount<span style="color: #fff;">*</span></label>
                          <div class="mb-3">
                            <input type="text" required="" style="border: 1px solid #7b6fff;" class="form-control input_anim" aria-label="Small" aria-describedby="inputGroup-sizing-sm" name="amount">
                          </div>
                        </div>
                      </div>                      

                    <div class="col-12 col-md-12">
                      <div class="row">
                        <div class="col-12 col-md-12">
                          <div class="profile-flex border-0 pt-4 pull-left">
                            <div class="text-center">
                              <button name="withdraw_bank" id="withdraw_bank" class="btn btn-success waves-effect waves-light button" type="submit"> Withdraw </button>
                            </div> 
                          </div>
                        </div>
                      </div>
                    </div>
                <?php } else{ ?>
                    <div class="col-12 col-md-12">
                      <div class="row">
                        <div class="col-12 col-md-12">
                          <div class="profile-flex border-0 pt-4 pull-left">
                             <label>Please Fill the Bank Details here</label>
                                <button style="margin-left:20px;" class="btn btn-success waves-effect waves-light button" ><a href="<?php echo base_url();?>profile">Click Here </a> </button>
                          </div>
                        </div>
                      </div>
                    </div>

                   <?php } ?> 
                  </div>
                  <?php echo form_close();?> </div>
              </div>
            </div>
       </div>
    
    </div>
  </div>
</div>



   

   <?php $this->load->view('front/common/footer'); ?>
    <!--  <script src="<?php echo front_js();?>datatables.bootstrap4.min.js"></script>
     <script src="<?php echo front_js();?>dataTables.min.js"></script>
     <script src="<?php echo front_js();?>datatables.bootstrap4.js"></script> -->
   
    

    <script type="text/javascript">

$(document).ready(function() {

   
    var base_url='<?php echo base_url();?>';
        var front_url='<?php echo front_url();?>';
        var user_id='<?php echo $user_id;?>';
        var ip_address = '<?php echo $ip_address;?>';
        var get_os = '<?php echo $get_os;?>';

        var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';

        var success = "<?php echo $this->session->flashdata('success')?>";
        var error = "<?php echo $this->session->flashdata('error')?>";
        $(document).ready(function() {
        $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
        if (options.type.toLowerCase() == 'post') {
        options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
        if (options.data.charAt(0) == '&') {
        options.data = options.data.substr(1);
        }
        }
        });


        });
  // $(document).ready(function() {
  //   $('#table').DataTable();
  //       });

 

var default_type = '<?php echo $sel_currency->type;?>';

      if(default_type=='fiat')
      {
        $(".fiat_payment").css('display','block');
        $(".digital-div").css('display','none');
      }
      else
      {
        $(".fiat_payment").css('display','none');
        $(".digital-div").css('display','block');
      } 


});


       $.validator.addMethod("noSpace", function(value, element) { 
  return value.indexOf(" ") < 0 && value != ""; 
}, "No space please and don't leave it empty");

        $("#withdrawcoin").validate({
          rules: {
                  address: {
                    required: true,
                    noSpace: true
                  },
                  amount: {
                    required: true,
                    number:true
                  },
                  ids: {
                    required: true
                  },
                  own_address: {
                    required: true
                  },
                  code : {
                    required :true
                  }
                },
          messages: {
                address: {
                  required: "Please enter address"
                },
                amount: {
                  required: "Please enter Amount",
                  number: "Invalid Amount"
                },
                ids: {
                  required: "Please select currency"
                },
                  own_address: {
                    required: 'Please confirm this'
                  }
              },
              submitHandler: function(form) 
        { 
    var fees_type = $('#fees_type').val();
    var fees = $('#fees').val();

    var amount = $('#amount').val();

    if(fees_type=='Percent'){
        var fees_p = ((parseFloat(amount) * parseFloat(fees))/100);
        var amount_receive = parseFloat(amount) - parseFloat(fees_p);
    }
    else{
        var fees_p = fees;
        var amount_receive = parseFloat(amount) - parseFloat(fees_p);
    }
    if(parseFloat(amount_receive)<=0){
      $.growl.error({ message: 'Please enter valid amount' });
      return false;
    }
    else if(parseFloat(amount)<=parseFloat(fees_p)){
     
      $.growl.error({ message: 'Please enter valid amount' });
      return false;
    }
    else{
      form.submit();
    }
        }     
         });

        $('#withdraw_mobile').validate(
        {
            rules: {
              mobile_number:{
                required: true,
                number: true
              },
              pay_name:{
                required: true
              },
                amount1: {
                  required: true,
                  number: true,
                },
                narration: {
                    required: true
                }
            },
            messages: {
              mobile_number:{
                  required:'Please enter mobile number',
                  number:'Please enter valid number'
              },
              pay_name:{
                required: 'Please enter name',
              },
                amount1: {
                    required: "Please enter amount",
                    number: "Only enter numbers as decimal or float"
                },
                narration: {
                    required: "Please enter Narration"          
                }
            },
            invalidHandler: function(form, validator) {
                if (!validator.numberOfInvalids())
                {
                    return;
                }
                else
                {
                    var error_element=validator.errorList[0].element;
                    error_element.focus();
                }
            },
            highlight: function (element) {
                //$(element).parent().addClass('error')
            },
            unhighlight: function (element) {
                $(element).parent().removeClass('error')
            },
            submitHandler: function(form) 
            { 
                form.submit();
            }
        });

        $('#withdraw_bank').validate(
        {
            rules: {
              account_number:{
                required: true,
                number: true
              },
              pay_name:{
                required: true
              },
                amount2: {
                  required: true,
                  number: true,
                },
                narration: {
                    required: true
                }
            },
            messages: {
              account_number:{
                  required:'Please enter Account number',
                  number:'Please enter valid number'
              },
              pay_name:{
                required: 'Please enter name',
              },
                amount2: {
                    required: "Please enter amount",
                    number: "Only enter numbers as decimal or float"
                },
                narration: {
                    required: "Please enter Narration"          
                }
            },
            invalidHandler: function(form, validator) {
                if (!validator.numberOfInvalids())
                {
                    return;
                }
                else
                {
                    var error_element=validator.errorList[0].element;
                    error_element.focus();
                }
            },
            highlight: function (element) {
                //$(element).parent().addClass('error')
            },
            unhighlight: function (element) {
                $(element).parent().removeClass('error')
            },
            submitHandler: function(form) 
            { 
                form.submit();
            }
        });



       $('#mollie_form').validate(
        {
            rules: {
                amount: {
                  required: true,
                  number: true,
                },
                narration: {
                    required: true
                }
            },
            messages: {
                amount: {
                    required: "Please enter amount",
                    number: "Only enter numbers as decimal or float"
                }
            },
            invalidHandler: function(form, validator) {
                if (!validator.numberOfInvalids())
                {
                    return;
                }
                else
                {
                    var error_element=validator.errorList[0].element;
                    error_element.focus();
                }
            },
            highlight: function (element) {
                //$(element).parent().addClass('error')
            },
            unhighlight: function (element) {
                $(element).parent().removeClass('error')
            },
            submitHandler: function(form) 
            { 
                form.submit();
            }
        });



        function getcurrency(ids,texts)
    { 
      var txt = texts.options[texts.selectedIndex].text;
      var namer = ids.split("_");
      var id = namer[0];
      var cname = namer[1];
      var bal =  namer[2];
      var type =  namer[3]; 

      $('#currency_id').val(id); 
      $('#banwire_id').val(id);  
      $('#mollie_id').val(id);   
       

      if(type=='fiat')
      {
        $(".fiat_payment").css('display','block');
        $(".digital-div").css('display','none');
      }
      else
      {
        $(".fiat_payment").css('display','none');
        $(".digital-div").css('display','block');
      }

         $.ajax({

                url: base_url+"change_address",
                type: "POST",
                data: "currency_id="+id,
                success: function(data) {
                  var res = jQuery.parseJSON(data);
                 
                  $('#tot_balance').html(res.coin_balance);
                  $('#balsym').html(res.coin_symbol);
                  $('.sym').html(res.coin_symbol);
                  $('#fees_type').val(res.withdraw_type);
                  $('#fees').val(res.withdraw_fees);
                  // console.log(res);
                  calculate();
 
                  
                }

            }); 
 


    }
function calculate(){
    
    var fees_type = $('#fees_type').val();
    var fees = $('#fees').val();
    // console.log(fees_type);

    var amount = $('#amount').val();

    if(amount!='') {


    if(fees_type=='Percent'){
        var fees_p = ((parseFloat(amount) * parseFloat(fees))/100);
        var amount_receive = parseFloat(amount) - parseFloat(fees_p);
        // console.log(amount_receive);
    }
    else{
        var fees_p = fees;
        var amount_receive = parseFloat(amount) - parseFloat(fees_p);
        // console.log(amount_receive);
    }
    $('#fees_p').html(fees_p.toFixed(8));
    if(amount_receive<=0){
      $('#amount_receive').html('0');
      $('#amount_receive_error').html('Please enter valid amount');
    }
    else{
      $('#amount_receive_error').html('');
    $('#amount_receive').html(amount_receive.toFixed(8)); 
  }

 }
 else
 {  
  $('#fees_p').html(0);
  $('#amount_receive').html(0); 

 } 

}



</script>

  </body>
</html>