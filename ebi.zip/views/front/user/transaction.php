<?php $this->load->view('front/user/login_header');
      $settings = $site_common['site_settings']; 
      ?>


<div class="content-body">
            <div class="container-fluid">
                <div class="row">
                <div class="col-md-12">
                    <div class="card">
                    <div class="history-tabs card-body">
                       <ul class="nav nav-pills pt-3" id="pills-tab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active deposit_tab" data-toggle="tab" href="#Deposit"><?php echo $this->lang->line('Deposit')?></a>
                            </li>
                            <li class="nav-item" style="cursor: pointer;">
                                <a  class="nav-link withdraw_tab" data-toggle="tab" href="#Withdraw"><?php echo $this->lang->line('Withdraw')?></a>
                            </li>




                        </ul>
                        <hr>
                        <div class="tab-content">
                            <div id="Deposit" class="tab-pane active">
                                <div class="block">
                                    <h5 class="block_title mb-3"><?php echo $this->lang->line('Deposit')?></h5>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="deposit_right mb-2">
                                                <div class="mb-2">
                                                    <label class="label_inner"><?php echo $this->lang->line('Select Your Currency')?> :</label>
                                                    <select id="crypto_curr" onChange="change_address(this)" class="form-control select_inner">
                                                        <?php if(count($all_currency)>0) { foreach($all_currency as $currency){ ?>
                                           <!--  <option value="<?php echo $currency->id;?>_<?php echo $currency->type;?>"><?php echo $currency->currency_name;?> (<?php echo strtolower($currency->currency_symbol);?>)</option> -->

                                            <option value="<?php echo $currency->id.'#'.$currency->type.'#'.$currency->currency_symbol;?>" <?=($sel_currency->id == $currency->id)?'selected':''?>>
                                              <?=$currency->currency_symbol?>
                                              </option>


                                            <?php } } ?>
                                                    </select>
                                                </div>
                                                <div class="your_balance">
                                                    <ul>
                                                        <li><?php echo $this->lang->line('Total Balance')?>: <span id="tot_balance"></span></li>
                                                        <!-- <li>In Order: <span>0.005400 CRC</span></li> 
                                                        <li>Available Balance: <span>0.005400 CRC</span></li>-->
                                                    </ul>
                                                </div>
                                            </div>

                                            <div class="det_tag" style="display: none;">
                                                <div class="form-group text-left">
                                                      <label class="label_inner">Destination Tag</label>
                                                      <input type="text" class="form-control" value="<?php echo $destination_tag;?>" id="destination_tag">
                                                    </div>
                                            </div>


                                        </div>
                                        <div class="col-md-6">
                                            <div class="deposit_left card-body">
                                                <h5><?php echo $this->lang->line('Scan QR Code')?>  <?php echo $this->lang->line('OR send funds to the below Address')?></h5>


                                                <div class="deposit_left_inner d-flex align-items-center">
                                                    <span>
                                                        <img src="<?=base_url();?>assets/front/inner/img/qr_code.svg" alt="qr_code" width="125px;" id="crypto_img" class="img-fluid">
                                                    </span>

                                                </div>
                                                <label class="mt-3"> <?php echo $this->lang->line('Address')?> :</label>
                                                <span id="crypto_address"></span>

                                                <a  class="btn btn-success waves-effect waves-light button" href="javascript:;" onclick="copyToClipboard('<?php echo $secret;?>')">  <?php echo $this->lang->line('Copy');?></a>

                                            </div>

                                            <div class="fiat_payment" style="display: none;">

                                                <div class="text-center">
                                                <!-- <a  class="btn btn-success waves-effect waves-light button" href="javascript:;" style="margin-right:20px;"  data-toggle="modal" data-target="#paypal_deposit" data-dismiss="modal" aria-label="Close">Paypal</a>

                                                 <a  class="btn btn-success waves-effect waves-light button" href="javascript:;" data-toggle="modal" data-target="#perfectmoney_deposit" data-dismiss="modal" aria-label="Close">PerfectMoney</a> -->


                                                </div>

                                            </div>



                                        </div>
                                        <div class="col-md-12">
                                            <ul class="note">
                                                <span><?php echo $this->lang->line('Note')?> :</span>
                                                <li><?php echo $this->lang->line('Coins will be deposited after network confirmations')?></li>
                                                <li><?php echo $this->lang->line('After making a deposit, you can track its progress on the history page')?></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="block p-3">
                                    <div class="table_panel_heading mb-4 d-flex justify-content-between align-items-center">
                                        <h2><?php echo $this->lang->line('Deposit History')?></h2>
<!--                                         <input type="text" class="form-control search_input" id="search" placeholder="Search">
 -->                                    </div>
                                     <div class="table_inner">
                                        <div class="table_responsive">
                                            <table id="deposit-1" class="table display table-borderless" style="width:100%">
                                                <thead>
                                                    <tr>
                                                        <th><?php echo $this->lang->line('S.no')?></th>
                                                        <th><?php echo $this->lang->line('Date & Time')?></th>
                                                        <th><?php echo $this->lang->line('Currency')?></th>
                                                        <th><?php echo $this->lang->line('Transaction ID')?></th>
                                                        <th><?php echo $this->lang->line('Deposit Amount')?></th>
                                                        <th><?php echo $this->lang->line('Address')?></th>
                                                        <th><?php echo $this->lang->line('Status')?></th>
                                                    </tr>
                                                </thead>
                                               <tbody>
                                    <?php
                                        if(isset($deposit_history) && !empty($deposit_history))
                                        {
                                            $a=0;
                                           foreach($deposit_history as $deposit)
                                           {
                                            $a++;
                                            if($deposit->transaction_id == '')
                                            {
                                              $transaction_id = '-';
                                            }
                                            else
                                            {
                                              $transaction_id = $deposit->transaction_id;
                                            }     
                                            ?>

                                                    <tr>
                                            <td><?php echo $a;?></td>
                                            <td><?php echo $deposit->datetime;?></td>
                                            <td><?php echo strtoupper(getcryptocurrency($deposit->currency_id));?></td>
                                            <td>#<?php echo $transaction_id;?></td>
                                            <td><?php echo number_format($deposit->amount,8);?></td>
                                            <td><?php echo $deposit->crypto_address;?></td>
                                            <?php if($deposit->status =='Completed')
                                            {
                                              $clr_class = 'text-green';

                                            }
                                            else
                                            {
                                              $clr_class = 'text-red';
                                            } ?>                   
                                             
                                            <td class="<?php echo $clr_class;?>"><?php echo $deposit->status;?></td>
                                        </tr>
                                                  <?php } } ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="Withdraw" class="tab-pane fade">
                                <div class="block">
                                    <h5 class="block_title mb-2"><?php echo $this->lang->line('Withdraw')?></h5>
                        <?php 
                        $attributes=array('id'=>'deposit_withdraw_coin');
                        $action1 = base_url().'transaction';
                        echo form_open($action1,$attributes);
                        ?>
                        <input type="hidden" name='ids' id="ids" value="">

                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="mb-3">
                                                <label class="label_inner"><?php echo $this->lang->line('Select Your Currency')?></label>
                                                 <input type="hidden" name="fees_type" id="fees_type" value="<?php echo $fees_type;?>">
                                                  <input type="hidden" name="fees" id="fees" value="<?php echo $fees;?>">

                                                <select class="form-control select_inner" onChange="change_witaddress(this)" id="cryptos_curr">
                                     <?php
                                          foreach($all_currency as $currency){
                                            ?>
                                            <option value="<?php echo $currency->id.'#'.$currency->type.'#'.$currency->currency_symbol;?>" <?=($sel_currency->id == $currency->id)?'selected':''?>><?php echo $currency->currency_name;?> (<?php echo strtoupper($currency->currency_symbol);?>)</option>
                                            <?php
                                          }
                                          ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4 cryp_add">
                                            <div class="form-group  form_inner mb-3">
                                                <label class="label_inner"><span id="withdraw_curr"></span> <?php echo $this->lang->line('Wallet Address')?></label>
                                                <input id="address" name="address" type="text" class="form-control" placeholder="<?php echo $this->lang->line('Enter Wallet Address')?>">
                                            </div>
                                        </div>
                                        <div class="col-md-4 cryp_amt">
                                            <div class="form-group form_inner mb-3">
                                                <label class="label_inner"><?php echo $this->lang->line('Amount of')?> <span id="withdraw_amt"></span> <?php echo $this->lang->line('to Wallet')?></label>
                                                <input type="text" class="form-control" id="amount" name="amount" placeholder="<?php echo $this->lang->line('Enter BTC Amount')?>" onkeyup="calculate1();">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="det_tag_with" style="display: none;">
                                                <div class="form-group form_inner mb-3">
                                                      <label class="label_inner">Destination Tag</label>
                                                      <input type="text" class="form-control" value="<?php echo $destination_tag;?>" id="destination_tag">
                                                    </div>
                                            </div>
                                         </div>   

                                          <div class="col-md-4">
                                            <div class="perfect_div" style="display: none;">
                                                <div class="form-group form_inner mb-3">
                                                      <label class="label_inner">Account ID</label>
                                                      <input type="text" class="form-control" value="<?php echo $user->perfect_account;?>" id="destination_tag" readonly>
                                                    </div>
                                            </div>
                                         </div>   

                                        <div class="col-md-12">

                                           <div class="crypto_withdraw" style="display: none;"> 
                                            <div class="text-center">
                                                <input type="submit" name="withdrawcoin" class="btn btn-success waves-effect waves-light button" value="<?php echo $this->lang->line('Submit')?>"  />
                                            </div>
                                          </div> 

                                          <div class="fiat_withdraw">
                                            <div class="text-center">


                                               <!--  <input type="submit" name="paypal_withdraw" class="btn btn-success waves-effect waves-light button" value="Paypal" />

                                                <input type="submit" name="perfect_withdraw" class="btn btn-success waves-effect waves-light button" value="PerfectMoney" /> -->

                                           <!--  <a  class="btn btn-success waves-effect waves-light button" href="javascript:;" style="margin-right:20px;"  data-toggle="modal" data-target="#paypal_withdraw" data-dismiss="modal" aria-label="Close">Paypal</a>

                                            <a  class="btn btn-success waves-effect waves-light button" href="javascript:;" data-toggle="modal" data-target="#perfectmoney_withdraw" data-dismiss="modal" aria-label="Close">PerfectMoney</a> -->
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <ul class="note mb-md-0 mb-2">
                                                <li><?php echo $this->lang->line('Transaction Fees')?>: <small id="withdraw_fee">0.0056</small></li>
                                                <li><?php echo $this->lang->line('You will Get')?>: <small id="withdraw_limit">0.0056 BTC</small></li>
                                            </ul>
                                        </div>
                                        
                                    </div>
                                     <?php echo form_close();?>
                                </div>
                                <div class="block p-3">
                                  <div class="table_panel_heading mb-4 d-flex justify-content-between align-items-center">
                                        <h2><?php echo $this->lang->line('Withdraw History')?></h2>
<!--                                         <input type="text" class="form-control search_input" id="search" placeholder="Search">
 -->                                    </div>  
                                    <div class="table_inner">
                                        <div class="table_responsive">
                                             <table id="withdraw-1" class="table display table-borderless" style="width:100%">
                                                <thead>
                                                    <tr>
                                                        <th><?php echo $this->lang->line('S.no')?></th>
                                                        <th><?php echo $this->lang->line('Date & Time')?></th>
                                                        <th><?php echo $this->lang->line('Currency')?></th>
                                                        <th><?php echo $this->lang->line('Send Amount')?></th>
                                                        <th><?php echo $this->lang->line('Fees')?></th>
                                                        <th><?php echo $this->lang->line('Receive Amount')?></th>
                                                        <th><?php echo $this->lang->line('Status')?></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                     <?php
                                    if(isset($withdraw_history) && !empty($withdraw_history)){
                                    $b=0;
                                    foreach($withdraw_history as $withdraw){
                                    $b++;
                                    ?>
                                                   <tr>
                                            <td><?php echo $b;?></td>
                                            <td><?php echo gmdate("d-m-Y h:i:s", $withdraw->datetime);?></td>
                                            <td><?php echo strtoupper(getcryptocurrency($withdraw->currency_id));?></td>
                                            <td><?php echo number_format($withdraw->amount,8);?></td>
                                            <td><?php echo number_format($withdraw->fee,8);?></td>
                                            <td><?php echo number_format($withdraw->transfer_amount,8);?></td>
                                             <?php 
                                              if($withdraw->status =='Completed')
                                              {
                                                $elmt_class = 'text-green';

                                              }
                                              else
                                              {
                                                $elmt_class = 'text-red';
                                              } ?> 
                                                <td class="<?php echo $elmt_class; ?>"><?php echo $withdraw->status;?></td>
                                          </tr>
                                                   <?php } } ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


<!--Deposit paypal modal -->
<div class="modal fade right" id="paypal_deposit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true"> 
  
  <!-- Add class .modal-full-height and then add class .modal-right (or other classes from list above) to set a position to the modal -->
  <div class="modal-dialog modal-full-height modal-right iks-popup" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title w-100" id="myModalLabel">Paypal <?php echo $this->lang->line('Deposit');?></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
      </div>
      <div class="modal-body">
        <div class="col-sm-12">
              <div class="row">
                <div class="col-sm-12 deposit-address bank_wire">
                  <?php  $action = base_url()."paypal";
       $attributes = array('id'=>'paypal_form','autocomplete'=>"off"); 
        echo form_open($action,$attributes); 
                                        ?>     
                  <input type="hidden" name="currency" class="currency" value="<?php echo $all_currency[0]->id;?>" >
                  <div class="form-row">
                    <div class="col-8 col-md-8">
                      <div class="row">
                        <div class="col-12 col-md-12">
                          <label for="basic-url"><?php echo $this->lang->line('Enter amount');?><span style="color: red;">*</span></label>
                          <div class="mb-3">
                            <input type="text" class="form-control input_anim" aria-label="Small" aria-describedby="inputGroup-sizing-sm" name="amount">
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-12 col-md-12">
                      <div class="row">
                        <div class="col-12 col-md-12">
                          <div class="profile-flex border-0 pt-4 pull-left">
                            <div class="text-center">
                              <button name="deposit_paypal" id="deposit_paypal" class="btn btn-success waves-effect waves-light button" type="submit"> <?php echo $this->lang->line('Deposit');?> </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <?php echo form_close();?> </div>
              </div>
            </div>
       </div>
    
    </div>
  </div>
</div>
<!-- Deposit End paypal modal -->




<!--Deposit PerfectMoney modal -->
<div class="modal fade right" id="perfectmoney_deposit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true"> 
  
  <!-- Add class .modal-full-height and then add class .modal-right (or other classes from list above) to set a position to the modal -->
  <div class="modal-dialog modal-full-height modal-right iks-popup" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title w-100" id="myModalLabel">PerfectMoney <?php echo $this->lang->line('Deposit');?></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
      </div>
      <div class="modal-body">
        <div class="col-sm-12">
              <div class="row">
                <div class="col-sm-12 deposit-address bank_wire">
                 <form action="https://perfectmoney.is/api/step1.asp" id="perfect_form" method="POST"> 

                  <input type="hidden" name="PAYEE_ACCOUNT" value="<?php echo $user->perfect_account;?>">
                  <input type="hidden" name="PAYEE_NAME" value="<?php  echo $perfect_account_name;?>">
                  <input type='hidden' name='PAYMENT_ID' value='<?=time() ?>'>
                  <input type="hidden" name="PAYMENT_UNITS" value="USD">
                  <input type="hidden" name="STATUS_URL" value="<?php echo base_url();?>perfectmoney_success">
                  <input type="hidden" name="PAYMENT_URL" value="<?php echo base_url();?>perfectmoney_success">
                  <input type="hidden" name="PAYMENT_URL_METHOD" value="POST">
                  <input type="hidden" name="NOPAYMENT_URL" value="<?php echo base_url();?>perfectmoney_cancel">
                  <input type="hidden" name="NOPAYMENT_URL_METHOD" value="POST">
                  <input type="hidden" name="SUGGESTED_MEMO" id="perf_cur" value="">


                  <input type="hidden" name="currency" class="currency" id="cur_id" value="<?php echo $all_currency[0]->id;?>" >
                  <div class="form-row">
                    <div class="col-8 col-md-8">
                      <div class="row">
                        <div class="col-12 col-md-12">
                          <label for="basic-url"><?php echo $this->lang->line('Enter amount');?><span style="color: red;">*</span></label>
                          <div class="mb-3">
                            <input type="text" class="form-control input_anim" aria-label="Small" aria-describedby="inputGroup-sizing-sm" id="PAYMENT_AMOUNT" name="PAYMENT_AMOUNT" onChange="perfect_check(this)">
                          </div>
                        </div>

                        <div class="col-12 col-md-12">
                          <label for="basic-url">Description</label>
                          <div class="mb-3">
                           <textarea class="form-control input_anim"  name="SUGGESTED_MEMO" id="SUGGESTED_MEMO"></textarea>
                          </div>
                        </div>


                      </div>
                    </div>
                    <div class="col-12 col-md-12">
                      <div class="row">
                        <div class="col-12 col-md-12">
                          <div class="profile-flex border-0 pt-4 pull-left">
                            <div class="text-center">
                              <button name="deposit_perfect" id="deposit_perfect" class="btn btn-success waves-effect waves-light button" type="submit"> <?php echo $this->lang->line('Deposit');?> </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                 </form> </div>
              </div>
            </div>
       </div>
    
    </div>
  </div>
</div>
<!-- Deposit End PerfectMoney modal -->

<!-- Withdraw  PerfectMoney--->

<!--Deposit PerfectMoney modal -->
<div class="modal fade right" id="perfectmoney_withdraw" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true"> 
  
  <!-- Add class .modal-full-height and then add class .modal-right (or other classes from list above) to set a position to the modal -->
  <div class="modal-dialog modal-full-height modal-right iks-popup" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title w-100" id="myModalLabel">PerfectMoney <?php echo $this->lang->line('Withdraw');?></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
      </div>
      <div class="modal-body">
        <div class="col-sm-12">
              <div class="row">
                <div class="col-sm-12 deposit-address bank_wire">
                 <?php
                    $action = front_url()."withdraw/GHS";
                    $attributes = array('id'=>'withdraw_perfect','autocomplete'=>"off"); 
                    echo form_open($action,$attributes); 
                                        ?>

                  <input type="hidden" name="currency" class="currency" id="cur_id" value="<?php echo $all_currency[0]->id;?>" >
                  <div class="form-row">
                    <div class="col-8 col-md-8">
                      <div class="row">
                        <div class="col-12 col-md-12">
                          <label for="basic-url"><?php echo $this->lang->line('Enter amount');?><span style="color: red;">*</span></label>
                          <div class="mb-3">
                            <input type="text" class="form-control input_anim" aria-label="Small" aria-describedby="inputGroup-sizing-sm" id="amount" name="amount">
                          </div>
                        </div>


                        <div class="col-12 col-md-12">
                          <label for="basic-url">Account ID<span style="color: red;">*</span></label>
                          <div class="mb-3">
                            <input type="text" class="form-control input_anim" aria-label="Small" aria-describedby="inputGroup-sizing-sm" id="account_id" name="account_id" readonly="" value="<?php echo $users->perfect_account;?>">
                          </div>
                        </div>

                        <div class="col-12 col-md-12">
                          <label for="basic-url">Account Name<span style="color: red;">*</span></label>
                          <div class="mb-3">
                            <input type="text" class="form-control input_anim" aria-label="Small" aria-describedby="inputGroup-sizing-sm" id="pay_name" name="pay_name" readonly="" value="<?php echo $users->perfect_account_name;?>">
                          </div>
                        </div>

                        <div class="col-12 col-md-12">
                          <label for="basic-url">Description</label>
                          <div class="mb-3">
                           <textarea class="form-control input_anim"  name="SUGGESTED_MEMO" id="SUGGESTED_MEMO"></textarea>
                          </div>
                        </div>


                      </div>
                    </div>
                    <div class="col-12 col-md-12">
                      <div class="row">
                        <div class="col-12 col-md-12">
                          <div class="profile-flex border-0 pt-4 pull-left">
                            <div class="text-center">
                              <button name="perfect_withdraw" id="perfect_withdraw" class="btn btn-success waves-effect waves-light button" type="submit"> <?php echo $this->lang->line('Withdraw');?> </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                <?php echo form_close();?></div>
              </div>
            </div>
       </div>
    
    </div>
 </div>
</div>





<!-- Withdraw paypal Start-->
<div class="modal fade right" id="paypal_withdraw" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true"> 
  
  <!-- Add class .modal-full-height and then add class .modal-right (or other classes from list above) to set a position to the modal -->
  <div class="modal-dialog modal-full-height modal-right iks-popup" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title w-100" id="myModalLabel">Paypal <?php echo $this->lang->line('Withdraw');?></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
      </div>
      <div class="modal-body">
        <div class="col-sm-12">
              <div class="row">
                <div class="col-sm-12 deposit-address bank_wire">
                  <?php  $action = base_url()."paypal_withdraw";
       $attributes = array('id'=>'paypal_form','autocomplete'=>"off"); 
        echo form_open($action,$attributes); 
                                        ?>     
                  <input type="hidden" name="currency" class="currency" value="<?php echo $all_currency[0]->id;?>" >
                  <div class="form-row">
                    <div class="col-8 col-md-8">
                      <div class="row">
                        <div class="col-12 col-md-12">
                          <label for="basic-url"><?php echo $this->lang->line('Enter amount');?><span style="color: red;">*</span></label>
                          <div class="mb-3">
                            <input type="text" class="form-control input_anim" aria-label="Small" aria-describedby="inputGroup-sizing-sm" name="amount" id="pay_with_amt" onChange="paypal_check(this)">
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-12 col-md-12">
                      <div class="row">
                        <div class="col-12 col-md-12">
                          <div class="profile-flex border-0 pt-4 pull-left">
                            <div class="text-center">
                              <button name="withdraw_paypal" id="withdraw_paypal" class="btn btn-success waves-effect waves-light button" type="submit"> <?php echo $this->lang->line('Withdraw');?> </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <?php echo form_close();?> </div>
              </div>
            </div>
       </div>
    
    </div>
  </div>


                                    </div>
                                </div>
                            </div>


<!-- Withdraw paypal End-->

<!--- PerfectMoney--- End -->

    <!--- Data Tables  --->
     <script src="<?php echo front_js();?>datatables.bootstrap4.min.js"></script>
     <script src="<?php echo front_js();?>dataTables.min.js"></script>
     <script src="<?php echo front_js();?>datatables.bootstrap4.js"></script>
 
<script type="text/javascript">
$(document).ready(function() {

  var language = '<?php echo  $lang_id = $this->session->userdata('site_lang'); ?>';

  if(language=='spanish')
  {

    $('table.display').DataTable( {

       "language": {
              
            "sProcessing": "Procesando ...",
            "sLengthMenu": "Show _MENU_ registros",
            "sZeroRecords": "No se han encontrado resultados",
            "sEmptyTable": "No hay datos disponibles en esta tabla.",
            "sInfo": "Showing registros from _START_ to _END_ of a total of _TOTAL_ registros",
            "sInfoEmpty": "Mostrando registros de 0 to 0 out of a total of 0 registros",
            "sInfoFiltered": "(filtrando un total de _MAX_ registros)",
            "sInfoPostFix": "",
            "sSearch": "búsqueda:",
            "sUrl": "",
            "sInfoThousands": ",",
            "sLoadingRecords": "Cargando ...",
            "oPaginate": {
              "sFirst": "Primera",
              "sLast": "Última",
              "sNext": "Próxima",
              "sPrevious": "Previa"
            },
            "oAria": {
              "sSortAscending": ": Activate to sort the column in ascending order",
              "sSortDescending": ": Activate to sort the column in descending order"
            }


        }
    } );

  }
  else if(language=='italic')
  {
     $('table.display').DataTable( {
       "language": {
              
            "sProcessing": "in lavorazione ...",
            "sLengthMenu": "Mostra _MENU_ inserimenti",
            "sZeroRecords": "nessun risultato trovato",
            "sEmptyTable": "Nessun dato disponibile in questa tabella",
            "sInfo": "Visualizzazione del inserimenti da _START_ a _END_ di un totale di _TOTAL_ inserimenti",
            "sInfoEmpty": "Mostra inserimenti da 0 a 0 su un totale di 0 inserimenti",
            "sInfoFiltered": "(filtrando un totale di _MAX_ inserimenti)",
            "sInfoPostFix": "",
            "sSearch": "ricerca:",
            "sUrl": "",
            "sInfoThousands": ",",
            "sLoadingRecords": "Caricamento in corso ...",
            "oPaginate": {
              "sFirst": "Primo",
              "sLast": "Ultimo",
              "sNext": "Prossimo",
              "sPrevious": "Precedente"
            },
            "oAria": {
              "sSortAscending": ": Activate to sort the column in ascending order",
              "sSortDescending": ": Activate to sort the column in descending order"
            }


        }

    });

  }

  else
  {

    $('table.display').DataTable();


  }


} );

</script>
<?php $this->load->view('front/common/login_footer');
 
 $default_coin = $all_currency[0]->id; 
 $default_type = $all_currency[0]->type;

?>



           <script>

    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';
     var base_url = '<?php echo base_url();?>';
     var front_url='<?php echo front_url();?>';


    $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
        if (options.type.toLowerCase() == 'post') {
            options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
            if (options.data.charAt(0) == '&') {
                options.data = options.data.substr(1);
            }
        }
    });

    $( document ).ajaxComplete(function( event, xhr, settings ) {
        if (settings.type.toLowerCase() == 'post') {
            $.ajax({
                url: front_url+"get_csrf_token", 
                type: "GET",
                cache: false,             
                processData: false,      
                success: function(data) {

                     $("input[name="+csrfName+"]").val(data);
                }
            });
        }
    });

    function perfect_check(amt)
        {

           var amt =  $("#PAYMENT_AMOUNT").val();  
            $.ajax({
                    url: base_url+"perfectmoney_check",
                    type: "POST",
                    data: "PAYMENT_AMOUNT="+amt,
                    success: function(data) {
                        
                        if(data!='')
                        {
                            $.growl.error({title: "Cripyicexchange", message: data });
                            document.getElementById("deposit_perfect").disabled = true;
                        }
                        else
                        {
                            document.getElementById("deposit_perfect").disabled = false;
                        }
                    }
                });


        }


    function paypal_check(amt)
        {

          var amt =  $("#pay_with_amt").val();

            $.ajax({
                    url: base_url+"paypal_check",
                    type: "POST",
                    data: "amount="+amt,
                    success: function(data) {
                        
                        if(data!='')
                        {
                            $.growl.error({title: "Cripyicexchange", message: data });
                            document.getElementById("withdraw_paypal").disabled = true;
                        }
                        else
                        {
                            document.getElementById("withdraw_paypal").disabled = false;
                        }
                    }
                });


        }



  $(document).ready(function(){

    var defa_type = '<?php echo $default_type;?>';
    var defa_coin = '<?php echo $default_coin;?>';
    var recs = $("#crypto_curr").val();

    change_address(recs);
    change_witaddress(recs);
   });

$.validator.addMethod("noSpace", function(value, element) { 
  return value.indexOf(" ") < 0 && value != ""; 
}, "No space please and don't leave it empty");


// Jquery Start //



        $("#deposit_withdraw_coin").validate({
          rules: {
                  address: {
                    required: true,
                    noSpace: true
                  },
                  amount: {
                    required: true,
                    number:true
                  },
                  ids: {
                    required: true
                  },
                  destination_tag: {
                    number: true
                  }
                },
          messages: {
                address: {
                  required: "Please enter address"
                },
                amount: {
                  required: "Please <?php echo $this->lang->line('Enter amount');?>",
                  number: "Invalid Amount"
                },
                ids: {
                  required: "Please select currency"
                },
                  destination_tag: {
                    number: 'Please enter numbers only'
                  }
              },
              submitHandler: function(form) 
        { 
    var fees_type = $('#fees_type').val();
    var fees = $('#fees').val();

    var amount = $('#amount').val();

    if(fees_type=='Percent'){
        var fees_p = ((parseFloat(amount) * parseFloat(fees))/100);
        var amount_receive = parseFloat(amount) - parseFloat(fees_p);
    }
    else{
        var fees_p = fees;
        var amount_receive = parseFloat(amount) - parseFloat(fees_p);
    }
    if(parseFloat(amount_receive)<=0){
      $.growl.error({ message: 'Please enter valid amount' });
      return false;
    }
    else if(parseFloat(amount)<=parseFloat(fees_p)){
     
      $.growl.error({ message: 'Please enter valid amount' });
      return false;
    }
    else{
      form.submit();
    }
        }     
         });




        $('#withdraw_perfect').validate(
        {
            rules: {
              
              pay_name:{
                required: true
              },
                amount: {
                  required: true,
                  number: true,
                }
            },
            messages: {
              
              pay_name:{
                required: 'Please enter name',
              },
                amount: {
                    required: "Please <?php echo $this->lang->line('Enter amount');?>",
                    number: "Only enter numbers as decimal or float"
                }
            },
            invalidHandler: function(form, validator) {
                if (!validator.numberOfInvalids())
                {
                    return;
                }
                else
                {
                    var error_element=validator.errorList[0].element;
                    error_element.focus();
                }
            },
            highlight: function (element) {
                //$(element).parent().addClass('error')
            },
            unhighlight: function (element) {
                $(element).parent().removeClass('error')
            },
            submitHandler: function(form) 
            { 
                form.submit();
            }
        });




        $('#paypal_withdraw').validate(
        {
            rules: {
              
              
                pay_with_amt: {
                  required: true,
                  number: true,
                }
            },
            messages: {
            
                pay_with_amt: {
                    required: "Please <?php echo $this->lang->line('Enter amount');?>",
                    number: "Only enter numbers as decimal or float"
                }
            },
            invalidHandler: function(form, validator) {
                if (!validator.numberOfInvalids())
                {
                    return;
                }
                else
                {
                    var error_element=validator.errorList[0].element;
                    error_element.focus();
                }
            },
            highlight: function (element) {
                //$(element).parent().addClass('error')
            },
            unhighlight: function (element) {
                $(element).parent().removeClass('error')
            },
            submitHandler: function(form) 
            { 
                form.submit();
            }
        });


       $('#paypal_form').validate(
        {
            rules: {
             
                amount: {
                  required: true,
                  number: true,
                }
            },
            messages: {
              
              amount: {
                    required: "Please <?php echo $this->lang->line('Enter amount');?>",
                    number: "Only enter numbers as decimal or float"
                }
            },
            invalidHandler: function(form, validator) {
                if (!validator.numberOfInvalids())
                {
                    return;
                }
                else
                {
                    var error_element=validator.errorList[0].element;
                    error_element.focus();
                }
            },
            highlight: function (element) {
                //$(element).parent().addClass('error')
            },
            unhighlight: function (element) {
                $(element).parent().removeClass('error')
            },
            submitHandler: function(form) 
            { 
                form.submit();
            }
        });




        $('#perfect_form').validate(
        {
            rules: {
             
                PAYMENT_AMOUNT: {
                  required: true,
                  number: true,
                }
            },
            messages: {
              
              PAYMENT_AMOUNT: {
                    required: "Please <?php echo $this->lang->line('Enter amount');?>",
                    number: "Only enter numbers as decimal or float"

                }
            },
            invalidHandler: function(form, validator) {
                if (!validator.numberOfInvalids())
                {
                    return;
                }
                else
                {
                    var error_element=validator.errorList[0].element;
                    error_element.focus();
                }
            },
            highlight: function (element) {
                //$(element).parent().addClass('error')
            },
            unhighlight: function (element) {
                $(element).parent().removeClass('error')
            },
            submitHandler: function(form) 
            { 
                form.submit();
            }
        });


// Jquery End //





 function change_address(cur)
 {

    var arr1 = $("#crypto_curr option:selected").val();
    var arr = arr1.split('#');
    var currency_id = arr[0];
    var type = arr[1];
    var symbol = arr[2];
    $("#cur_id").val(currency_id);
    $('#perf_cur').val(currency_id);

  // var currency_id = $("#crypto_curr option:selected").val();
    $.ajax({

                url: base_url+"change_address",
                type: "POST",
                data: "currency_id="+currency_id,
                success: function(data) {
                  var res = jQuery.parseJSON(data);
                  $('#crypto_address').html(res.address);
                  $("#crypto_img").attr("src",res.img);
                  $('#curr_name').html(res.currname);
                  $('#tot_balance').html(res.coin_balance+' '+res.coin_symbol);
                    
                  if(type=='fiat')
                   {  
                    
                    $(".deposit_left").css('display','none');
                    $(".fiat_payment").css('display','block');

                   }
                   else
                   {

                    $(".deposit_left").css('display','block');
                    $(".fiat_payment").css('display','none');

                        if(symbol=='XRP')
                        {

                            $('.det_tag').css('display','block');
                            $('#destination_tag').val(res.destination_tag);

                        }
                        else
                        {
                            $('.det_tag').css('display','none');
                        }

                        



                   }

                }

            });
  }

 



  function change_witaddress(cur)
  {
   var arr1 = $("#cryptos_curr option:selected").val();
    var arr = arr1.split('#');
    var currency_id = arr[0];
    var type = arr[1];
    var sym = arr[2];




    $.ajax({

                url: base_url+"change_address",
                type: "POST",
                data: "currency_id="+currency_id,
                success: function(data) {
                  var res = jQuery.parseJSON(data);
                  $('#withdraw_curr').text(res.coin_symbol);
                  $('#withdraw_amount').text(res.coin_symbol);
                  $('#amount').attr("placeholder","Enter "+res.coin_symbol+" Amount");
                  $('#withdraw_fee').text(res.withdraw_fees);

                  $('#fees_type').text(res.withdraw_fees_type);
                  $('#fees').text(res.withdraw_fees);

                  $("#withdraw_limit").text(res.withdraw_limit+' '+res.coin_symbol);
                    

                    if(type=='fiat')
                   {  
                    
                    $(".crypto_withdraw").css('display','none');
                    $(".fiat_withdraw").css('display','block');
                    $(".cryp_add").css('display','none');
                    $(".cryp_amt").css('display','none');
                    
                    

                   }
                   else
                   {

                    $(".crypto_withdraw").css('display','block');
                    $(".fiat_withdraw").css('display','nonne');
                    $(".cryp_add").css('display','block');
                    $(".cryp_amt").css('display','block');


                        if(sym=='XRP')
                        {

                            $('.det_tag_with').css('display','block');
                            $('#destination_tag').val(res.destination_tag);

                        }

                        else
                        {
                            $('.det_tag_with').css('display','none');
                        }


                   }


                }
            });
    $('#ids').val(currency_id);
  }




function calculate1(){
    
    var fees_type = $('#fees_type').val();
    var fees = $('#fees').val();

    var amount = $('#amount').val();


    if(fees_type=='Percent'){
        var fees_p = ((parseFloat(amount) * parseFloat(fees))/100);
        var amount_receive = parseFloat(amount) - parseFloat(fees_p);
    }
    else{
        var fees_p = fees;
        var amount_receive = parseFloat(amount) - parseFloat(fees_p);
    }
    $('#withdraw_fee').html(fees_p);



    if(amount_receive<=0){
      $('#withdraw_limit').html('0');
      //$('#amount_receive_error1').html('Please enter valid amount');
    }
    else{
      //$('#amount_receive_error1').html('');
    $('#withdraw_limit').html(amount_receive);
  }
}


var url = window.location.href;
var activeTab = url.substring(url.indexOf("#") + 1);
if(activeTab=="deposit")
{
$(".deposit_tab").trigger("click");
}
else if(activeTab=="withdraw")
{
$(".withdraw_tab").trigger("click");
}


 // var hash = window.location.hash;
 //  var cur_hash = hash.substr(1);
 //  if(cur_hash=="deposit")
 //  {
 //    $(".deposit_tab").trigger("click");
 //  }
 //  else if(cur_hash=="withdraw")
 //  {
 //    $(".withdraw_tab").trigger("click");
 //  }

 //  $(".deposit_tab").click(function(){
 //   var hash_char1='#deposit';
 //    $(location).attr('href','<?php echo base_url();?>transaction'+hash_char1);
 //  });

 //  $(".withdraw_tab").click(function(){
 //   var hash_char2='#withdraw';
 //    $(location).attr('href','<?php echo base_url();?>transaction'+hash_char2);
 //  });



function copyToClipboard(text) {
    var copyText = document.getElementById("crypto_address");  
    var input = document.createElement("textarea");
    input.value = copyText.textContent;
    document.body.appendChild(input);
    input.select();
    document.execCommand("Copy");
    input.remove();
}


</script>