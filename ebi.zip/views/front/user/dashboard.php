<?php
    $this->load->view('front/user/login_header');
      $settings = $site_common['site_settings']; 
      $usermail = getUserEmail($users->id);
      if($users->verify_level2_status=="" || $users->verify_level2_status=="Pending" || $users->verify_level2_status=="Rejected")
       {
        $kyc_status = $this->lang->line('Not Verified');
        $sym = 'times-circle';
        $sta = 'text-red';
       }
       else
       {
         $kyc_status = $this->lang->line('Verified');
         $sym = 'check-circle';
         $sta = 'text-green';
       }

?>


            <?php if($users->profile_status==1)
                    {
                       $prf_st = $this->lang->line('Verified');
                       $sym_p = 'far fa-check-circle'; 
                       $txtp = 'text-green';
                    }
                    else
                    {
                      $prf_st = $this->lang->line('Not Verified');
                      $sym_p = 'far fa-times-circle';
                      $txtp = 'text-red'; 
                    }
            ?>
<!-- 
      <style>
        
        .card-body{
        width: fit-content;

        }

      </style> -->

        <div class="content-body">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-3 col-lg-4 col-xxl-4">
                        <div class="card balance-widget-section">
                            <div class="card-body">
                                <div class="balance-widget"> 
                                   
                                    <ul class="list-unstyled">

                                       <?php
                            if(isset($dig_currency) && !empty($dig_currency))
                            {
                                foreach($dig_currency as $digital)
                                {
                                    if($digital->type=="fiat")
                                    {
                                        $format = 2;
                                    }
                                    
                                    elseif($digital->currency_symbol=="USDT")
                                    {
                                        $format = 8;
                                    }
                                    else
                                    {
                                        $format = 6;
                                    }
                                  



                                   $bch_change =  marketprice_change($market_pair);
                                      if($bch_change>=0)
                                      {
                                        $clr_class="badge badge-success ml-2";
                                        $arw_class="fa-arrow-up";
                                      }
                                      else
                                      {
                                       $clr_class="badge badge-danger ml-2";
                                       $arw_class="fa-arrow-down";
                                      }
                                      $coin_price_val = to_decimal($wallet['Exchange AND Trading'][$digital->id], $format);

                                      // $USD_Balance = $coin_price_val * $digital->online_usdprice;
                                      $USD_Balance = $this->common_model->conveter($digital->currency_symbol);
                                      $user_USD = $coin_price_val * $USD_Balance;

                                    ?>


                                        <li class="media">
                                          <!--   <i class="cc <?php echo strtoupper($digital->currency_symbol);?> mr-3"></i> -->
                                            <div class="media-body">
                                                <h5 class="m-0"><?php echo ucfirst($digital->currency_name);?></h6>
                                            </div>
                                            <div class="text-right">
                                                <h5><?php echo number_format($user_USD,2); ?> USD</h5> 

                                                <span><?php echo $coin_price_val;?></span>
                                                <span class="badge badge-success ml-2"> <?php echo $digital->currency_symbol;?> </span>
                                            </div>
                                        </li>


                                      <?php } } ?>

                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-9 col-lg-8 col-xxl-8">
                          <div class="card">
                          <div class="card-header border-0">
                                <h4 class="card-title"><?php echo $this->lang->line('Recent Transactions')?></h4>
                            </div>
                          <div class="card-body"  style="overflow: auto;">
                            <div class="table_inner">
                              <div class="table_responsive">
                                 <table id="example" class="table display table-striped" style="width:100%">
                                    <thead>                                        
                                       <tr>
                                            <th>Coin</th>
                                            <th><?php echo $this->lang->line('Date & Time')?></th>
                                            <th><?php echo $this->lang->line('Type')?></th>
                                            <th><?php echo $this->lang->line('Amount')?> / <?php echo $this->lang->line('Price')?></th>
                                            <th><?php echo $this->lang->line('Status')?></th>
                                        </tr>                                 
                                    </thead>
                                     <tbody>
                                    <?php
                                        $style = (count($trans_history)>0)?"display:block":"display:none";
                                        if(count($trans_history) > 0)
                                        {
                                            foreach($trans_history as $trans)
                                            {
                                                if($trans->type=="Deposit")
                                                {
                                                  $dates = date('d-M-Y H:i',$trans->datetime);
                                                    $style="display:none";
                                                    $txt_clr = 'text-green';
                                                }
                                                else
                                                {


                                                  $dates =  date('d-M-Y H:i',$trans->datetime);
                                                    $style="display:block";
                                                    $txt_clr = 'text-red';
                                                }
                                                $cursym = $this->common_model->getTableData('currency',array('status'=>1, 'id'=>$trans->currency_id))->row();
                                                $sym = strtoupper($cursym->currency_symbol);
                                                if($trans->status=='Pending')
                                                    $sts = 'text-warning';
                                                else
                                                   $sts = 'text-green'; 
                                    ?>
                                        <tr>
                                            <td><?php echo $sym;?></td>
                                            <td><?php echo $dates;?></td>
                                            <td class="<?=$txt_clr?>"><?php echo $trans->type;?></td>
                                            <td><?php echo number_format($trans->amount,8);?></td>
                                            <td class="text-green"><?php echo $trans->status;?></td>
                                        </tr>
                                    <?php }
                                    } ?>    
                                    </tbody>
                                </table>
                            </div>        
                            </div>
                        </div>
                    </div>

                </div>
            
            </div>
            <div class="row">

<div class="col-xl-12 col-lg-12 col-xxl-12">
  <div class="card">
        <div class="card-header border-0">
            <h4 class="card-title"><?php echo $this->lang->line('Login')?> <?php echo $this->lang->line('History')?></h4>
        </div>
        <div class="card-body"  style="overflow: auto;">
        <div class="table_inner">
          <div class="table_responsive">
             <table id="example" class="table display table-striped" style="width:100%">
                <thead>                                        
                    <tr>
                        <th><?php echo $this->lang->line('S.no')?></th>
                        <th><?php echo $this->lang->line('Date & Time')?></th>
                        <th><?php echo $this->lang->line('IP Address')?></th>
                        <th><?php echo $this->lang->line('Browser')?></th>
                    </tr>                                    
                </thead>
                <tbody>
                    <?php
                        if(count($login_history) >0) 
                        {
                            $i=1;
                            foreach($login_history as $login)
                            {
                    ?>
                    <tr>
                        <td><?php echo $i++;?></td>
                        <td><?php echo date('d-m-y H:i A',$login->date);?></td>
                        <td><?php echo substr($login->ip_address,0,14);?></td>
                        <td><?php echo $login->browser_name;?></td>
                    </tr>
                    <?php } 
                }?>                                        
                </tbody>
            </table>
        </div>
    </div>
        </div>
    </div>
</div>
</div>
        </div>



        <!--**********************************
            Right sidebar end
        ***********************************-->
        <!--endRemoveIf(production)-->
    </div>

<?php 
    $this->load->view('front/common/login_footer');

?>
    <!--- Data Tables  --->
     <script src="<?php echo front_js();?>datatables.bootstrap4.min.js"></script>
     <script src="<?php echo front_js();?>dataTables.min.js"></script>
     <script src="<?php echo front_js();?>datatables.bootstrap4.js"></script>

<script type="text/javascript">
$(document).ready(function() {

  var language = '<?php echo  $lang_id = $this->session->userdata('site_lang'); ?>';

  if(language=='spanish')
  {

    $('table.display').DataTable( {

       "language": {
              
            "sProcessing": "Procesando ...",
            "sLengthMenu": "Show _MENU_ registros",
            "sZeroRecords": "No se han encontrado resultados",
            "sEmptyTable": "No hay datos disponibles en esta tabla.",
            "sInfo": "Showing registros from _START_ to _END_ of a total of _TOTAL_ registros",
            "sInfoEmpty": "Mostrando registros de 0 to 0 out of a total of 0 registros",
            "sInfoFiltered": "(filtrando un total de _MAX_ registros)",
            "sInfoPostFix": "",
            "sSearch": "búsqueda:",
            "sUrl": "",
            "sInfoThousands": ",",
            "sLoadingRecords": "Cargando ...",
            "oPaginate": {
              "sFirst": "Primera",
              "sLast": "Última",
              "sNext": "Próxima",
              "sPrevious": "Previa"
            },
            "oAria": {
              "sSortAscending": ": Activate to sort the column in ascending order",
              "sSortDescending": ": Activate to sort the column in descending order"
            }


        }
    } );

  }
  else if(language=='italic')
  {
     $('table.display').DataTable( {
       "language": {
              
            "sProcessing": "in lavorazione ...",
            "sLengthMenu": "Mostra _MENU_ record",
            "sZeroRecords": "nessun risultato trovato",
            "sEmptyTable": "Nessun dato disponibile in questa tabella",
            "sInfo": "Visualizzazione del record da _START_ a _END_ di un totale di _TOTAL_ record",
            "sInfoEmpty": "Mostra record da 0 a 0 su un totale di 0 record",
            "sInfoFiltered": "(filtrando un totale di _MAX_ record)",
            "sInfoPostFix": "",
            "sSearch": "ricerca:",
            "sUrl": "",
            "sInfoThousands": ",",
            "sLoadingRecords": "Caricamento in corso ...",
            "oPaginate": {
              "sFirst": "Primo",
              "sLast": "Ultimo",
              "sNext": "Prossimo",
              "sPrevious": "Precedente"
            },
            "oAria": {
              "sSortAscending": ": Activate to sort the column in ascending order",
              "sSortDescending": ": Activate to sort the column in descending order"
            }


        }

    });

  }

  else
  {

    $('table.display').DataTable();


  }


} );

</script>


   </body>
</html> 