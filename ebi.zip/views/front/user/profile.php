<?php $this->load->view('front/user/login_header');
$settings = $site_common['site_settings']; 

?>

<style>
        .nav-pills-custom .nav-link {
    color: #fff;
    background: #4890fb;
    position: relative;
    }

        .nav-pills-custom .nav-link.active {
            color: #4890fb;
            background: #fff;
        }


        /* Add indicator arrow for the active tab */
        @media (min-width: 992px) {
            .nav-pills-custom .nav-link::before {
                content: '';
                display: block;
                border-top: 8px solid transparent;
                border-left: 10px solid #fff;
                border-bottom: 8px solid transparent;
                position: absolute;
                top: 50%;
                right: -10px;
                transform: translateY(-50%);
                opacity: 0;
            }
        }

        .nav-pills-custom .nav-link.active::before {
            opacity: 1;
        }
        .Neon {
    font-family: sans-serif;
    font-size: 14px;
    color: #494949;
    position: relative;


}
.Neon * {
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
}
.Neon-input-dragDrop {
    display: block;
    width: 280px;
    margin: 0 auto 25px auto;
    padding: 25px;
    color: #8d9499;
    color: #97A1A8;
    background: #fff;
    border: 2px dashed #C8CBCE;
    text-align: center;
    -webkit-transition: box-shadow 0.3s, border-color 0.3s;
    -moz-transition: box-shadow 0.3s, border-color 0.3s;
    transition: box-shadow 0.3s, border-color 0.3s;
}
.Neon-input-dragDrop .Neon-input-icon {
    font-size: 48px;
    margin-top: -10px;
    -webkit-transition: all 0.3s ease;
    -moz-transition: all 0.3s ease;
    transition: all 0.3s ease;
}
.Neon-input-text h3 {
    margin: 0;
    font-size: 18px;
}
.Neon-input-text span {
    font-size: 12px;
}
.Neon-input-choose-btn.blue {
    color: #4890fb;
    border: 1px solid #4890fb;
}
.Neon-input-choose-btn {
    display: inline-block;
    padding: 8px 14px;
    outline: none;
    cursor: pointer;
    text-decoration: none;
    text-align: center;
    white-space: nowrap;
    font-size: 12px;
    font-weight: bold;
    color: #8d9496;
    border-radius: 3px;
    border: 1px solid #c6c6c6;
    vertical-align: middle;
    background-color: #fff;
    box-shadow: 0px 1px 5px rgba(0,0,0,0.05);
    -webkit-transition: all 0.2s;
    -moz-transition: all 0.2s;
    transition: all 0.2s;
}
    </style>


    <div class="page-body">
        <div class="container-xl">
            <div class="row">
              <!--for demo wrap-->
              <!-- <div class="col-2"></div> -->
              <div class="col-12" style="overflow: auto;margin-bottom: 50px;">



             <div class="row">

                <div class="col-md-3">
                <!-- Tabs nav -->
                <div class="nav flex-column nav-pills nav-pills-custom" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                    <a class="nav-link mb-3 p-3 shadow active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true">
                        <i class="fa fa-user-circle-o mr-2"></i>
                        <span class="font-weight-bold small text-uppercase">Personal information</span></a>

                    <a class="nav-link mb-3 p-3 shadow" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">
                        <i class="fa fa-calendar-minus-o mr-2"></i>
                        <span class="font-weight-bold small text-uppercase">KYC Verification</span></a>

                    <a class="nav-link mb-3 p-3 shadow" id="v-pills-messages-tab" data-toggle="pill" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false">
                        <i class="fa fa-star mr-2"></i>
                        <span class="font-weight-bold small text-uppercase">Bank Details</span></a>

                    <a class="nav-link mb-3 p-3 shadow" id="v-pills-settings-tab" data-toggle="pill" href="#v-pills-settings" role="tab" aria-controls="v-pills-settings" aria-selected="false">
                        <i class="fa fa-check mr-2"></i>
                        <span class="font-weight-bold small text-uppercase">2FA</span></a>

                     <a class="nav-link mb-3 p-3 shadow" id="v-pills-settings-tab" data-toggle="pill" href="#v-pills-login" role="tab" aria-controls="v-pills-settings" aria-selected="false">
                        <i class="fa fa-check mr-2"></i>
                        <span class="font-weight-bold small text-uppercase">Login History</span></a>

                    <a class="nav-link mb-3 p-3 shadow" id="v-pills-settings-tab" data-toggle="pill" href="#v-pills-password" role="tab" aria-controls="v-pills-settings" aria-selected="false">
                        <i class="fa fa-check mr-2"></i>
                        <span class="font-weight-bold small text-uppercase">Change Password</span></a>
                    </div>
            </div>


            <div class="col-md-9">
                <!-- Tabs content -->
                <div class="tab-content" id="v-pills-tabContent">
                    <div class="tab-pane fade shadow rounded bg-white show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                        <div class="card-header">
                            <h3 class="card-title" style="color: #4890fb;">Profile</h3>
                          </div>
                        <div class="col-md-12">
                            <div class="card-trans">
                             <div class="card-body">
                               
                                    <div class="row">
                                        <div class="col-md-6">

                                                <?php 
                                    $attributes=array('id'=>'verification_form',"autocomplete"=>"off"); 
                                      $action = front_url() . 'profile-edit';
                                    echo form_open_multipart($action,$attributes); 
                                ?>
                                     <div class="form-group mb-3 ">
                                 
                                            <label class="form-label" style="color: black;">First Name</label>
                                            <div>
                                            <input type="text" class="form-control" aria-describedby="emailHelp" id="firstname" placeholder="Enter First Name" name="firstname" value="<?php echo $users->xabits_fname; ?>">

                                            </div>
                                        </div>
                                        <div class="form-group mb-3 ">
                                        <label class="form-label" style="color: black;">Last Name</label>
                                        <div>
                                        <input type="text" id="lastname" class="form-control" aria-describedby="emailHelp" placeholder="Enter Last Name" name="lastname" value="<?php echo $users->xabits_lname; ?>" >

                                        </div>
                                    </div>
                                    <div class="form-group mb-3 ">
                                        <label class="form-label" style="color: black;">Phone Number</label>
                                        <div>
                                        <input type="text" id="phone" class="form-control" aria-describedby="emailHelp" placeholder="Enter Your Phone Number" name="phone" value="<?php echo ($users->xabits_phone);?>">

                                        </div>
                                    </div>
                                        

                                                    <div class="form-group mb-3 ">
                                                        <label class="form-label" style="color: black;">Address</label>
                                                        <div>
                                                        <textarea type="text" class="form-control" aria-describedby="emailHelp" placeholder="Enter Address" id="address" name="address"><?php echo ($users->street_address)?$users->street_address:'';?></textarea>

                                                        </div>
                                                    </div>
                                                    </div>
                                                    <div class="col-md-6">

                                    


                                    

                                
                                <div class="form-group mb-3 ">
                                    <?php $usermail = getUserEmail($users->id);?>
                                    <label class="form-label" style="color: black;">Email</label>
                                    <div>
                                   <input type="text" class="form-control" id="email" name="email" disabled value="<?php echo ($usermail)?$usermail:'';?>" placeholder="Enter Your Email">
                                    </div>
                                </div>
                                <div class="form-group mb-3 ">
                                            <label class="form-label" style="color: black;">Country</label>
                                            <div>
                                            <select class="form-select" name="register_country" id="register_country">
                                                <option>Select Country</option>
                                        <?php if($countries) {
                                            foreach($countries as $co) {
                                              ?>
                                              <option <?php if($co->id==$users->country) { echo "selected"; } ?>
                                              value ="<?php echo $co->id; ?>"><?php echo $co->country_name; ?></option>
                                              <?php
                                            }
                                          } ?>
                                            </select>
                                            </div>
                                                    </div>
                            </div>

                                <div class="col-12 col-md-12 col-lg-3">
                                <div class="profile-img">
                                  <?php
                                  $pro_img = front_img().'photo.png';
                                  if(!empty($users->profile_picture)){
                                      $pro_img = $users->profile_picture;
                                  }
                                  ?>
                                    <a href="javascript:void(0);" class="profile-size"><img id="profile_pic" src="<?php echo $pro_img;?>" class="img-fluid" style="width: 80px;height:80px; border-radius: 50px;"></a>

                                </div>
                             </div>
                                             <div class="col-12 col-md-12 col-lg-8">
                                                <div class="profile-content">
                                                   <label for="inputEmail4" class="active">Profile Picture</label>
                                                 

                                                   
                                                    <div class="file-upload-wrapper" data-text="Change Picture">
                                                        <input name="profile_photo" type="file" class="file-upload-field" style="background-color: #4890fb ;" id="profile-picture" value="<?php echo $users->profile_picture; ?>">
                                                    </div>


                                                </div>
                                             </div>
                                                    <div class="form-footer">
                                                        <button type="submit" class="Neon-input-choose-btn blue">Submit</button>
                                                        
                                    </div>
                                 </div>
                               <?php echo form_close(); ?>
                              </div>
                            </div>
                          </div>





                    </div>

                    <div class="tab-pane fade shadow rounded bg-white" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
                        <div class="card-header">
                            <h3 class="card-title" style="color: #4890fb;">KYC Verification</h3>
                          </div>
                         <div class="page-body">
        <div class="container-xl">
          <div class="row row-deck row-cards">
            <div class="heading">

              <div class="space-10"></div>
              <h3 style="text-align: center;color: black;height: 50px;">Kyc Verification</h3>
          </div>

       <div class="row">
          <div class="col-12 col-lg-4">
            <?php
                        $attributes=array('id'=>'verification_forms2'); 
                        $action = front_url() . 'address_verification';
                        echo form_open_multipart($action,$attributes);
                        $img = front_img().'id.png';
                        if(!empty(trim($users->photo_id_1)) && ($users->photo_1_status==3 || $users->photo_1_status==1)){
                            $img = $users->photo_id_1;
                        }
                     ?> 
            <h4 style="color:black; font-weight: 500;text-align: center;">Front Photo of ID</h4>
            <div class="Neon Neon-theme-dragdropbox">
                 <div class="Neon-input-dragDrop"><div class="Neon-input-inner"><div class="Neon-input-icon"><img id="address_proof" src="<?php echo $img;?>" ></div></div>
              </div>
                 <?php
                     if(($users->photo_1_status==0 || $users->photo_1_status==2)){
                     ?>  
                      <input type="hidden"  value="253d521c8b2a4fe7d17412ac5a8b0e1c">    
                      
              <input style="z-index: 999; opacity: 0; width: 320px; height: 200px; position: absolute; right: 0px; left: 0px; margin-right: auto; margin-left: auto;" name="latincoin" id="photo_ids_1" multiple="multiple"  type="hidden"  name="photo_ids_1" value="<?php echo $users->photo_id_1;?>">
              <input type="hidden" id="addr_proof" value="">
               <input name="photo_id_1" type="file" id="imageUpload1" class="file-upload-field" >
             

          </div>
        
          <div class="form-footer">
            <button><a  class="logibtn gradient-btn" type="submit" id="addr_submit">Upload Front of the Document</a></button>

            <?php } ?>
           <?php   

  if($users->photo_1_status==1 || $users->photo_1_status==0){

    $kyc_status="pending";
  }
  elseif($users->photo_1_status==2){

     $kyc_status="Rejected";

  }
  else{

     $kyc_status="completed";


  }
?>
 <p style="color:black; font-weight: 500;text-align: center;">Please provide front photo of your ID/Passport</p>
               <h4>[Note : Maximum FileSize Should Be Below 3mb]</h4>

              <b><p style="color: aliceblue";>KYC Status : <?=$kyc_status;?></p></b>
                <span class="photo_error">
    <small style="padding-left: 85px;" class="error_msg photo_id_1_error error"></small>
    </span>
          </div>
          <?php echo form_close();?>

          </div>

          <div class="col-12 col-lg-4">

             <?php
                                $attributes = array('id'=>'verification_forms3'); 
                                $action = front_url() . 'id_verification';
                                echo form_open_multipart($action,$attributes);

                                $img1 = front_img().'id.png';
                                if(!empty(trim($users->photo_id_2)) && ($users->photo_2_status==3 || $users->photo_2_status==1)){
                                    $img1 = $users->photo_id_2;
                                }
                                            
                                           
                                        ?>

            <h4 style="color:black; font-weight: 500;text-align: center;">Back Photo of ID</h4>
            <div class="Neon Neon-theme-dragdropbox">

                  <div class="Neon-input-dragDrop"><div class="Neon-input-inner"><div class="Neon-input-icon"><img id="id_proof" src="<?php echo $img1;?>" ></div></div></div>
                  <?php
                                                 if(($users->photo_2_status==0 || $users->photo_2_status==2)){
                                                 ?>
                         <input type="hidden" name="latincoin" value="253d521c8b2a4fe7d17412ac5a8b0e1c">
                          <input name="photo_id_2" type="file" id="imageUpload2" class="file-upload-field">
                           
              <input style="z-index: 999; opacity: 0; width: 320px; height: 200px; position: absolute; right: 0px; left: 0px; margin-right: auto; margin-left: auto;" name="photo_ids_2" id="photo_ids_2" multiple="multiple" type="hidden" value="<?php echo $users->photo_id_2;?>">
            
              </div>
              
              <div class="form-footer">
               <button> <a  class="logibtn gradient-btn" type="submit" id="id_submit">Upload Back of the Document</a></button>
              <?php }?>

              <?php   

  if($users->photo_2_status==1 || $users->photo_2_status==0){

    $kyc_status="pending";
  }
  elseif($users->photo_2_status==2){

     $kyc_status="Rejected";

  }
  else{

     $kyc_status="completed";


  }
?>

              <p style="color:black; font-weight: 500;text-align: center;">Please provide Back photo of your ID/Passport</p>
               <h4>[Note : Maximum FileSize Should Be Below 3mb]</h4>
        <b><p style="color: aliceblue";>KYC Status : <?=$kyc_status;?></p></b>    

         <span class="photo_error">
    <small style="padding-left: 85px;" class="error_msg photo_id_1_error error"></small>
    </span>  
             
        </div>
            <?php echo form_close();?>

            </div>

            <div class="col-12 col-lg-4">
                  <?php
                        $attributes = array('id'=>'verification_forms4'); 
                        $action = front_url() . 'photo_verification';
                        echo form_open_multipart($action,$attributes);

                        $img2 = front_img().'id.png';
                        if(!empty(trim($users->photo_id_3)) && ($users->photo_3_status==3 || $users->photo_3_status==1)){
                            $img2 = $users->photo_id_3;
                        }
                        
                    ?>
              <h4 style="color:black; font-weight: 500;text-align: center;">A recent Photo of Yourself</h4>
              <div class="Neon Neon-theme-dragdropbox">
                <div class="Neon-input-dragDrop"><div class="Neon-input-inner"><div class="Neon-input-icon"><img id="selfie_proof" src="<?php echo $img2; ?>" ></div></div></div>
                 <?php
                             if(($users->photo_3_status==0 || $users->photo_3_status==2)){
                             ?>
                               <input name="photo_id_3" type="file" id="imageUpload3" class="file-upload-field" >
                <input style="z-index: 999; opacity: 0; width: 320px; height: 200px; position: absolute; right: 0px; left: 0px; margin-right: auto; margin-left: auto;" id="photo_ids_3" name="photo_ids_3" multiple="multiple" type="hidden">
                
                </div>
             
                <div class="form-footer">
                 <button> <a id="photo_submit" type="submit" class="logibtn gradient-btn">Upload Your Photo</a></button>
                <?php } ?>

  
                <?php   

  if($users->photo_3_status==1 || $users->photo_3_status==0){

    $kyc_status="pending";
  }
  elseif($users->photo_3_status==2){

     $kyc_status="Rejected";

  }
  else{

     $kyc_status="completed";


  }
?>
 <p style="color:black; font-weight: 500;text-align: center;">Please provide Recent photo of you</p>
  <h4 >[Note : Maximum FileSize Should Be Below 3mb]</h4>

 <b><p style="color: aliceblue";>KYC Status : <?=$kyc_status;?></p></b>
  <span class="photo_error">
    <small style="padding-left: 85px;" class="error_msg photo_id_1_error error"></small>
    </span>
    </div>
    <?php echo form_close();?>
            </div>
          </div>

            </div>
          </div>
        </div>
        </div>



        <div class="tab-pane fade shadow rounded bg-white" id="v-pills-login" role="tabpanel" aria-labelledby="v-pills-settings-tab">
                                <div class="tab-pane fade shadow rounded bg-white show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                                    <div class="card-header border-0">
            <h4 class="card-title">Login History</h4>
        </div>
        <div class="card-body"  style="overflow: auto;">
        <div class="table_inner">
          <div class="table_responsive">
             <table id="example" class="table-striped table" style="width:100%">
                <thead>                                        
                    <tr>
                        <th>S.no></th>
                        <th>Date & Time</th>
                        <th>IP Address</th>
                        <th>Browser</th>
                        <th>Activity</th>
                    </tr>                                    
                </thead>
                <tbody>
                    <?php
                        if(count($login_history) >0) 
                        {
                            $i=1;
                            foreach($login_history as $login)
                            {
                                
                    ?>
                    <tr>
                        <td><?php echo $i++;?></td>
                        <td><?php echo date('d-m-y H:i A',$login->date);?></td>
                        <td><?php echo substr($login->ip_address,0,14);?></td>
                        <td><?php echo $login->browser_name;?></td>
                        <td><?php echo $login->activity;?></td>
                    </tr>
                    <?php } 
                }?>                                        
                </tbody>
            </table>
        </div>
    </div>
        </div>





                                </div>

                            </div>

                            

                            <div class="tab-pane fade shadow rounded bg-white" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">
                                <div class="tab-pane fade shadow rounded bg-white show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                                    <div class="card-header">
                                        <h3 class="card-title" style="color: #4890fb;line-height: 35px;">2 Factor Authentication</h3>
                                      </div>
                                    <div class="col-md-12">
                                        <div class="card-trans">
                                         <div class="card-body">
                                            <?php 
                                            $attributes1=array('id'=>'security','class'=>'deposit_form');
                                            $action1=base_url().'security';
                                            echo form_open($action1,$attributes1); 
                                            if($users->randcode=='' || $users->randcode=='disable')
                                            {
                                              $btn_content = $this->lang->line('ENABLE');
                                            }
                                             else{
                                              $btn_content = $this->lang->line('DISABLE');
                                            }                                     
                                          ?>
                                          <input type="hidden" name="latincoin" value="253d521c8b2a4fe7d17412ac5a8b0e1c">  
                                                                                                      
                                            <div class="verify-code">
                                                
                                                    <div class="form-group">
                                                        
                                                        <input type="text" class="form-control" id="code" name="code" placeholder="Verification Code">
                                                        <input type="hidden"  name="secret" id="secret" value="<?php echo $secret;?>">
                                                    </div>
                                               
                                            </div>



                                                    <div class="form-footer">
                                                         <button class="btn btn-success btn-sm waves-effect waves-light button" type="submit"><?php echo $btn_content;?></button>
                                                             <?php echo form_close(); ?>
                                                    </div>
                                                     <div class="col-12 col-md-6 text-center">
                                            <label class="text-capitalize">Scan QR Code In Google Authenticator</label>
                                            <img src="<?php echo $url;?>" class="img-thumbnail" width="100">
                                            <div class="manual-verify">
                                                <p>Or Type The Key Manually</p>
                                                <p><span id="authenticator_key"><?php echo $secret;?></span> <span class="fs-18" style="cursor:pointer;"><i class="far fa-copy" onclick="copyToClipboard('<?php echo $secret;?>')"></i></span></p>
                                            </div>
                                        </div>
                                          </div>
                                        </div>
                                      </div>

                                </div>

                            </div>

                            <div class="tab-pane fade shadow rounded bg-white" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
                                <div class="tab-pane fade shadow rounded bg-white show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                                    <div class="card-header">
                                        <h3 class="card-title" style="color: #4890fb;">Bank Details</h3>
                                      </div>
                                    <div class="col-md-12">
                                        <div class="card-trans">
                                         <div class="card-body">
                                            <?php
                                      $attributes=array('id'=>'bankwire',"autocomplete"=>"off","class"=>"mt-4");
                                      $action = front_url() . 'update_bank_details';
                                      echo form_open_multipart($action,$attributes);
                                  ?>
                                                <div class="row">
                                                    <div class="col-md-6">

                                                         <div class="form-group mb-3 ">
                                                        <label class="form-label" style="color: black;">Currency</label>
                                                        <div>
                                                        <select class="form-select" name ="currency" id="currency">
                                                          <?php
                                            if(count($currencies)>0)
                                            {
                                                foreach($currencies as $cur)
                                                {
                                        ?>
                                                    <option value="<?php echo $cur->id;?>" <?php
                                                            if(!empty($user_bank))
                                                                if($user_bank->currency==$cur->id) { echo "selected"; } ?>>
                                                        <?php echo $cur->currency_symbol;?>
                                                    </option>
                                        <?php
                                                }
                                            }
                                        ?>
                                                        </select>
                                                        </div>
                                                    </div>


                            <div class="form-group mb-3 ">
                            <label class="form-label" style="color: black;">Bank Name</label>
                            <div>
                           <input type="text" class="form-control" aria-describedby="emailHelp" id="bank_name" name="bank_name" placeholder="Enter First Name" value="<?php echo $user_bank->bank_name;?>">

                            </div>
                        </div>

                        <div class="form-group mb-3 ">
                            <label class="form-label" style="color: black;">Bank Branch Location</label>
                            <div>
                            <input type="text" class="form-control" aria-describedby="emailHelp" id="bank_address" name="bank_address" placeholder="Enter Branch Name" value="<?php echo $user_bank->bank_address;?>">

                            </div>
                        </div>
                        <div class="form-group mb-3 ">
                            <label class="form-label" style="color: black;">IFSC Code</label>
                            <div>
                             <input type="text" class="form-control" aria-describedby="emailHelp" placeholder="Enter IFSC code" id="bank_swift" name="bank_swift" value="<?php echo $user_bank->bank_swift;?>">

                            </div>
                        </div>
                   
                        </div>
                        <div class="col-md-6">

                            <div class="form-group mb-3 ">
                                <label class="form-label" style="color: black;">Account Holder Name</label>
                                <div>
                                  <input type="text" class="form-control" aria-describedby="emailHelp" placeholder="Enter Account Name" name="bank_account_name"  value="<?php echo $user_bank->bank_account_name;?>" id="bank_account_name">

                                </div>
                            </div>
                            <div class="form-group mb-3 ">
                                <label class="form-label" style="color: black;">Bank Account Number</label>
                                <div>
                                <input type="Text" class="form-control" aria-describedby="emailHelp" placeholder="Enter Account Number" id="bank_account_number" name="bank_account_number" value="<?php echo $user_bank->bank_account_number;?>">

                                </div>
                            </div>
                            <div class="form-group mb-3 ">
                                <label class="form-label" style="color: black;">Bank City</label>
                                                    <div>
                                      <input type="Text" class="form-control" aria-describedby="emailHelp" placeholder="Bank City" id="bank_city" name="bank_city" value="<?php echo $user_bank->bank_city;?>">

                                                    </div>
                                                </div>
                                                  </div>
                                <div class="form-group mb-3 ">
                                            <label class="form-label" style="color: black;">Country</label>
                                            <div>
                                            <select class="form-select" name="bank_country" id="bank_country">
                                                <option>Select Country</option>
                                        <?php if($countries) {
                                            foreach($countries as $co) {
                                              ?>
                                              <option <?php if($co->id==$user_bank->bank_country) { echo "selected"; } ?>
                                              value ="<?php echo $co->id; ?>"><?php echo $co->country_name; ?></option>
                                              <?php
                                            }
                                          } ?>
                                            </select>
                                            </div>
                                                    </div>
                    </div>
                        <?php if(empty($user_bank)){ ?> 
                        <div class="form-footer">
                            <button type="submit" class="Neon-input-choose-btn blue">Submit</button>
                                             </div>
                                          <?php } ?> 
                                               <?php echo form_close();?>
                                             </div>
                                           
                                          </div>
                                        </div>
                                      </div>





                                </div>




                            </div>



                            
                            <div class="tab-pane fade shadow rounded bg-white" id="v-pills-password" role="tabpanel" aria-labelledby="v-pills-messages-tab">
                                <div class="tab-pane fade shadow rounded bg-white show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                                    <div class="card-header">
                                        <h3 class="card-title" style="color: #4890fb;">Change Password</h3>
                                      </div>
                                    <div class="col-md-12">
                                        <div class="card-trans">
                                         <div class="card-body">
                                            <?php 
                                     $attributes=array('id'=>'change_password1','class'=>'change_password_form');
                                     $action=base_url().'settings';
                                     echo form_open($action,$attributes); ?>

                                                <div class="row">
                                                   <div class="form-group mb-3 ">
                            <label class="form-label" style="color: black;">Enter Current Password</label>
                            <div>
                            <input type="password" class="form-control" id="oldpass" aria-describedby="emailHelp" name="oldpass" placeholder="Enter Current Password">

                            </div>
                        </div>

                        <div class="form-group mb-3 ">
                            <label class="form-label" style="color: black;">Enter New Password</label>
                            <div>
                            <input type="password" class="form-control" id="newpass" aria-describedby="emailHelp" placeholder="Enter New Password" name="newpass">

                            </div>
                        </div>
                        <div class="form-group mb-3 ">
                            <label class="form-label" style="color: black;">Confirm Password</label>
                            <div>
                            <input type="password" class="form-control" id="confirmpass" name="confirmpass" aria-describedby="emailHelp" placeholder="Enter Confirm Password">

                            </div>
                        </div>
                       <div class="form-footer">
                            <button type="submit" class="Neon-input-choose-btn blue">Submit</button>
                        </div>
                                             </div>
                                            <?php echo form_close();?>
                                          </div>
                                        </div>
                                      </div>





                                </div>




                            </div>

                            </div>
                </div>
            </div>
            </div>
            </div>
            </div>

        </div>
        </div>


    <?php $this->load->view('front/common/footer');?>

      <script src="<?php echo front_js();?>datatables.bootstrap4.min.js"></script>
     <script src="<?php echo front_js();?>dataTables.min.js"></script>
     <script src="<?php echo front_js();?>datatables.bootstrap4.js"></script> 

     <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.js"></script>
    <script type="text/javascript">


        function readURLProfile(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#img-profile').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }
    $("#imageUpload").change(function() {
        readURLProfile(this);
    });

      $.validator.addMethod('ZipChecker', function() {
    }, 'Invalid zip code');
         $.validator.addMethod("lettersonly", function(value) {
    return (/^[a-zA-Z\s]*$/.test(value));
});

    $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
        if (options.type.toLowerCase() == 'post') {
            options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
            if (options.data.charAt(0) == '&') {
                options.data = options.data.substr(1);
            }
        }
    });

    $( document ).ajaxComplete(function( event, xhr, settings ) {
        if (settings.type.toLowerCase() == 'post') {
            $.ajax({
                url: front_url+"get_csrf_token", 
                type: "GET",
                cache: false,             
                processData: false,      
                success: function(data) {

                     $("input[name="+csrfName+"]").val(data);
                }
            });
        }
    });



    $('#verification_form').validate({
      rules: {
        firstname: {
          required: true,
           lettersonly: true
        },
       
        address: {
          required: true
        },
         lastname: {
          required: true
        },
        
        phone: {
          required: true,
           number: true
        }
      },
      messages: {
        firstname: {
          required: "Please enter first name",
           lettersonly: "Please enter letters only"
        },
       
        address: {
          required: "Please enter address"
        },
         lastname: {
          required: "Please enter last name"
        },
       
        phone: {
          required: "Please enter phone number"
        }
      }
    });

    $('#bankwire').validate({
    rules: {
        currency: {
            required: true
        },
        bank_name: {
            required: true,
             lettersonly: true
        },
        bank_account_number: {
            required: true,
            number: true
        },
        bank_account_name: {
            required: true,
            lettersonly: true
        },
        bank_swift: {
            required: true
        },
        bank_address: {
             required: true
        },
        bank_city: {
            required: true,
            lettersonly: true
        }
        
    },
    messages: {
        bank_name: {
            required: "Please enter bank name",
             lettersonly: "Please enter letters only"
        },
        bank_account_number: {
            required: "Please enter bank account number"
        },
        bank_account_name: {
            required: "Please enter bank account name",
            lettersonly: "Please enter letters only"
        },
        bank_swift: {
            required: "Please enter bank swift"
        },
        bank_address: {
            required: "Please enter bank address"
        },
        bank_city: {
            required: "Please enter bank city",
            lettersonly: "Please enter letters only"
        }
       
       
    }
});

    $("#imageUpload1").change(function() {
        readURL1(this);
    });
   $("#imageUpload2").change(function() {
        readURL2(this);
    });

   $("#imageUpload3").change(function() {
        readURL3(this);
    });
    $("#profile-picture").change(function() {
        readURL5(this);
    });


   function readURL1(input) {

        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#address_proof').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }


    function readURL2(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#id_proof').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }



    function readURL3(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#selfie_proof').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }

        function readURL5(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#profile_pic').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }

  
    $("#address_submit").click(function(){
        var photo_id_2 = $('#imageUpload1').val();       
        var error_msg = '';
        if($.trim(photo_id_2) == '' || $.trim(photo_id_2) == null){
            $('.photo_id_1_error').html('Provide Address Proof').fadeIn(1000).fadeOut(3000);
            $('#imageUpload1').focus();
            return false;
        }else{
            $("#verification_forms2").submit();
            return true;
        }
    });
    $("#address_cancel").click(function(){
        var photo_id_2 = $('#imageUpload1').val(); 
        var error_msg = '';
        if($.trim(photo_id_2) == '' || $.trim(photo_id_2) == null){
            $('.photo_id_1_error').html('No Address Proof to cancel').fadeIn(1000).fadeOut(3000);
            $('#imageUpload1').focus();
            return false;
        }else{

            $('#imageUpload1').val('');
            $('#address_proof').attr('src', base_url+'assets/front/images/id_proof.png');
            return true;
        }
    });

    $("#id_submit").click(function(){
        var photo_id_3 = $('#imageUpload2').val();       
        var error_msg = '';
        //console.log(isEmpty($.trim(photo_id_3)));
        if($.trim(photo_id_3) == '' || $.trim(photo_id_3) == null){
            $('.photo_id_2_error').html('Provide ID Proof').fadeIn(1000).fadeOut(3000);
            $('#imageUpload2').focus();
            return false;
        }else{
            $("#verification_forms3").submit();
            return true;
        }
    });
    $("#id_cancel").click(function(){
        var photo_id_3 = $('#imageUpload2').val();
        var error_msg = '';
        if($.trim(photo_id_3) == '' || $.trim(photo_id_3) == null){
            $('.photo_id_2_error').html('No ID Proof to cancel').fadeIn(1000).fadeOut(3000);
            $('#imageUpload2').focus();
            return false;
        }else{
            $('#imageUpload2').val('');
            $('#id_proof').attr('src', base_url+'assets/front/images/id_proof.png');
            return true;
        }
    });

     $("#selfie_submit").click(function(){
        var photo_id_3 = $('#imageUpload3').val();       
        var error_msg = '';
        //console.log(isEmpty($.trim(photo_id_3)));
        if($.trim(photo_id_3) == '' || $.trim(photo_id_3) == null){
            $('.photo_id_3_error').html('Provide Selfie Photo').fadeIn(1000).fadeOut(3000);
            $('#imageUpload3').focus();
            return false;
        }else{
            $("#verification_forms4").submit();
           
            return true;
        }
    });
    $("#selfie_cancel").click(function(){
        var photo_id_3 = $('#imageUpload3').val();
        var error_msg = '';
        if($.trim(photo_id_3) == '' || $.trim(photo_id_3) == null){
            $('.photo_id_3_error').html('No Photo to cancel').fadeIn(1000).fadeOut(3000);
            $('#imageUpload3').focus();
            return false;
        }else{
            //$("#verification_forms3").submit();
            $('#imageUpload3').val('');
            $('#selfie_proof').attr('src', base_url+'assets/front/images/settings_user.png');
            return true;
        }
    });

    </script>
    <script type="text/javascript">
$(document).ready(function() {

  var language = '<?php echo  $lang_id = $this->session->userdata('site_lang'); ?>';

 

    $('.table').DataTable( {

      
    } );


} );

</script>
<script type="text/javascript">
    var base_url='<?php echo base_url();?>';
    var front_url='<?php echo front_url();?>';
    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';

    $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
        if (options.type.toLowerCase() == 'post') {
            options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
            if (options.data.charAt(0) == '&') {
                options.data = options.data.substr(1);
            }
        }
    });

    $( document ).ajaxComplete(function( event, xhr, settings ) {
        if (settings.type.toLowerCase() == 'post') {
            $.ajax({
                url: front_url+"get_csrf_token", 
                type: "GET",
                cache: false,             
                processData: false,      
                success: function(data) {

                     $("input[name="+csrfName+"]").val(data);
                }
            });
        }
    });




  $('#change_password1').validate({
      rules: {
        oldpass: {
          required: true,
          remote: {
                    url: front_url+'oldpassword_exist',
                    type: "post",
                    csrf_token : csrfName,
                    data: {
                        oldpass: function() {
                        return $( "#oldpass" ).val();
                        }
                    }
                }
        },
       newpass: {
          required: true
        },
        confirmpass: {
          required: true,
          equalTo : "#newpass"
        }
    },
     messages: {
        oldpass: {
          required: "Please enter Old Password",
           remote: "Invalid Old Password"
        },
        newpass: {
          required: "Please enter New Password"
        },
        confirmpass: {
          required: "Please enter Confirm Password",
          equalTo : "Confirm Password not matches with New Password"
        }
    }
});  

    $('#security').validate({
        rules: {
            code: {
                required: true,
                number: true,
                minlength: 6
            }
        },
        messages: {
            code: {
                required: 'Please enter code',
                number: 'Please enter valid code',
                minlength:'Please 6 digit valid code'
            }
        }
    });

function copyToClipboard(text) {
    var copyText = document.getElementById("authenticator_key");  
    var input = document.createElement("textarea");
    input.value = copyText.textContent;
    document.body.appendChild(input);
    input.select();
    document.execCommand("Copy");
    input.remove();
}

    </script>