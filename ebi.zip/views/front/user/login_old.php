<?php $this->load->view('front/common/inner_header');
?>


<div class="token-info-sec" style="background: #fff !important;">
<div class="container">
<div class="sec-title text-center">
<h1 data-watermark=""> 
<span>Sign</span>In
</h1>
<p>Sign into your account again for full access</p>
</div>
<div class="row">
<div class="col-lg-3"></div>
<div class="col-lg-6">
<?php 
$action = front_url()."login";
$attributes = array('id'=>'loginuserFrom','autocomplete'=>"off",'class'=>'auth_form');
echo form_open($action,$attributes);
?>
<div class="single-input-box box-1">
<input type="email" placeholder="Enter Your Email Address" name="login_detail">
<span class="input-icon">
<i class="icofont-ui-user"></i>
</span>
</div>
<div class="single-input-box box-1">
<input type="password" placeholder="Enter Your Password" name="login_password" id="register_password" value="">
<span toggle="#register_password" class="input-icon toggle-password">
<i class="icofont-eye-alt eye-icon"></i>
</span>
</div>
<label>Google Authenticator Code (if enabled)</label>
<div class="single-input-box box-1">
   <input type="text" class="form-control" id="login_tfa" name="login_tfa" placeholder="Enter TFA">
   <span class="input-group-addon" class="input-icon">
    <i class="icofont-lock"></i></span>
  </div>

<br>
<button class="btn btn-primary" type="submit">Login</button>
<?php echo form_close();?>
<div class="mt-5">
<p>Dont have an account yet?<a href="<?php echo base_url();?>signup" class="fw-bold">Sign Up</a></p>
<p><a href="<?php echo base_url();?>forgot_password" class="fw-bold">Forgot Password</a></p>
</div>
</div>
<div class="col-lg-3"></div>
</div>
</div>
</div>

<?php $this->load->view('front/common/inner_footer');?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.js"></script>

<script type="text/javascript">
var base_url='<?php echo base_url();?>';
var front_url='<?php echo front_url();?>';
var user_id='<?php echo $user_id;?>';
var ip_address = '<?php echo $ip_address;?>';
var get_os = '<?php echo $get_os;?>';

var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';

var success = "<?php echo $this->session->flashdata('success')?>";
var error = "<?php echo $this->session->flashdata('error')?>";
$(document).ready(function() {
$.ajaxPrefilter(function (options, originalOptions, jqXHR) {
if (options.type.toLowerCase() == 'post') {
options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
if (options.data.charAt(0) == '&') {
options.data = options.data.substr(1);
}
}
});

$( document ).ajaxComplete(function( event, xhr, settings ) {
if (settings.type.toLowerCase() == 'post') {
$.ajax({
url: front_url+"get_csrf_token",
type: "GET",
cache: false,
processData: false,
success: function(data) {

$("input[name="+csrfName+"]").val(data);
}
});
}
});

});
$.validator.addMethod("emailcheck", function(value) {
return (/^\w+([.-]?\w+)@\w+([.-]?\w+)(.\w{2,3})+$/.test(value));
},"Please enter valid email address");
$('#loginuserFrom').validate({
errorClass: 'invalid-feedback',
rules: {
login_detail: {
required: true,
email:true,
emailcheck: true,
},
login_password: {
required: true
},
login_tfa: {
number: true,
minlength: 6
}
},
messages: {
login_detail: {
required: "Please enter email",
email: "Please enter valid email address",
emailcheck: "Please enter valid email address",
},
login_password: {
required: "Please enter password"
},
login_tfa: {
number: "Please enter valid tfa code",
minlength:"Enter 6 digit valid tfa code"
}
},
invalidHandler: function(form, validator) {
if (!validator.numberOfInvalids())
{
return;
}
else
{
var error_element=validator.errorList[0].element;
error_element.focus();
}
},
highlight: function (element) {
//$(element).parent().addClass('error')
},
unhighlight: function (element) {
$(element).parent().removeClass('error')
},
submitHandler: function(form)
{
$('#submit_btn').prop('disabled');
$('.spinner-border').css('display','inline-block');

var $form = $(form);
$.ajax({
url: front_url+"login_check",
type: "POST",
data: $form.serialize(),
cache: false,
processData: false,
success: function(data)
{
    console.log(data);
var d = jQuery.parseJSON(data);
if(d.status==0)
{
//toastr.error(d.msg);
 toastr.error(d.msg);
$('#submit_btn').prop('enabled');
$('.spinner-border').css('display','none');
}
else
{
if(d.tfa_status==1)
{
$('#submit_btn').prop('enabled');
$('.spinner-border').css('display','none');
}
else
{
if(d.login_url=='wallet')
{
window.location.href = front_url+"wallet";
}
else
{
window.location.href = front_url+"wallet";
}
}
toastr.info(d.msg);

}
}
});
return false;
// }
}
});
</script>

<!-- <script type="text/javascript">
    $(".toggle-password").click(function() {
      console.log($(this));
  $(this).find('.eye-icon').toggleClass("icofont-eye-blocked");
  var input = $($(this).attr("toggle"));
  if (input.attr("type") == "password") {
    input.attr("type", "text");
  } else {
    input.attr("type", "password");
  }
});
</script> -->
