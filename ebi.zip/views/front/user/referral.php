<?php
    $this->load->view('front/user/login_header');
      $settings = $site_common['site_settings']; 
      $usermail = getUserEmail($users->id);
      $user_id = $this->session->userdata('user_id');
      $referrallink=base_url()."invite?"."ref=".$users->referralid;
?>
<div class="content-body">
<div class="container-fluid">
    <div class="wrapper">
        <div class="content u-flexCenter u-sizeViewHeightMin100">
          <div class="shareUrl u-verticalGrid u-marginAuto u-size1040">
            <header class="shareUrl-header">
              <h1 class="shareUrl-headerText">Click to Copy Invite Link</h1>
              <p class="shareUrl-headerSubtext">Share your link on Twitter, Telegram or anywhere you want. &#34;The more you promote, the more you earn.&#34; </p>
            </header>
            <div class="shareUrl-body">
              <div class="container">
                <!-- COPY INPUT -->
                <input class="shareUrl-input js-shareUrl" value="<?=$referrallink;?>" type="text" readonly="readonly" />
                <p class="shareUrl-subtext">Click above to copy the link.</p>
              </div>
            </div>
            <!-- <footer class="shareUrl-footer">
              <p>Works in Chrome, Firefox, IE9, Opera.</p>
            </footer> -->
          </div>
        </div>
      </div>

      <div class="ref_count">
        <div class="col-md-10 col-lg-10 m-auto">
          <div class="row">
            <div class="col-md-3 col-lg-3">
            </div>

            <div class="col-md-3 col-lg-3">
              <div class="ref_bx">
                <span>
                  <?php

                if($users->successful_referral > 0) 
                  echo $users->successful_referral;
                else
                  echo '0'; 
                ?></span>
                <img src="<?php echo front_img();?>r1.png" alt="">
                <p>Referral Signups</p>

              </div>
            </div>

            <!-- <div class="col-md-3 col-lg-3">
              <div class="ref_bx">
                <span>10</span>
                <img src="<?php echo front_img();?>r2.png" alt="">
                <p>Successful Referral </p>

              </div>
            </div> -->

            <!-- <div class="col-md-3 col-lg-3">
              <div class="ref_bx">
                <span>3</span>
                <img src="<?php echo front_img();?>r3.png" alt="">
                <p>Exchanged Crypto</p>

              </div>
            </div> -->

            <div class="col-md-3 col-lg-3">
              <div class="ref_bx">
                <span><?php

                if($total_referral > 0) 
                  echo $total_referral;
                else
                  echo '0'; 
                ?></span>
                <img src="<?php echo front_img();?>r4.png" alt="">
                <p>Credits Earned</p>

              </div>
            </div>
             <div class="col-md-3 col-lg-3">
            </div>



          </div>
        </div>
      </div>



    <div class="cryptorio-forms cryptorio-main-form pb-5" style="overflow: auto;">

<table id="example" class="table display table-striped" style="width:100%;">
        <thead>
             <tr>
                                                <th>S.no</th>
                                                <th>Date & Time</th>
                                                <th>Referral Mail</th>
                                                <th>Amount</th>
                                                <th>Currency</th>
                                            </tr>
        </thead>
         <tbody class="opnOdrTblScroll">
                                            <?php
                                                if(isset($referral_history) && !empty($referral_history)){
                                                    $r=0;
                                                    foreach($referral_history as $referral){

                                                       $userrecs = $this->common_model->getTableData('users',array('id'=>$this->session->userdata('user_id')))->row();
                                                        $referral_recs = $this->common_model->getTableData('users',array('parent_referralid'=>$userrecs->referralid))->row();

                                                        $ref_mail = getUserEmail($referral_recs->id);
 
                                                        $r++;
                                            ?>

                                                        <tr>
                                                            <td><?php echo $r;?></td>
                                                            <td><?php echo $referral->datetime;?></td>
                                                             <td><?php echo $ref_mail;?></td>
                                                            <td><?php echo $referral->amount;?></td>
                                                            <td><?php echo strtoupper(getcryptocurrency($referral->currency));?></td>
                                                          
                                                        </tr>   
                                            <?php
                                                    }
                                                } 
                                            ?>
                                                
                                        </tbody>
    </table>
</div>

</div>
</div>
<?php 
    $this->load->view('front/common/login_footer');

?>
<script src="<?php echo front_js();?>datatables.bootstrap4.min.js"></script>
<script src="<?php echo front_js();?>dataTables.min.js"></script>
<script src="<?php echo front_js();?>datatables.bootstrap4.js"></script>

<script>
(function() {

    // Create reusable copy fn
    function copy(element) {

        return function() {
          document.execCommand('copy', false, element.select());
          toastr.success('xabits! Link Copied');
        }
    }

    // Grab shareUrl element
    var shareUrl = document.querySelector('.js-shareUrl');

    // Create new instance of copy, passing in shareUrl element
    var copyShareUrl = copy(shareUrl);

    // Set value via markup or JS
    shareUrl.value = "<?php echo $referrallink;?>";

    // Click listener with copyShareUrl handler
    shareUrl.addEventListener('click', copyShareUrl, false);


}());
</script>
<script type="text/javascript">
$(document).ready(function() {

  var language = 'english';

  if(language=='spanish')
  {

    $('table.display').DataTable( {

       "language": {

            "sProcessing": "Procesando ...",
            "sLengthMenu": "Show _MENU_ registros",
            "sZeroRecords": "No se han encontrado resultados",
            "sEmptyTable": "No hay datos disponibles en esta tabla.",
            "sInfo": "Showing registros from _START_ to _END_ of a total of _TOTAL_ registros",
            "sInfoEmpty": "Mostrando registros de 0 to 0 out of a total of 0 registros",
            "sInfoFiltered": "(filtrando un total de _MAX_ registros)",
            "sInfoPostFix": "",
            "sSearch": "bÃºsqueda:",
            "sUrl": "",
            "sInfoThousands": ",",
            "sLoadingRecords": "Cargando ...",
            "oPaginate": {
              "sFirst": "Primera",
              "sLast": "Ãšltima",
              "sNext": "PrÃ³xima",
              "sPrevious": "Previa"
            },
            "oAria": {
              "sSortAscending": ": Activate to sort the column in ascending order",
              "sSortDescending": ": Activate to sort the column in descending order"
            }


        }
    } );

  }
  else if(language=='italic')
  {
     $('table.display').DataTable( {
       "language": {

            "sProcessing": "in lavorazione ...",
            "sLengthMenu": "Mostra _MENU_ inserimenti",
            "sZeroRecords": "nessun risultato trovato",
            "sEmptyTable": "Nessun dato disponibile in questa tabella",
            "sInfo": "Visualizzazione del inserimenti da _START_ a _END_ di un totale di _TOTAL_ inserimenti",
            "sInfoEmpty": "Mostra inserimenti da 0 a 0 su un totale di 0 inserimenti",
            "sInfoFiltered": "(filtrando un totale di _MAX_ inserimenti)",
            "sInfoPostFix": "",
            "sSearch": "ricerca:",
            "sUrl": "",
            "sInfoThousands": ",",
            "sLoadingRecords": "Caricamento in corso ...",
            "oPaginate": {
              "sFirst": "Primo",
              "sLast": "Ultimo",
              "sNext": "Prossimo",
              "sPrevious": "Precedente"
            },
            "oAria": {
              "sSortAscending": ": Activate to sort the column in ascending order",
              "sSortDescending": ": Activate to sort the column in descending order"
            }


        }

    });

  }

  else
  {

    $('table.display').DataTable();


  }


} );

</script>