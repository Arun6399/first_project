<?php $this->load->view('front/user/login_header.php');?>
<div class="token-info-sec">
    <div class="container">
        <div class="sec-title text-center">
        <h1 data-watermark="Forgot Password">
                <span>Forgot</span> Password
            </h1>
            <!-- <p>Forgot Password</p> -->
        </div>
        <div class="row">
        <div class="col-lg-3"></div>
            <div class="col-lg-6">
            <?php 
                        $action = front_url()."login";
                        $attributes = array('id'=>'forgot_user','autocomplete'=>"off",'class'=>'auth_form'); 
                        echo form_open($action,$attributes);
                        ?>
                    <div class="single-input-box box-1">
                       <!--  <input type="email" placeholder="Enter Your Email Address" id="forgot_detail" name="forgot_detail"> -->
                         <input type="email" class="form-control" placeholder="Enter Your Email Address" aria-label="email"  id="forgot_detail" name="forgot_detail">
                      <!--   <span class="input-icon">
                            <i class="icofont-ui-user"></i>
                        </span> -->
                    </div>
                    <label id="forgot_detail" class="erro1r" for="email"></label>
                    
                   <br>
                    <button id="submit_btn" class="btn btn-success btn-round" type="submit">Request</button>
               <?php echo form_close();?>
                    <div class="mt-5">
                        <p>Sign into your account again for full access <a href="<?php echo base_url();?>login" class="fw-bold">Sign In</a></p>
                        
                    </div>
                    
            </div>
            <div class="col-lg-3"></div>
        </div>
    </div>
</div>


<?php
 $this->load->view('front/common/footer.php');
?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.js"></script>
<script type="text/javascript">
        var base_url='<?php echo base_url();?>';
    var front_url='<?php echo front_url();?>';
    var user_id='<?php echo $user_id;?>';
    var ip_address = '<?php echo $ip_address;?>';
    var get_os     = '<?php echo $get_os;?>';

    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';

     var success = "<?php echo $this->session->flashdata('success')?>";
    var error = "<?php echo $this->session->flashdata('error')?>";
  
        if(success!=''){
toastr.info('Cripyic! '+success);
//alert(success);
}
if(error!=''){
    toastr.error('Cripyic! '+error);
}


    $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
        if (options.type.toLowerCase() == 'post') {
            options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
            if (options.data.charAt(0) == '&') {
                options.data = options.data.substr(1);
            }
        }
    });

    $( document ).ajaxComplete(function( event, xhr, settings ) {
        if (settings.type.toLowerCase() == 'post') {
            $.ajax({
                url: front_url+"get_csrf_token", 
                type: "GET",
                cache: false,             
                processData: false,      
                success: function(data) {

                     $("input[name="+csrfName+"]").val(data);
                }
            });
        }
    });

    
    $.validator.addMethod("emailcheck", function(value) {
        return (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(value));
    },"Please enter valid email address"); 
    
    $('#forgot_user').validate({
        errorClass: 'invalid-feedback',
        rules: {
            forgot_detail: {
                required: true,
                email:true,
                emailcheck: true,
            }
        },
        messages: {
            forgot_detail: {
                required: "Please enter email",
                email: "Please enter valid email address",
                emailcheck: "Please enter valid email address"
            }
        },
        invalidHandler: function(form, validator) {
            if (!validator.numberOfInvalids())
            {
                return;
            }
            else
            {
                var error_element=validator.errorList[0].element;
                error_element.focus();
            }
        },
        highlight: function (element) {
          //$(element).parent().addClass('error')
        },
        unhighlight: function (element) {
          $(element).parent().removeClass('error')
        },
        submitHandler: function(form) {
            var $form = $(form);
        
            $.ajax({
            url: front_url+"forgot_check", 
            type: "POST",             
            data: $form.serialize(),
            cache: false,             
            processData: false,    
            beforeSend: function() {
                $(':input[type="submit"]').prop('disabled', true);
            },
            success: function(data) {
                //console.log(data);
                var d = jQuery.parseJSON(data);
                if(d.status==0)
                {
                    $('#forgot_detail').val('');
                    $(':button[type="submit"]').prop('disabled', false);

                   
                     toastr.error(d.msg);
                }
                else
                { 
                   
                    $('#forgot_detail').val('');
                    $(':input[type="submit"]').prop('disabled', false);

                    
                    toastr.info(d.msg);

                }
            }
        });
        return false;
        }
    });
    </script>

</body>

</html>