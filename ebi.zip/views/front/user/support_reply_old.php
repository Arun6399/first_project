<?php
    $this->load->view('front/user/login_header');
    $user_id = $this->session->userdata('user_id');
     $all_currency = $this->common_model->getTableData("currency",array("status"=>1))->result();
      if(count($all_currency))
      {
        $tot_balance = 0;
        foreach($all_currency as $cur)
        {
            $balance = getBalance($user_id,$cur->id);
            $usd_balance = $balance * $cur->online_usdprice;

            $tot_balance += $usd_balance;
        }
      }
?>
    <!-- <link rel="stylesheet" href="<?php echo front_css();?>custom.css"> -->

<style>

#myImg {
  border-radius: 5px;
  cursor: pointer;
  transition: 0.3s;
}

#myImg:hover {opacity: 0.7;}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.9); /* Black w/ opacity */
}

/* Modal Content (image) */
.modal-content {
  margin: auto;
  display: block;
  width: 30%;
  max-width: 700px;
}

/* Caption of Modal Image */
#caption {
  margin: auto;
  display: block;
  width: 80%;
  max-width: 700px;
  text-align: center;
  color: #ccc;
  padding: 10px 0;
  height: 80px;
}

/* Add Animation */
.modal-content, #caption {  
  -webkit-animation-name: zoom;
  -webkit-animation-duration: 0.6s;
  animation-name: zoom;
  animation-duration: 0.6s;
}

@-webkit-keyframes zoom {
  from {-webkit-transform:scale(0)} 
  to {-webkit-transform:scale(1)}
}

@keyframes zoom {
  from {transform:scale(0)} 
  to {transform:scale(1)}
}

/* The Close Button */
.close {
  position: absolute;
  top: 15px;
  right: 35px;
  color: #f1f1f1;
  font-size: 40px;
  font-weight: bold;
  transition: 0.3s;
}

.close:hover,
.close:focus {
  color: #bbb;
  text-decoration: none;
  cursor: pointer;
}
.img-thumbnail{
  max-width: 100px;
}

/* 100% Image Width on Smaller Screens */
@media only screen and (max-width: 700px){
  .modal-content {
    width: 100%;
  }
}

.eye-icon{
  font-size: 20px;
height: 45px;
width: 45px;
color:#007bff;
}
/*.support-reply-btn{

  height: 40px;
}
*/
.logo{
  line-height: 2.5rem;
}
</style>
<div class="content-body">
            <div class="container-fluid">
                <div class="row">
                   
                    <div class="col-xl-12 col-md-12">
                        <div class="row">

                            <div class="col-xl-12">
                                <div class="card">
                                    
                                    <div class="card-body">
         <div class="dashboard-section">
                    <div class="dashboard-box">
                        <div class="dashboard-box-inner pb-0">
                            <h2 class="text-center">Support Ticket</h2>

                           
                         <div class="profile-details">
                                 <div class="form-row ml-auto mx-auto form-bor">
                                    <div class="form-group col-md-6 form-pad-30">
                                        <h2>Ticket ID- <?php echo $support->ticket_id;?></h2>
                                        <?php $img =  ($users->profile_picture)?$users->profile_picture:front_img().'non-verify_1.png';?>
                                        <img class="img-thumbnail" src="<?php echo $img;?>">
                                       <table class="table">
                                         <thead>
                                           </thead>
                                             <tbody>
                                               <tr>
                                                            <td>Subject</td>
                                                            <td>:</td>
                                                            <td><?php echo $support->subject;?></td>
                                                        </tr>
                                                        <tr>

                                                            <td>Created On</td>
                                                            <td>:</td>
                                                            <td><?php echo time_calculator($support->created_on); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Category</td>
                                                            <td>:</td>
                                                            <td><?php echo getSupportCategory($support->category);?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Message</td>
                                                            <td>:</td>
                                                            <td><?php echo htmlentities($support->message); ?></td>
                                                        </tr>
                                           </tbody>
                                        </table>
                                    </div>
                                    <div class="form-group col-md-6 form-pad-30">
                                          <div class="card msgcard">
                                            <div class="card-bodys">
                                              <div class="container-fluid">
                                                <div id="messages_container" class="chat-log">

                                                    <?php
                                                    if(isset($support_reply) && !empty($support_reply)){
                                                        $i=0;
                                                         foreach($support_reply as $reply) 
                                                    {  $i++;

                                                        $time = time_calculator($reply->created_on);
                                                          $reply_msg = $reply->message;
                                                          $reply_file = $reply->image;

                                                        if($reply->user_id ==0) 
                                                        {
                                                            $img1 = front_img().'admin-user.jpg';

                                                            ?>


                                                  <div class="chat-log_item chat-log_item z-depth-0">
                                                    <div class="row justify-content-end mx-1 d-flex">
                                                      <div class="col-auto px-0">
                                                        <span class="chat-log_author">

                                                            <?php 
                                                    if(isset($reply_file) && !empty($reply_file)){
                                                        ?>

                                                      <a href="#" onclick="myFunction('<?php echo $reply_file;?>')" style="font-size: 15px;" ><span class="eye-icon"><i class="la la-eye"> </i> </span></a>
                                                    <?php
                                                    }
                                                    ?>


                                                              <?php echo $time;?>
                                                           <span class="eye-icon"><i class="la la-file"> </i> </span> 
                                                        </span>
                                                      </div>
                                                      <div class="col-auto px-0">
                                                      </div>
                                                    </div>
                                                    <hr class="my-1 py-0 col-8" style="opacity: 0.5">
                                                    <div class="chat-log_message">

                                                      <p><?php echo $reply_msg;?></p>
                                                    </div>
                                                   </div>

                                                  <?php
                                                        }
                                                        else
                                                        {
                                                  ?>

                                                                        <div class="chat-log_item chat-log_item-own z-depth-0">
                                                                        <div class="row justify-content-end mx-1 d-flex">
                                                                          <div class="col-auto px-0">
                                                                            <span class="chat-log_author">
                                                                                <?php 
                                                                                if(isset($reply_file) && !empty($reply_file)){
                                                                                    ?>


                               <a style="font-size: 15px;"  href="#" onclick="myFunction('<?php echo $reply_file;?>')"><span class="eye-icon"><i class="la la-eye"> </i> </span></a>
                                                                                    <?php
                                                                                }
                                                                                ?>
                                                                                 <?php echo $time;?>
                                                                                <span class="eye-icon"><i class="la la-file"> </i> </span> 
                                                                            </span>
                                                                          </div>
                                                                          <div class="col-auto px-0">
                                                                          </div>
                                                                        </div>
                                                                        <hr class="my-1 py-0 col-8" style="opacity: 0.5">
                                                                        <div class="chat-log_message">
                                                                          <p><?php echo $reply_msg;?>
                                                                          </p>
                                                                        </div>
                                                                       
                                                                      </div>    

                                                    <?php } } } ?>
                                                          
                                                       
                                                        


                                                </div>
                                              </div>
                                            </div>
                                            <?php
                                        if($support->close==0)
                                        {                             
                                        $attributes=array('id'=>'reply');
                                        echo form_open_multipart($action,$attributes);
                                        ?>
                                             <div class="input-group">
                                        
                                        <div class="input-group-prepend">
                                             <input type="file" class="custom-file-input d-none" id="imageUpload2" name="image">
                                                <label class="support-trigger-btn" for="imageUpload2" style="margin-bottom: 0 !important;background: #6456ff; height: 49px;"><span><i class="la la-paperclip" aria-hidden="true"></i></span></label>
                                        </div>
                                        <input type="text" name="message" id="message" class="form-control" placeholder="" aria-label="Recipient's username" aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button type="submit" class="support-reply-btn" style="height: 49px;"><span><i class="la la-paper-plane" aria-hidden="true"></i></span></button>

                                        </div>
                                        <br>
                                       <label id="img_error" class="error"></label>
                                    </div>
                                     <img id="support_img" src="" alt="Support Img" style="display: none;" class="img-fluid mb-6 proof_img logo"><label style="color: #ffffff;" id="image_name">
                                          </div>
                                          <?php
                                                echo form_close();
                                            }
                                        ?>


                                    </div>
                                    
                                 </div>
                                 
                        </div>
                        </div>
                            </div>
                            </div>
                            

<div id="myModal" class="modal">
  <span class="close">&times;</span>
  <img class="modal-content" id="img01">
  <div id="caption"></div>
</div>  

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>  
<?php 
    $this->load->view('front/common/footer');
    $user_id    = $this->session->userdata('user_id');
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $get_os     = $_SERVER['HTTP_USER_AGENT'];
    ?>

    <script type="text/javascript">
         var base_url='<?php echo base_url();?>';
    var front_url='<?php echo front_url();?>';
    var user_id='<?php echo $user_id;?>';
    var ip_address = '<?php echo $ip_address;?>';
    var get_os     = '<?php echo $get_os;?>';

    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';


    $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
        if (options.type.toLowerCase() == 'post') {
            options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
            if (options.data.charAt(0) == '&') {
                options.data = options.data.substr(1);
            }
        }
    });

    $( document ).ajaxComplete(function( event, xhr, settings ) {
        if (settings.type.toLowerCase() == 'post') {
            $.ajax({
                url: front_url+"get_csrf_token", 
                type: "GET",
                cache: false,             
                processData: false,      
                success: function(data) {

                     $("input[name="+csrfName+"]").val(data);
                }
            });
        }
    });


    $("#imageUpload2").change(function() {
        document.getElementById("support_img").style.display = "block";
        readURL4(this);
    });

function scrollDown() {
  $('#messages_container').animate({scrollTop:$('#messages_container').prop('scrollHeight')}, 100);
}

    function readURL4(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#support_img').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }

    $('#reply').validate({
        rules: {
            
            message: {
                required: true
            }
        },
        messages: {
            
            message: {
                required: "'Please enter message"
            }
        },
    });

$('input[type=file]#imageUpload2').change(function(){ 
        $("#image_name").html($("#imageUpload2").val());
        var ext = $('#imageUpload2').val().split('.').pop().toLowerCase();
        if($.inArray(ext, ['gif','png','jpg','jpeg']) == -1) {
            $("#img_error").html("<?php echo $this->lang->line('Please upload proper file format');?>");
            $(':button[type="submit"]').prop('disabled', true);
        }
        else{  
            $("#img_error").html('');
            $(':button[type="submit"]').prop('disabled', false); 
        }
    });
</script>

<script>
// Get the modal
var modal = document.getElementById("myModal");

var img = document.getElementById("rep_img");
var modalImg = document.getElementById("img01");
var span = document.getElementsByClassName("close")[0];
function myFunction(src) {

  modal.style.display = "block";
  modalImg.src = src;
}

span.onclick = function() { 
  modal.style.display = "none";
}

</script>


</body>
</html>