<?php $this->load->view('front/user/login_header');
 $user_id = $this->session->userdata('user_id');
 ?>



      <div class="page-body" >
        <div class="container-xl">
         
<style>
    .form-control:not([size]):not([multiple]) {
    height: calc(2.25rem + 7px) !important;
}
.table.th{
  float: left;
}

</style>


<div class="row">
    <div class="col-md-12 col-lg-4">
   
      <div class="ap_pnl">
        <div class="ap_log_h1 ">Deposit</div>
        <div class="ap_depo_sel_hd ">Deposit Using  
          <select class="ap_depo_sel_selc" onChange="change_address(this.value)">
    
                                                        <?php
                                                        if(count($all_currency) > 0)
                                                        {
                                                            foreach ($all_currency as $currency) 
                                                            {
                                                        ?>
                                              <option value="<?php echo $currency->id.'#'.$currency->type;?>" <?=($sel_currency->id == $currency->id)?'selected':''?>>
                                              <?=$currency->currency_symbol?>
                                              </option>
                                              <?php } } ?>
        </select></div>
       
     <div class=" col-md-2 mr-auto">
                                  <?php                                 
                                  if($sel_currency->type=='digital')
                                    $style = 'display:block';
                                  else
                                    $style = 'display:none';
                                   ?>
                                    <img class="qr-code" id="qr_img" style="height: 200px; max-width: 1000% !important;height: 200px;<?=$style;?>" src="<?php echo $First_coin_image;?>"> 
                                </div>
      <div class="ap_depo_qr_stxt">Scan QR (or) Copy Address<br> For Deposit</div>
       <div class="form-group text-left cryp_add" <?php if($sel_currency->type == 'fiat'){ ?> style="display: none;" <?php } ?>>
                                       
                                        <input type="text" class="form-control" readonly="" value="<?php echo $crypto_address;?>" id="crypto_address">
                                    </div>

                                    <div class="col-md-6 mr-auto deposit-address fiat_deposit" <?php if($sel_currency->type != 'fiat'){?> style="display: none;" <?php } ?>>
                            <?php
                            if(trim($user->verify_level2_status)=='Completed')
                                            {
                                    ?>
                            <div class="text-center">
                           

                              <a  class="btn btn-success waves-effect waves-light button" href="javascript:;" style="margin-right:20px;"  data-toggle="modal" data-target="#bankwire" data-dismiss="modal" aria-label="Close" id="btnn">Bank Wire</a> 

                            <b><p id="tet" class="color" style="display:none;">Bank details not update this currency.. Please contact Admin</p></b>


                            </div>



                            <?php } else {  ?>

                                <div class="text-center mt-3 mb-2">Please Complete KYC<a  class="btn btn-danger" style="margin-left: 30px;" href="<?php echo base_url();?>kyc"> Click here</a></div><?php } ?>
                                </div>
      
      </div>
    </div>

      <div class="modal fade right" id="bankwire" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true"> 
  
  <!-- Add class .modal-full-height and then add class .modal-right (or other classes from list above) to set a position to the modal -->
  <div class="modal-dialog modal-full-height modal-right iks-popup" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background: #d3d6f3;">
        <h4 class="modal-title w-100" id="myModalLabel">Bankwire Deposit</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
      </div>
      <div class="modal-body" style="background: #d3d6f3;"> 
        <div class="col-sm-12">
              <div class="row">
                <div class="col-sm-12 deposit-address bank_wire">
                  <?php  $action = base_url()."deposit";
       $attributes = array('id'=>'deposit_fiat','autocomplete'=>"off"); 
        echo form_open($action,$attributes); 
                                        ?>     
                  <input type="hidden" name="currency" id="banwire_id" class="currency" value="<?php echo $sel_currency->id;?>" >
                  <div class="form-row"> 
                    <table class="table popup">
                      <tr>
                        <th>Account Number</th>
                        <td><strong id="account_number"><?=$user_bank->bank_account_number?></strong></td>
                      </tr>
                      <tr>
                        <th>Bank Swift</th>
                        <td><strong id="swift"><?=$user_bank->bank_swift?></strong></td>
                      </tr>
                      <tr>
                        <th>Account Name</th>
                        <td><strong id="account_name"><?=$user_bank->bank_account_name?></strong></td>
                      </tr>
                      
                      <tr>
                        <th>Bank Name</th>
                        <td><strong id="bank_name"><?=$user_bank->bank_name?></strong></td>
                      </tr>
                      <tr>
                        <th>POSTAL Code</th>
                        <td><strong id="postal_code"><?=$user_bank->bank_postalcode?></strong></td>
                      </tr>
                      <tr>
                        <th>Bank city</th>
                        <td><strong id="bank_city"><?=$user_bank->bank_city?></strong></td>
                      </tr>
                       <tr>
                        <th>Bank Address</th>
                        <td><strong id="bank_address"><?=$user_bank->bank_address?></strong></td>
                      </tr>
                    <!--    <tr>
                        <th>Bank country</th>
                        <td><strong id="bank_country"><?php echo getcountryname($user_bank->bank_country); ?></strong></td>
                      </tr> -->
                    </table>
 
                    
                      <input type="hidden"  name="account_number" value="<?=$user_bank->bank_account_number ;?>">
                      <input type="hidden"  name="account_name" value="<?=$user_bank->bank_account_name;?>">
                       <input type="hidden"  name="bank_name" value="<?=$user_bank->bank_name;?>">
                        <input type="hidden"  name="bank_swift_code" value="<?=$admin_bankdetails->bank_swift;?>">
                         <input type="hidden"  name="bank_country" value="<?=$user_bank->bank_country;?>">
                         <input type="hidden"  name="bank_city" value="<?=$user_bank->bank_city;?>">
                         <input type="hidden"  name="bank_postalcode" value="<?=$user_bank->bank_postalcode;?>">
                          <input type="hidden"  name="bank_address" value="<?=$user_bank->bank_address;?>">

                     <div class="row">
                        <div class="col-12 col-md-12">
                          <label for="basic-url">Enter amount<span style="color: #fff;">*</span></label>
                          <div class="mb-3">
                            <input type="text"  required="" style="border: 1px solid #7b6fff;" class="form-control input_anim" aria-label="Small" aria-describedby="inputGroup-sizing-sm" name="amount">
                          </div>
                        </div>


                         <div class="col-12 col-md-12">
                          <label for="basic-url">Description<span style="color: #fff;">*</span></label>
                          <div class="mb-3">

                            <?php
                            $permitted_chars = 'GTILGDE7980493WTIAYXQJ804761';
                            $random=substr(str_shuffle($permitted_chars), 0, 10);
                            ?>

                            <input type="text" readonly="" style="border: 1px solid #7b6fff;" class="form-control input_anim description" aria-label="Small" aria-describedby="inputGroup-sizing-sm" name="description" id="description" value="<?=$random;?>"  > 
<!-- value="<?=$random;?>" -->

                          </div>
                        </div> 
                     
                      </div>    

                    <div class="col-12 col-md-12">
                      <div class="row">
                        <div class="col-12 col-md-12">
                          <div class="profile-flex border-0 pt-4 pull-left">
                            <div class="text-center">
                              <button name="deposit_bank" id="deposit_bank" class="btn btn-success waves-effect waves-light button" type="submit"> Deposit </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <?php echo form_close();?> </div>
              </div>
            </div>
       </div>
    
    </div>
  </div>
</div>


    <div class="col-md-12 col-lg-8">
     
      <div class="table_panel" style="padding-top: 20px;">
                        <div class="table_panel_heading justify-content-between align-items-center disp">
                            <h4>Deposit History</h4>
                       
                        </div>
                        <div class="table_panel_body">
                            <div class="table-responsive">
                              <table class="table table-borderless" id="table">
                                <thead>
                                  <tr>
                                    <th>Coin</th>
                                    <th>Date&Time</th>
                                    <th>Transaction ID</th>
                                    <th>Description</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <?php if($sel_currency->id == 7){?>
                                    <th class="fiat_div">Update</th>
                                    <?php
                                  }
                                    ?>
                                  </tr>
                                </thead>
                                <tbody class="table_scroll">
                                  <?php
                                                            if(isset($deposit_history) && !empty($deposit_history))
                                                            {
                                                                $a=0;
                                                                foreach($deposit_history as $deposit)
                                                                {
                                                                    $a++;
                                                                    if(empty($deposit->transaction_id))
                                                                    {
                                                                      $transaction_id = '-';
                                                                    }
                                                                    else
                                                                    {
                                                                      $transaction_id = $deposit->transaction_id;
                                                                    }     
                                                        ?>
                                  <tr>
                                    <td><?php echo strtoupper(getcryptocurrency($deposit->currency_id));?></td>
                                    <td><?php echo date('d-M-Y H:i',$deposit->datetime);?></td>
                                    <!-- <td class="address"> --><td><?php echo $transaction_id;?></td>

                                    <td><?php echo $deposit->description;?></td>
                                    <td><?php echo number_format($deposit->amount,8);?></td>
                                    <?php if($deposit->status =='Completed')
                                                                {
                                                                    $clr_class = 'green';
                                                                }
                                                                else
                                                                {
                                                                    $clr_class = 'red';
                                                                } ?>
                                    <td id="dep<?php echo encryptIt($deposit->trans_id);?>"><span class="<?php echo $clr_class;?>"><?php echo $deposit->status;?></span></td>
                                    <?php if($sel_currency->id == 7){
                                      if($deposit->status=='Pending'){
                                      ?>

                                    <td class="fiat_div"><i class="fa fa-refresh" aria-hidden="true"  style="cursor: pointer;"></i></td>
                                    <?php
                                  }
                                  else{
                                    ?>
                                    <td class="fiat_div">-</td>
                                    <?php
                                  }
                                  }
                                    ?>
                                  </tr>
                                  <?php 
                                                                } 
                                                            }else{ 
                                                        ?>
                                  <tr>
                                    <td colspan="6" style="text-align: center;">No records found !!!</td>
                                  </tr>
                                  <?php } ?>
                                </tbody>
                              </table>
                            </div>
                        </div>
                    </div>
    </div>
  </div>


          </div>
        </div>
      </div>
      <?php $this->load->view('front/common/footer');?>
      <script src="<?php echo front_js();?>datatables.bootstrap4.min.js"></script>
     <script src="<?php echo front_js();?>dataTables.min.js"></script>
     <script src="<?php echo front_js();?>datatables.bootstrap4.js"></script>

    <script type="text/javascript">
$(document).ready(function() {
 
sel =$('.ap_depo_sel_selc').val();
change_address(sel);

    $('#table').DataTable();
        });


         var base_url='<?php echo base_url();?>';
    var front_url='<?php echo front_url();?>';

         var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';


        $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
            if (options.type.toLowerCase() == 'post') {
                options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
                if (options.data.charAt(0) == '&') {
                    options.data = options.data.substr(1);
                }
            }
        });

        $( document ).ajaxComplete(function( event, xhr, settings ) {
            if (settings.type.toLowerCase() == 'post') {
                $.ajax({
                    url: front_url+"get_csrf_token", 
                    type: "GET",
                    cache: false,             
                    processData: false,      
                    success: function(data) {
                            var dataaa = $.trim(data);
                         $("input[name="+csrfName+"]").val(dataaa);
                    }
                });
            }
        });


 




        function copy_function() 
        {
            var copyText = document.getElementById("crypto_address");
            copyText.select();
            document.execCommand("COPY");
            $('.copy_but').html("COPIED");
        }

        function change_address(sel)
        {
            var arr1 = sel;
            var arr = arr1.split('#');
            var currency_id = arr[0];
            var type = arr[1];
            if(type=='fiat')
            {
              
                //alert(arr[0]);
                $(".grey-box").css('display','none');
                $(".cryp_add").css('display','none');
                $(".fiat_amt").css('display','block');
                $(".dig_button").css('display','none');
                $(".fiat_div").css('display','block');
                $(".fiat_deposit").css('display','block');
                $("#qr_img").css('display','none');
                
                $.ajax({
                    url: base_url+"change_address",
                    type: "POST",
                    data: "currency_id="+currency_id,
                    success: function(data) {
                        var res = jQuery.parseJSON(data);


                        console.log(res);
                        if(res.description!=null)
                        {
                          $('.description').val(res.description);  
                        }
                        else{
                         
                          random_generate(); 
                        }

                       
                       
                        $('#minimum_deposit').html(res.minimum_deposit);



                       $('#account_number').html(res.bank_account_number);
                        $('#swift').html(res.bank_swift);
                        $('#account_name').html(res.bank_account_name);
                        $('#bank_name').html(res.bank_name);
                        $('#postal_code').html(res.bank_postalcode);
                         $('#bank_city').html(res.bank_city);
                         $('#bank_address').html(res.bank_address);
                         $('#bank_country').html(res.bank_country);
                         $('#description').html(res.description);

                           if(res.bank_account_number!=null)
                         {

                          // console.log('block');
                           $("#btnn").css('display','block');
                           $("#tet").css('display','none');
                         }
                         else
                         {
                          // console.log('none');
                          $("#btnn").css('display','none');
                          $("#tet").css('display','block');
                        }
                    }
                });
                $("#currency").val(currency_id);
                $(".currency").val(currency_id);
                 $("#paypro_cur").val(currency_id);
            }
            else
            { 
              // console.log(currency_id);
              $(".grey-box").css('display','block');
                $(".fiat_div").css('display','none');
                $(".fiat_amt").css('display','none');
                $(".cryp_add").css('display','block');
                $(".fiat_deposit").css('display','none');
                $('.bank_wire').css('display','none');
                $('.paypal_form').css('display','none');
                $(".dig_button").css('display','block');
                $("#wallet_deposit").css('display','none');               
                 $("#qr_img").css('display','block');
                $.ajax({
                    url: base_url+"change_address",
                    type: "POST",
                    data: "currency_id="+currency_id,
                    success: function(data) {
                        var res = jQuery.parseJSON(data);
                        $('#crypto_address').val(res.address);
                        $("#qr_img").attr("src",res.img);
                        $('.det_tag').css('display','none');
                        $('#minimum_withdrawal').html(res.minimum_deposit);
                        $('.syname').html(res.coin_name);
                        // $('.sym').html(res.coin_symbol);
                        
                        console.log(currency_id);
                        // if(currency_id == '5'){
                        //   console.log(currency_id);
                        //   $("#qr_img").css('display','none');
                        // } else{
                        //   // console.log(currency_id);
                        //   $("#qr_img").css('display','block');
                        // }
                       

                    }
                });
            }
        }

       
        function show_paypal(){
            $(".bank_wire").css("display","none");
            $('.paypal_form').css('display','');
        }


        $('#deposit_fiat').validate(
        {
            rules: {
             
                amount: {
                  required: true,
                  number: true,
                },
                description: {
                   required: true
                }
            },
            messages: {
              
              amount: {
                    required: "Please enter amount",
                    number: "Only enter numbers as decimal or float"
                },
                description: {
                    required: "Please enter Description"
                }

            },
            invalidHandler: function(form, validator) {
                if (!validator.numberOfInvalids())
                {
                    return;
                }
                else
                {
                    var error_element=validator.errorList[0].element;
                    error_element.focus();
                }
            },
            highlight: function (element) {
                //$(element).parent().addClass('error')
            },
            unhighlight: function (element) {
                $(element).parent().removeClass('error')
            },
            submitHandler: function(form) 
            { 
                form.submit();
            }
        });

        


        $('#paypro_form').validate(
        {
            rules: {
             
                paypro_amount: {
                  required: true,
                  number: true,
                }
            },
            messages: {
              
              paypro_amount: {
                    required: "Please enter amount",
                    number: "Only enter numbers as float",
                }
            },
            invalidHandler: function(form, validator) {
                if (!validator.numberOfInvalids())
                {
                    return;
                }
                else
                {
                    var error_element=validator.errorList[0].element;
                    error_element.focus();
                }
            },
            highlight: function (element) {
                //$(element).parent().addClass('error')
            },
            unhighlight: function (element) {
                $(element).parent().removeClass('error')
            },
            submitHandler: function(form) 
            { 
                form.submit();
            }
        });

        


    </script>
    
<script type="text/javascript">
function process(input){
let value = input.value;
let numbers = value.replace(/[^0-9]/g, "");
input.value = numbers;
}
</script>


<script>
  function random_generate() {

  var length = 15;
var result = '';
var characters = 'AUICPOT6193537190HIJKLMNOPQRUNDQLAPNCXWXYZ540123452326789';
var charactersLength = characters.length;
for ( var i = 0; i < length; i++ ) {
result += characters.charAt(Math.floor(Math.random() *
charactersLength));
}
  
  $('#description').val(result);
  // $('#description').html(result);

// return result;
}

</script>

  </body>
</html>