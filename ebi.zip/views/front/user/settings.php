<?php
    $this->load->view('front/user/login_header');
    $user_id = $this->session->userdata('user_id');
     $all_currency = $this->common_model->getTableData("currency",array("status"=>1))->result();
      if(count($all_currency))
      {
        $tot_balance = 0;
        foreach($all_currency as $cur)
        {
            $balance = getBalance($user_id,$cur->id);
            $usd_balance = $balance * $cur->online_usdprice;

            $tot_balance += $usd_balance;
        }
      }
?>
      <!-- Page Content -->
        <div class="content-body">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-12">
                                <div class="card">
                                    
                                    <div class="card-body">

                <div class="dashboard-section">
                    <div class="dashboard-box">
                        <div class="dashboard-box-inner pb-0">
                            <h4 class="card-title">Change Password</h4>
                            <div class="profile-details setting-details">
                                <?php 
                                     $attributes=array('id'=>'change_password1','class'=>'change_password_form');
                                     $action=base_url().'settings';
                                     echo form_open($action,$attributes); ?>

                                         <input type="hidden" name="latincoin" value="253d521c8b2a4fe7d17412ac5a8b0e1c">
                                    <div class="form-row ml-auto mx-auto form-bor">
                                        <div class="form-group col-md-4 form-pad-30">
                                            <label for="oldpass" class="active">Old Password</label>
                                             <input type="password" class="form-control" name="oldpass" id="oldpass" placeholder="Enter Your Current Password">
                                        </div>
                                        <div class="form-group col-md-4 form-pad-30">
                                            <label for="newpass" class="active">New Password</label>
                                            <input type="password" class="form-control"  name="newpass" id="newpass" placeholder="Enter Your New Password">
                                        </div>
                                        <div class="form-group col-md-4 form-pad-30">
                                            <label for="confirmpass" class="active">Confirm Password</label>
                                            <input type="password" class="form-control"  name="confirmpass" id="confirmpass" placeholder="Enter Your Confirm New Password">
                                        </div>
                                    </div>
                                    <div class="form-btn">
                                        <button class="btn btn-success waves-effect waves-light button" type="submit" name="chngpass">Change Password</button>
                                    </div>
                                  <?php echo form_close();?>
                                      </div>
                        </div>
                    </div>

                    <div class="dashboard-box">
                        <div class="dashboard-box-inner mt-5 pb-0">
                        <h4 class="card-title">2 STEP VERIFICATION</h4>
                            <div class="profile-flex border-0 pt-3">
                                <div class="col-12 col-md-8 ml-auto mx-auto">
                                    <div class="row">
                                        <div class="col-12 col-md-6">
                                            <label class="text-capitalize">To Get The Google Authenticator Details Please</label>
                                            <a href="https://support.google.com/accounts/answer/1066447" target="_blank" class="btn btn-sm btn-clr-blue waves-effect waves-light">Click here</a>
                                            <?php 
                                            $attributes1=array('id'=>'security','class'=>'deposit_form');
                                            $action1=base_url().'security';
                                            echo form_open($action1,$attributes1); 
                                            if($users->randcode=='' || $users->randcode=='disable')
                                            {
                                              $btn_content = $this->lang->line('ENABLE');
                                            }
                                             else{
                                              $btn_content = $this->lang->line('DISABLE');
                                            }                                     
                                          ?>
                                          <input type="hidden" name="latincoin" value="253d521c8b2a4fe7d17412ac5a8b0e1c">                                                                                  
                                            <div class="verify-code">
                                                
                                                    <div class="form-group">
                                                        
                                                        <input type="text" class="form-control" id="code" name="code" placeholder="Verification Code">
                                                        <input type="hidden"  name="secret" id="secret" value="<?php echo $secret;?>">
                                                    </div>
                                               
                                            </div>
                                            <button class="btn btn-success btn-sm waves-effect waves-light button" type="submit"><?php echo $btn_content;?></button>
                                            <?php echo form_close(); ?>                              </div>
                                        <div class="col-12 col-md-6 text-center">
                                            <label class="text-capitalize">Scan QR Code In Google Authenticator</label>
                                            <img src="<?php echo $url;?>" class="img-thumbnail" width="100">
                                            <div class="manual-verify">
                                                <p>Or Type The Key Manually</p>
                                                <p><span id="authenticator_key"><?php echo $secret;?></span> <span class="fs-18" style="cursor:pointer;"><i class="far fa-copy" onclick="copyToClipboard('<?php echo $secret;?>')"></i></span></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
              </div>
            </div>
           </div>     
</div> 
</div>
</div>
<?php 
    $this->load->view('front/common/login_footer');
    ?>
    <script type="text/javascript">
    var base_url='<?php echo base_url();?>';
    var front_url='<?php echo front_url();?>';
    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';

    $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
        if (options.type.toLowerCase() == 'post') {
            options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
            if (options.data.charAt(0) == '&') {
                options.data = options.data.substr(1);
            }
        }
    });

    $( document ).ajaxComplete(function( event, xhr, settings ) {
        if (settings.type.toLowerCase() == 'post') {
            $.ajax({
                url: front_url+"get_csrf_token", 
                type: "GET",
                cache: false,             
                processData: false,      
                success: function(data) {

                     $("input[name="+csrfName+"]").val(data);
                }
            });
        }
    });




  $('#change_password1').validate({
      rules: {
        oldpass: {
          required: true,
          remote: {
                    url: front_url+'oldpassword_exist',
                    type: "post",
                    csrf_token : csrfName,
                    data: {
                        oldpass: function() {
                        return $( "#oldpass" ).val();
                        }
                    }
                }
        },
       newpass: {
          required: true
        },
        confirmpass: {
          required: true,
          equalTo : "#newpass"
        }
    },
     messages: {
        oldpass: {
          required: "Please enter Old Password",
           remote: "Invalid Old Password"
        },
        newpass: {
          required: "Please enter New Password"
        },
        confirmpass: {
          required: "Please enter Confirm Password",
          equalTo : "Confirm Password not matches with New Password"
        }
    }
});  

    $('#security').validate({
        rules: {
            code: {
                required: true,
                number: true,
                minlength: 6
            }
        },
        messages: {
            code: {
                required: 'Please enter code',
                number: 'Please enter valid code',
                minlength:'Please 6 digit valid code'
            }
        }
    });

function copyToClipboard(text) {
    var copyText = document.getElementById("authenticator_key");  
    var input = document.createElement("textarea");
    input.value = copyText.textContent;
    document.body.appendChild(input);
    input.select();
    document.execCommand("Copy");
    input.remove();
}

    </script>
</body>
</html>