<?php $this->load->view('front/user/login_header'); ?>

<div class="page-body">
        <div class="container-xl">
          <div class="row">
          
            <div class="col-12" style="overflow: auto;margin-bottom: 50px;">
                <div class="col-sm-10 login-box">
                    <div class="row">
                       <div class="col-lg-4 col-md-5 box-de">

                            <div class="ditk-inf sup-oi">
                                <h2 class="w-100 text-white">Already Have an Account </h2>
                                <p class="text-white">Simply login to your account by clicking the login Button</p>
                                <a href="<?php echo base_url();?>login">
                                    <button type="button" class="btn btn-outline-light">SIGN IN</button>
                                </a>
                                <br>
                                <br>
                                <h3 class="w-100 text-white">Note :</h3>

                                <h4 class="text-white"> KYC Docs - Aadhar Card, Pan Card, Passport,Selfie.</h4>
                            </div>
                        </div>
                        <div class="col-lg-8 col-md-7 log-det">

                            <h2>Create Account</h2>
                         
                            <div class="text-box-cont">
                                  <?php $attributes=array('id'=>'register_user','class'=>'auth_form','autocomplete'=>"off");
                    echo form_open($action,$attributes); $settings = $site_common['site_settings'];
                                        ?>
                                <div class="input-group mb-3">

                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1">
                                        <i class="fa fa-user"></i></span>
                                    </div>
                                    <input type="text" class="form-control" placeholder="First Name" aria-label="Username" name="firstname" aria-describedby="basic-addon1" id="firstname">
                                </div>


                                 <div class="input-group mb-3">

                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1">
                                        <i class="fa fa-user"></i></span>
                                    </div>
                                    <input type="text" class="form-control" placeholder="Last Name" aria-label="Username" name="lastname" aria-describedby="basic-addon1" id="lastname">
                                </div>

                                 <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1">
                                            <i class="fa fa-envelope"></i>
                                        </span>
                                    </div>
                                    <input type="email" class="form-control" placeholder="Email Address" aria-label="email" id="register_email" name="register_email" aria-describedby="basic-addon1">
                                </div>
                                 <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-lock"></i></span>
                                    </div>
                                    <input type="password" class="form-control" placeholder="Password" aria-label="Password" id="register_password" name="register_password" aria-describedby="basic-addon1">
                                </div>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-lock"></i></span>
                                    </div>
                                    <input type="password" class="form-control" placeholder="Confirm Password" aria-label="Password" id="register_cpassword" name="register_cpassword" aria-describedby="basic-addon1">
                                </div>

                                <div class="input-group center sup mb-3">
                                    <button type="submit" id="submit_btn" class="btn btn-success btn-round">SIGN UP</button>
                                    <?php echo form_close();?>

                                </div>
                            </div>

                        </div>

                    </div>
                </div>

        </div>
        </div>
        </div>
        </div>

        <?php $this->load->view('front/common/footer'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.js"></script>
        <script type="text/javascript">

    var base_url='<?php echo base_url();?>';
    var front_url='<?php echo front_url();?>';

    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';


    $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
        if (options.type.toLowerCase() == 'post') {
            options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
            if (options.data.charAt(0) == '&') {
                options.data = options.data.substr(1);
            }
        }
    });

    // $( document ).ajaxComplete(function( event, xhr, settings ) {
    //     if (settings.type.toLowerCase() == 'post') {
    //         $.ajax({
    //             url: front_url+"get_csrf_token", 
    //             type: "GET",
    //             cache: false,             
    //             processData: false,      
    //             success: function(data) {
    //                 console.log(data);
    //                  $("input[name="+csrfName+"]").val(data);
    //             }
    //         });
    //     }
    // });
$(document).ready(function () {
    jQuery.validator.addMethod("mail", function(value, element) {
return this.optional(element) || /^([a-zA-Z0-9_.+-])+@(([a-zA-Z0-9-])+.)+([a-zA-Z0-9]{2,4})+$/.test(value);
});

jQuery.validator.addMethod("alphanumeric", function(value, element) {
        return this.optional(element) || /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[A-Za-z\d@$!%*#?&^_-]{8,}$/.test(value);
});


    $('#register_user').validate({
        errorClass: 'invalid-feedback',
            rules: {
                firstname: {
                required: true
            },
                 lastname : {
                    required : true
                 },
                register_email: {
                    required: true,
                    email: true,
                    mail: true,
               remote: {
                    url: front_url+'email_exist',
                    type: "post",
                    csrf_token : csrfName,
                    data: {
                        email: function() {
                            return $( "#register_email" ).val();
                        }
                    }
                }
            },
           
            register_password: {
                required: true,
                minlength: 8,
                alphanumeric: true
            },
            register_cpassword: {
                required: true,
                equalTo : "#register_password"
            }
            // country: {
            //     required: true
            // },
            // terms: {
            //     required:true
            // }
        },
        messages: {
            username: {
                required:"Please enter Username"
            },
           register_email: {
                required:"Please enter email",
                email: "Please enter valid email address",
                mail: "Please enter valid Email",
                remote: "Entered Email Address Already Exists"
            },
            register_password: {
                required: "Please enter password",
                 minlength: "Minimum 8 characters",
                alphanumeric: " Password should contains Minimum 8 characters  uppercase,lowecase,special characters and numbers"
            },
            register_cpassword: {
                required: "Please enter Confirm Password",
                equalTo : "Please enter same password"
            }
            // country: {
            //     required: "Please select country"
            // }
        },
        invalidHandler: function(form, validator) {
          if(!validator.numberOfInvalids())
          {
            return;
          }
          else
          {
            var error_element=validator.errorList[0].element;
            error_element.focus();
          }
        },
        highlight: function (element) {
          //$(element).parent().addClass('error')
        },
        unhighlight: function (element) {
          $(element).parent().removeClass('error')
        },
        submitHandler: function(form) 
        {
        $('#submit_btn').prop('disabled');
        // $('.spinner-border').css('display','inline-block');

                  var $form = $(form);
                  //alert("ddd")
                  form.submit();
          
        }
    });
});
</script>
<!-- <script type="text/javascript">
    $(".toggle-password").click(function() {
      console.log($(this));
  $(this).find('.eye-icon').toggleClass("icofont-eye-blocked");
  var input = $($(this).attr("toggle"));
  if (input.attr("type") == "password") {
    input.attr("type", "text");
  } else {
    input.attr("type", "password");
  }
});
</script> -->