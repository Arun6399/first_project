<?php
    $this->load->view('front/user/login_header');
    $user_id = $this->session->userdata('user_id');
    $referrallink=base_url()."invite?"."ref=".$users->referralid;
?>
<style type="text/css">
    .file-upload-wrapper:before {

content: "Upload";

}

</style>

<div class="content-body">
            <div class="container-fluid">
                <div class="row">
                   
                    <div class="col-xl-12 col-md-12">
                        <div class="">

                            <div class="">
                                <div class="card">
                                    
                                    <div class="card-body" style="z-index: 0;">
         <div class="dashboard-section">
            <div class="dashboard-box">
               <div class="history-tabs">
                  <ul class="nav nav-pills pt-3 justify-content-center" id="pills-tab" role="tablist">
                     <li class="nav-item">
                        <a class="nav-link active" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="true">Profile</a>
                     </li>
                     <li class="nav-item">
                        <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">Bank Details</a>
                     </li>
                  </ul>
                  <div class="tab-content" id="pills-tabContent">
                     <div class="tab-pane fade active show" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                        <div class="dashboard-box-inner pb-0">
                          <?php 
                                    $attributes=array('id'=>'verification_form',"autocomplete"=>"off"); 
                                      $action = front_url() . 'profile-edit';
                                    echo form_open_multipart($action,$attributes); 
                                ?>
                              <input type="hidden" name="latincoin" value="253d521c8b2a4fe7d17412ac5a8b0e1c">
                              <div class="profile-flex jus-start pad-l-15">
                                 <div class="col-12 col-md-12 col-lg-12 col-xl-10">
                                    <div class="row profile-img-section">
                                       <div class="col-12 col-md-8">
                                          <div class="row">
                                           <!--   <div class="col-12 col-md-12 col-lg-3">
                                                <div class="profile-img">
                                                  <?php
                                                  $pro_img = front_img().'non-verify.png';
                                                  if(!empty($users->profile_picture)){
                                                      $pro_img = $users->profile_picture;
                                                  }
                                                  ?>
                                                    <a href="javascript:void(0);" class="profile-size"><img id="profile_pic" src="<?php echo $pro_img;?>" class="img-fluid" style="width: 80px;height: 80px;border-radius: 50px;"></a>
                                                </div>
                                             </div> -->
                                         <!--     <div class="col-12 col-md-12 col-lg-8">
                                                <div class="profile-content">
                                                   <label for="inputEmail4" class="active">Profile Picture</label>
                                                 

                                                     <a class="btn btn-danger" href="#" title="Delete" onclick="delete_customer('<?=$user_id?>')"><i class="glyphicon glyphicon-trash"></i>Delete</a>
                                                    <div class="file-upload-wrapper" data-text="Change Picture">
                                                        <input name="profile_photo" type="file" class="file-upload-field" id="profile-picture" value="<?php echo $users->profile_picture; ?>">
                                                    </div>


                                                </div>
                                             </div> -->
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="profile-details">
                                 <div class="form-row ml-auto mx-auto form-bor">
                                    <div class="form-group col-md-6 form-pad-30">
                                       <label for="firstname">First Name</label>
                                       <input type="text" class="form-control" id="firstname" name="firstname" value="<?php echo $users->xabits_fname; ?>" placeholder="Enter Your First Name">
                                    </div>
                                    <div class="form-group col-md-6 form-pad-30">
                                       <label for="firstname">Last Name</label>
                                       <input type="text" class="form-control" id="lastname" name="lastname" value="<?php echo $users->xabits_lname; ?>" placeholder="Enter Your Last Name">
                                    </div>
                                    
                                 </div>
                                 <div class="form-row ml-auto mx-auto form-bor">
                                    <div class="form-group col-md-6 form-pad-30">
                                       <?php $usermail = getUserEmail($users->id);?>
                                       <label for="inputEmail4" class="active">Email</label>
                                      <input type="text" class="form-control" id="email" name="email" disabled value="<?php echo ($usermail)?$usermail:'';?>" placeholder="Enter Your Email">
                                    </div>
                                    <div class="form-group col-md-6 form-pad-30">
                                       <label for="address">Address</label>
                                       <textarea class="form-control" id="address" name="address"  placeholder="Enter Your Address"><?php echo ($users->street_address)?$users->street_address:'';?></textarea>
                                    </div>
                                 </div>
                                 <div class="form-row ml-auto mx-auto form-bor">
                                    <div class="form-group col-md-6 form-pad-30">
                                       <label for="city">City</label>
                                        <input type="text" class="form-control" id="city" name="city" value="<?php echo ($users->city)?$users->city:'';?>" placeholder="Enter Your City">
                                    </div>
                                    <div class="form-group col-md-6 form-pad-30">
                                       <label for="state">Country</label>
                                        <select class="form-control" name="register_country" id="register_country">
                                                     <option>Select Country</option>
                                        <?php if($countries) {
                                            foreach($countries as $co) {
                                              ?>
                                              <option <?php if($co->id==$users->country) { echo "selected"; } ?>
                                              value ="<?php echo $co->id; ?>"><?php echo $co->country_name; ?></option>
                                              <?php
                                            }
                                          } ?>
                                    </select>
                                    </div>
                                 </div>
                                 <div class="form-row ml-auto mx-auto form-bor">
                                    
                                    <div class="form-group col-md-6 form-pad-30">
                                       <label for="inputPassword4">Postal Code</label>
                                       <input type="text" class="form-control" id="postal_code" name="postal_code" value="<?php echo ($users->postal_code)?$users->postal_code:'';?>" placeholder="Enter Your Postal Code">
                                    </div>
                                    <div class="form-group col-md-6 form-pad-30">
                                       <label for="inputPassword4">Phone Number</label>
                                       <input type="text" class="form-control" id="phone" name="phone" value="<?php echo ($users->xabits_phone)?$users->xabits_phone:'';?>" placeholder="Enter Your Phone Number">
                                    </div>

                                     <div class="form-group col-md-6 form-pad-30">
                                       <label for="bank_postalcode">Paypal Email</label>
                                        <input type="email" class="form-control" id="paypal_email" name="paypal_email" value="<?php echo ($users->paypal_email)?$users->paypal_email:'';?>" placeholder="Enter Your email address">
                                    </div>

                                   <div class="form-group col-md-6 form-pad-30">
                                      
                                       <!-- <label for="inputEmail4" class="active">Referral Link</label> <span ><i onclick="myFunction()" class="la la-copy" style="font-size:24px;color:#fff"></i></span>
                                      <input type="text" class="form-control" id="referralid" name="referralid" disabled value="<?php echo $referrallink;?>" > -->
                                    </div>

                                 </div>
                                 <div class="form-btn">
                                    <button class="btn btn-danger waves-effect waves-light button" type="submit">SAVE</button>
                                 </div>
                              </div>
                           <?php echo form_close();?>
                        </div>
                     </div>
                     <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
                        <div class="dashboard-box-inner pb-0">
                           <h2 class="ticket-head">Bank Details</h2>
                           <div class="profile-details user_account" id="divContent">
                                 <?php
                                      $attributes=array('id'=>'bankwire',"autocomplete"=>"off","class"=>"mt-4");
                                      $action = front_url() . 'update_bank_details';
                                      echo form_open_multipart($action,$attributes);
                                  ?>
                                 <input type="hidden" name="latincoin" value="253d521c8b2a4fe7d17412ac5a8b0e1c">                                                              
                                 <div class="form-row ml-auto mx-auto form-bor">
                                    <div class="form-group col-md-6 form-pad-30">
                                      <label>COIN</label>
                                       <select class="form-control" id="currency" name ="currency">
                                        <?php
                                            if(count($currencies)>0)
                                            {
                                                foreach($currencies as $cur)
                                                {
                                        ?>
                                                    <option value="<?php echo $cur->id;?>" <?php
                                                            if(!empty($user_bank))
                                                                if($user_bank->currency==$cur->id) { echo "selected"; } ?>>
                                                        <?php echo $cur->currency_symbol;?>
                                                    </option>
                                        <?php
                                                }
                                            }
                                        ?>
                                    </select>
                                    </div>
                                    <div class="form-group col-md-6 form-pad-30">
                                       <label for="bank_account_number">Account Number</label>
                                        <?php if(!empty($user_bank)){ ?>
                                    <input type="text" class="form-control" name="bank_account_number" disabled value="<?php echo $user_bank->bank_account_number;?>">
                                    <?php }else{ ?>
                                      <input type="text" class="form-control" id="bank_account_number" name="bank_account_number" placeholder="Account Number">
                                    <?php } ?>
                                    </div>
                                 </div>
                                 <div class="form-row ml-auto mx-auto form-bor">
                                    <div class="form-group col-md-6 form-pad-30">
                                       <label for="bank_swift">Account Holder Name</label>
                                       <?php if(!empty($user_bank))
                                        { ?>
                                    <input type="text" class="form-control" disabled value="<?php echo $user_bank->bank_account_name;?>">
                                    <?php }else{ ?>
                                    <input type="text" class="form-control" id="bank_account_name" name="bank_account_name" placeholder="Account Holder Name">
                                    <?php } ?>
                                    </div>
                                    <div class="form-group col-md-6 form-pad-30">
                                       <label for="bank_name">Bank Name</label>
                                       <?php
                                        if(!empty($user_bank))
                                        {
                                    ?>
                                            <input type="text" class="form-control" disabled value="<?php echo $user_bank->bank_name;?>">
                                    <?php
                                        }else{ ?>
                                            <input type="text" class="form-control" id="bank_name" name="bank_name" placeholder="Bank Name">
                                    <?php } ?>
                                    </div>
                                 </div>
                                 <div class="form-row ml-auto mx-auto form-bor">
                                    <div class="form-group col-md-6 form-pad-30">
                                       <label for="bank_address">Bank Address</label>
                                       <?php if(!empty($user_bank)){ ?>
                                    <input type="text" class="form-control" disabled value="<?php echo $user_bank->bank_address;?>">
                                     <?php }else{ ?>
                                      <input type="text" class="form-control" id="bank_address" name="bank_address" placeholder="Bank Address">
                                    <?php } ?>
                                    </div>
                                    <div class="form-group col-md-6 form-pad-30">
                                       <label for="bank_city">Bank City</label>
                                       <?php if(!empty($user_bank)){ ?>
                                    <input type="text" class="form-control" disabled value="<?php echo $user_bank->bank_city;?>">
                                     <?php }else{ ?>
                                      <input type="text" class="form-control" id="bank_city" name="bank_city" placeholder="Bank City">
                                    <?php } ?>
                                    </div>
                                 </div>
                                 <div class="form-row ml-auto mx-auto form-bor">
                                    <div class="form-group col-md-6 form-pad-30">
                                       <label for="bank_country">Country</label>
                                       <div class="">
                                         
                                          <select name="bank_country" id="bank_country" class="form-control">
                                            <option>Select Country</option>
                                        <?php if($countries) {
                                            $banks = ($user_bank->bank_country!='')?$user_bank->bank_country:'';
                                            foreach($countries as $co) {
                                              ?>
                                              <option <?php if($co->id==$banks) { echo "selected"; } else { } ?> value="<?php echo $co->id; ?>"><?php echo $co->country_name; ?></option>
                                              <?php
                                            }
                                          } ?>
                                    </select>


                                        <!--   <button type="button" class="btn dropdown-toggle btn-light bs-placeholder" data-toggle="dropdown" role="combobox" aria-owns="bs-select-1" aria-haspopup="listbox" aria-expanded="false" data-id="bank_country" title="Select Country">
                                             <div class="filter-option">
                                                <div class="filter-option-inner">
                                                   <div class="filter-option-inner-inner">Select Country</div>
                                                </div>
                                             </div>
                                          </button> -->
                                          <div class="dropdown-menu ">
                                             <div class="bs-searchbox"><input type="search" class="form-control" autocomplete="off" role="combobox" aria-label="Search" aria-controls="bs-select-1" aria-autocomplete="list"></div>
                                             <div class="inner show" role="listbox" id="bs-select-1" tabindex="-1">
                                                <ul class="dropdown-menu inner show" role="presentation"></ul>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="form-group col-md-6 form-pad-30">
                                       <label for="bank_postalcode">Zip Code</label>
                                       <?php if(!empty($user_bank)) { ?>
                                        <input type="text" class="form-control" disabled value="<?php echo $user_bank->bank_postalcode;?>">
                                     <?php }else{ ?>
                                      <input type="text" class="form-control" id="bank_postalcode" name="bank_postalcode" placeholder="Zip Code">
                                    <?php } ?>
                                    </div>

                                     <div class="form-group col-md-6 form-pad-30">
                                       <label for="bank_postalcode">Bank Swift</label>
                                       <?php if(!empty($user_bank->bank_swift)) { ?>
                                        <input type="text" class="form-control" disabled value="<?php echo $user_bank->bank_swift;?>">
                                     <?php }else{ ?>
                                      <input type="text" class="form-control" id="bank_swift" name="bank_swift" placeholder="Bank Swift">
                                    <?php } ?>
                                    </div> 

                                    


                                 </div>
                                 <?php if(empty($user_bank)){ ?>
                                 <div class="form-btn">
                                    <button class="btn btn-danger waves-effect waves-light button" type="submit">SAVE</button>
                                 </div><?php } ?>
                               <?php echo form_close();?>
                           </div>
                        </div>
                     </div>

                     <!--- KYC SECTION --->
              
                  </div>
               </div>
            </div>
         </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>




<?php 
    $this->load->view('front/common/login_footer');
    ?>
    <script type="text/javascript">


        function readURLProfile(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#img-profile').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }
    $("#imageUpload").change(function() {
        readURLProfile(this);
    });

      $.validator.addMethod('ZipChecker', function() {
    }, 'Invalid zip code');
         $.validator.addMethod("lettersonly", function(value) {
    return (/^[a-zA-Z\s]*$/.test(value));
});

    $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
        if (options.type.toLowerCase() == 'post') {
            options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
            if (options.data.charAt(0) == '&') {
                options.data = options.data.substr(1);
            }
        }
    });

    $( document ).ajaxComplete(function( event, xhr, settings ) {
        if (settings.type.toLowerCase() == 'post') {
            $.ajax({
                url: front_url+"get_csrf_token", 
                type: "GET",
                cache: false,             
                processData: false,      
                success: function(data) {

                     $("input[name="+csrfName+"]").val(data);
                }
            });
        }
    });



    $('#verification_form').validate({
      rules: {
        firstname: {
          required: true,
           lettersonly: true
        },
        lastname: {
          required: true,
           lettersonly: true
        },
        address: {
          required: true
        },
        city: {
          required: true,
          lettersonly: true
        },
        state: {
          required: true,
          lettersonly: true
        },
        postal_code: {
          required: true,
         
          maxlength: 7,
          ZipChecker: function(element) {
          values=$("#postal_code").val();

           // if( values =="0" || values =="00" || values =="000" || values =="0000" || values =="00000"  || values =="000000"   || values =="0000000" )
           // {
           //    return true;
              
           // }
           
           }

        },
        paypal_email: {
            // required: true,
            email: true
        },
        phone: {
          required: true,
           number: true
        }
      },
      messages: {
        firstname: {
          required: "Please enter first name",
           lettersonly: "Please enter letters only"
        },
        lastname: {
          required: "Please enter last name",
           lettersonly: "Please enter letters only"
        },
        address: {
          required: "Please enter address"
        },
        city: {
          required: "Please enter city",
          lettersonly: "Please enter letters only"
        },
        state: {
          required: "Please enter state",
          lettersonly: "Please enter letters only"
        },
        postal_code: {
          required: "Please enter postal code"
        },
        paypal_email: {
           email: "Please enter email" 
        },
        phone: {
          required: "Please enter phone number"
        }
      }
    });

    $('#bankwire').validate({
    rules: {
        currency: {
            required: true
        },
        bank_name: {
            required: true,
             lettersonly: true
        },
        bank_account_number: {
            required: true,
            number: true
        },
        bank_account_name: {
            required: true,
            lettersonly: true
        },
        bank_swift: {
            required: true
        },
        bank_address: {
             required: true
        },
        bank_city: {
            required: true,
            lettersonly: true
        },
        bank_country: {
            required: true,
           // lettersonly: true
        },
        bank_postalcode: {
            required: true,
            
            maxlength: 7,
            ZipChecker: function(element) {
                values=$("#postal_code").val();
                // if( values =="0" || values =="00" || values =="000" || values =="0000" || values =="00000"  || values =="000000"   || values =="0000000" )
                // {
                //     return true;
                // }
            }
        }
    },
    messages: {
        bank_name: {
            required: "Please enter bank name",
             lettersonly: "Please enter letters only"
        },
        bank_account_number: {
            required: "Please enter bank account number"
        },
        bank_account_name: {
            required: "Please enter bank account name",
            lettersonly: "Please enter letters only"
        },
        bank_swift: {
            required: "Please enter bank swift"
        },
        bank_address: {
            required: "Please enter bank address"
        },
        bank_city: {
            required: "Please enter bank city",
            lettersonly: "Please enter letters only"
        },
        bank_country: {
            required: "Please enter bank bank country"
        },
        bank_postalcode: {
            required: "Please enter postal code"
        }
    }
});

    $("#imageUpload1").change(function() {
        readURL1(this);
    });
   $("#imageUpload2").change(function() {
        readURL2(this);
    });

   $("#imageUpload3").change(function() {
        readURL3(this);
    });
    $("#profile-picture").change(function() {
        readURL5(this);
    });


   function readURL1(input) {

        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#address_proof').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }


    function readURL2(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#id_proof').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }



    function readURL3(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#selfie_proof').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }

        function readURL5(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#profile_pic').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }

  
    $("#address_submit").click(function(){
        var photo_id_2 = $('#imageUpload1').val();       
        var error_msg = '';
        if($.trim(photo_id_2) == '' || $.trim(photo_id_2) == null){
            $('.photo_id_1_error').html('Provide Address Proof').fadeIn(1000).fadeOut(3000);
            $('#imageUpload1').focus();
            return false;
        }else{
            $("#verification_forms2").submit();
            return true;
        }
    });
    $("#address_cancel").click(function(){
        var photo_id_2 = $('#imageUpload1').val(); 
        var error_msg = '';
        if($.trim(photo_id_2) == '' || $.trim(photo_id_2) == null){
            $('.photo_id_1_error').html('No Address Proof to cancel').fadeIn(1000).fadeOut(3000);
            $('#imageUpload1').focus();
            return false;
        }else{

            $('#imageUpload1').val('');
            $('#address_proof').attr('src', base_url+'assets/front/images/id_proof.png');
            return true;
        }
    });

    $("#id_submit").click(function(){
        var photo_id_3 = $('#imageUpload2').val();       
        var error_msg = '';
        //console.log(isEmpty($.trim(photo_id_3)));
        if($.trim(photo_id_3) == '' || $.trim(photo_id_3) == null){
            $('.photo_id_2_error').html('Provide ID Proof').fadeIn(1000).fadeOut(3000);
            $('#imageUpload2').focus();
            return false;
        }else{
            $("#verification_forms3").submit();
            return true;
        }
    });
    $("#id_cancel").click(function(){
        var photo_id_3 = $('#imageUpload2').val();
        var error_msg = '';
        if($.trim(photo_id_3) == '' || $.trim(photo_id_3) == null){
            $('.photo_id_2_error').html('No ID Proof to cancel').fadeIn(1000).fadeOut(3000);
            $('#imageUpload2').focus();
            return false;
        }else{
            $('#imageUpload2').val('');
            $('#id_proof').attr('src', base_url+'assets/front/images/id_proof.png');
            return true;
        }
    });

     $("#selfie_submit").click(function(){
        var photo_id_3 = $('#imageUpload3').val();       
        var error_msg = '';
        //console.log(isEmpty($.trim(photo_id_3)));
        if($.trim(photo_id_3) == '' || $.trim(photo_id_3) == null){
            $('.photo_id_3_error').html('Provide Selfie Photo').fadeIn(1000).fadeOut(3000);
            $('#imageUpload3').focus();
            return false;
        }else{
            $("#verification_forms4").submit();
           
            return true;
        }
    });
    $("#selfie_cancel").click(function(){
        var photo_id_3 = $('#imageUpload3').val();
        var error_msg = '';
        if($.trim(photo_id_3) == '' || $.trim(photo_id_3) == null){
            $('.photo_id_3_error').html('No Photo to cancel').fadeIn(1000).fadeOut(3000);
            $('#imageUpload3').focus();
            return false;
        }else{
            //$("#verification_forms3").submit();
            $('#imageUpload3').val('');
            $('#selfie_proof').attr('src', base_url+'assets/front/images/settings_user.png');
            return true;
        }
    });

    </script>

      <script type="text/javascript">
      
function delete_customer(id)
{

  var base_url = '<?php echo base_url();?>customer_delete/';


    $.ajax({




        url : base_url+id,
        type: "POST",
        success: function(data)
        {

          console.log(data);
          if(data=='Success')
          {
            window.location.reload();
            toastr.success('xabits! profile Picture deleted successfully');
          }


        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            // alert('Error deleting data');
        }
    });

// }

}
function myFunction() {
  /* Get the text field */
  var copyText = document.getElementById("referralid");

  /* Select the text field */
  copyText.select();
  copyText.setSelectionRange(0, 99999); /* For mobile devices */

  /* Copy the text inside the text field */
  navigator.clipboard.writeText(copyText.value);
  
  /* Alert the copied text */
  toastr.success('xabits! Link Copied');
  // alert("Copied the text: " + copyText.value);
}


    </script>
</body>
</html>