<?php $this->load->view('front/user/login_header');
$user_id = $this->session->userdata('user_id');?>

<style>
    .Neon-input-choose-btn.blue {
    color: #4890fb;
    border: 1px solid #4890fb;
}
.Neon-input-choose-btn {
    display: inline-block;
    padding: 8px 14px;
    outline: none;
    /* cursor: pointer; */
    text-decoration: none;
    text-align: center;
    white-space: nowrap;
    font-size: 12px;
    font-weight: bold;
    /* color: #8d9496; */
    border-radius: 3px;
    /* border: 1px solid #c6c6c6; */
    vertical-align: middle;
    background-color: #fff;
    box-shadow: 0px 1px 5px rgb(0 0 0 / 5%);
    /* -webkit-transition: all 0.2s; */
    -moz-transition: all 0.2s;
    transition: all 0.2s;
}
</style>
<div class="pb-50">
    <div class="container">
        <div class="sec-title text-center">
            <h1 data-watermark="Contact Us"><span>Wallet</span> Request</h1>
           <!--  <p>If any query just contact us</p> -->
        </div>
        <div class="row">
            <div class="col-lg-3 py-3">
            
            </div>
            <div class="col-lg-6 py-3">
                <div class="">
                    <div class="mb-4">
                        <h2 class="fw-bold"><?php echo $contact->english_name;?></h2>
                        <?php echo $contact->english_content;?>
                    </div>

                   <?php
                      $attributes=array('id'=>'contactform',"autocomplete"=>"off","class"=>"deposit_form");
                      $action = front_url() . 'request';
                      echo form_open_multipart($action,$attributes);
                   ?>
                    <div class="">
                      
                                           <div class="form-group mb-3 ">
                                                        <label class="form-label" style="color: black;">Currency</label>
                                                        <div>
                                                        <select class="form-select" name ="currency" id="currency">
                                                          <?php
                                            if(count($currencies)>0)
                                            {
                                                foreach($currencies as $cur)
                                                {
                                        ?>
                                                    <option value="<?php echo $cur->id;?>" <?php
                                                            if(!empty($user_bank))
                                                                if($user_bank->currency==$cur->id) { echo "selected"; } ?>>
                                                        <?php echo $cur->currency_symbol;?>
                                                    </option>
                                        <?php
                                                }
                                            }
                                        ?>
                                                        </select>
                                                        </div>
                                                    </div>

                

                        <div class="form-group mb-3 ">
                            <label class="form-label" style="color: black;">Transaction Id</label>
                            <div>
                           <input type="text" class="form-control" aria-describedby="emailHelp" id="transaction_id" name="transaction_id" placeholder="Transaction Id">

                            </div>
                        </div>

                          <div class="form-group mb-3 ">
                             <?php $usermail = getUserEmail($users->id);?>
                            <label class="form-label" style="color: black;">Your e-mail</label>
                            <div>
                           <input type="text" class="form-control" aria-describedby="emailHelp" id="email" name="email" placeholder="email" value="<?php echo ($usermail)?$usermail:'';?>">

                            </div>
                        </div>


                         <div class="form-group mb-3 ">
                            <label class="form-label" style="color: black;">Request amount</label>
                            <div>
                           <input type="text" class="form-control" aria-describedby="emailHelp" id="amount" name="amount" placeholder="Enter the amount">

                            </div>
                        </div>

                     

                          <div class="form-group mb-3 ">
                            <label class="form-label" style="color: black;">Comment</label>
                            <div>
                           <input type="text" class="form-control" aria-describedby="emailHelp" id="comments" name="comments" placeholder="comments">

                            </div>
                        </div>


                        <div class=""> 
                            <button type="submit" class="Neon-input-choose-btn blue "> 
                               Send
                                
                            </button>
                        </div>
                    </div>
                    <?php
                      echo form_close();
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $this->load->view('front/common/footer');?>
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>

    <script type="text/javascript">
    $(document).ready(function() {

         $.validator.methods.email = function( value, element ) {
            return this.optional( element ) || /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i.test( value );
          }    
        $('#contactform').validate({
        rules: {
            transaction_id: {
                required: true
            },
            email: {
                required: true
            },
            amount: {
                required: true,
                number : true
            }
            // comments: {
            //     required: true
            // }
           
        },
        messages: {
            transaction_id: {
                required: "Please enter transaction id"
            },
            email: {
                required: "Please enter email"
            },
            amount: {
                required: "Please enter numbers"
            }
            // comments: {
            //     required: "Please enter message"
            // }
        },
           submitHandler: function(form) {
                var response = grecaptcha.getResponse(); 
               // console.log(response);

                //recaptcha failed validation
                if (response.length == 0 || response.length=='') {
                    $('#cp_error').css('display','block');
                    $('#cp_error').html('Please Verify here');
                    return false;
                }
                //recaptcha passed validation
                else {
                    $('#cp_error').html('');
                    form.submit();
                }
                //
            }
    });
      });
</script>
<style>
  #contactform label.error {
    /* background: rgba(0, 0, 0, 0) url(images/unchecked.gif) no-repeat scroll 0 0; */
    color: #f00;
    display: inline-block;
    font-family: "Exo 2",sans-serif;
    font-weight: normal;
    position: relative;
        padding-left: 10px;
    /*font-size: 14px;*/
    
    }

  </style>