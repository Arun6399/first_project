<?php
$user_id=$this->session->userdata('user_id');
$sitelan = $this->session->userdata('site_lang');
$usermail = getUserEmail($users->id);
$theme_mode = $_COOKIE['theme-mode'];
$currency = $this->common_model->getTableData('currency',array('status'=>'1','type'=>'digital'),'','','','','','', array('sort_order', 'ASC'))->result();
$favicon = $site_common['site_settings']->site_favicon;
$sitelogo = $site_common['site_settings']->site_logo;
$users = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
 $pairs = $this->common_model->getTableData('trade_pairs',array('status'=>'1'),'','','','','','', array('id', 'ASC'))->result();
$activePage = ucfirst($this->uri->segment(1));
  // echo $activePage;

if($users->verify_level2_status=="" || $users->verify_level2_status=="Pending" || $users->verify_level2_status=="Rejected")
       {
        $kyc_status = ('Not Verified');
        $sym = 'times-circle';
        $sta = 'text-red';
       }
       else
       {
         $kyc_status = ('Verified');
         $sym = 'check-circle';
         $sta = 'text-green';
       }
 if($users->profile_status==1)
                    {
                       $prf_st =('Verified');
                       $sym_p = 'far fa-check-circle'; 
                       $txtp = 'text-green';
                    }
                    else
                    {
                      $prf_st =('Not Verified');
                      $sym_p = 'far fa-times-circle';
                      $txtp = 'text-red'; 
                    }
            ?>
<!DOCTYPE html>
<html>
<head>
   <title>xabits</title>
    <link rel="icon" type="image/png" href="<?php echo $favicon;?>" />
    <meta content="Cripyic" name="keywords">
    <meta content="Cripyic" name="description">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

     <!-- <link rel="stylesheet" href="https://demo.themefisher.com/elaenia/icons/line-awesome/css/line-awesome.min.css"> -->

     <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/line-awesome/1.3.0/line-awesome/css/line-awesome.min.css">




     <link rel="stylesheet" href="<?php echo base_url();?>assets/front/fonts/cryptocoins.css">

    
    <link rel="stylesheet" href="<?php echo front_css();?>waves.min.css">
    <link rel="stylesheet" href="<?php echo front_css();?>toastr.min.css">
    <link rel="stylesheet" href="<?php echo front_css();?>owl.carousel_new.min.css">

     <link rel="stylesheet" href="<?php echo front_css();?>style-new.css">






     
    
        <?php   if($this->session->userdata('site_home')=='home_two') { ?>
    <link rel="stylesheet" href="<?php echo front_css();?>style_home_two.css">
    <?php } else {  ?>
        <link rel="stylesheet" href="<?php echo front_css();?>style_new.css"><?php } ?>

    

<style>

#particles-js{
  width: 100%;
  height: 100%;
  position: fixed;
  background-size: cover;
  background-position: 50% 50%;
  background-repeat: no-repeat;
}

.body-particles{
  position: absolute;
  top: 0;
  left: 0;
  z-index: 100;
}
    </style>

</head>






<body data-offset="80">
<div class="body-particles"></div>

<!-- particles.js container -->
<div id="particles-js"></div>   
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>

    <div  id="main-wrapper">
    <!-- <canvas class="particles-js-canvas-el" width="1351" height="414" style="width: 100%; height: 100%;"></canvas> -->



<header class="header_wrap fixed-top nav-fixed">
    <!-- <div class="container-fluid"> -->
        <!-- <div class="hamburger-menu">
            <input id="menu__toggle" type="checkbox" />
            <label class="menu__btn" for="menu__toggle">
              <span></span>
            </label>

            <ul class="menu__box">
              <li><a class="menu__item" href="<?php echo base_url();?>wallet"><i class="las la-wallet" style="padding: 10px;font-size: 20px;"></i> Wallet</a></li>
              <li><a class="menu__item" href="<?php echo base_url();?>settings"><i class="la la-tools"  style="padding: 10px;font-size: 20px;"></i>Settings</a></li>
              <li><a class="menu__item" href="<?php echo base_url();?>dashboard"><i class="la la-igloo" style="padding: 10px; font-size: 20px;"></i>Dashboard</a></li>
              <li><a class="menu__item" href="<?php echo base_url();?>profile"><i class="la la-user"  style="padding: 10px;font-size: 20px;"></i>Account</a></li>
              <li><a class="menu__item" href="<?php echo base_url();?>history"><i class="la la-history"  style="padding: 10px;font-size: 20px;"></i>History</a></li>
              <li><a class="menu__item" href="<?php echo base_url();?>kyc"><i class="la la-user-check"  style="padding: 10px;font-size: 20px;"></i>KYC Verification</a></li>
              <li><a class="menu__item" href="<?php echo base_url();?>add_coin"><i class="la la-list"  style="padding: 10px;font-size: 20px;"></i>Apply to List</a></li>
              <li><a class="menu__item" href="<?php echo base_url();?>support"><i class="la la-headphones"  style="padding: 10px;font-size: 20px;"></i>Support </a></li>
                <li><a class="menu__item" href="<?php echo base_url();?>logout"><i class="la la-sign-out-alt"  style="padding: 10px;font-size: 20px;"></i>Logout</a></li>


            </ul>
          </div> -->
      <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand page-scroll animation" href="<?=base_url()?>" data-animation="fadeInDown" data-animation-delay="1s">

            <img class="log-img" src="<?=$sitelogo?>" style="width: 70px; margin-left: 75px  " alt="">
               <!-- <a class="navbar-brand" href="<?=base_url()?>">
                                </a> -->
                
              </a>
              <button class="navbar-toggler animation prof" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" data-animation="fadeInDown" data-animation-delay="1.1s">
                  <span><i class="la la-user" aria-hidden="true"> </i></span>
              </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                  <ul class="navbar-nav m-auto">
                      <li class="dropdown animation" data-animation="fadeInDown" data-animation-delay="1.1s">
              <a  class="nav-link" href="<?php echo base_url();?>" style="color: #fff; font-size: 15px;">HOME</a>
              
                      </li>

                      <li class="animation" data-animation="fadeInDown" data-animation-delay="1.2s"><a class="nav-link page-scroll nav_item" href="<?=base_url('cms/about-us')?>" style="color: #fff; font-size: 15px;">ABOUT US</a></li>
                
                      <li class="dropdown animation" data-animation="fadeInDown" data-animation-delay="1.1s">
              <a class="nav-link" href="<?php echo base_url();?>market" style="color: #fff; font-size: 15px;">MARKET</a>
             
                      </li>
                   

                      
                      <li class="dropdown animation" data-animation="fadeInDown" data-animation-delay="1.1s">
              <a class="nav-link logout" href="<?php echo base_url();?>logout" style="color: #fff; font-size: 15px;">LOGOUT</a>
            
                      </li>

                  </ul>
                  <div class="profile_log dropdown">
                    <div class="user" data-toggle="dropdown">
                        <span class="thumb"><i class="la la-user" > </i> </span>
                        <span class="name" ><?php echo $usermail = getUserEmail($users->id);?></span>
                      
                       
                    </div>
                     </div>

                     <div class="profile_log dropdown">
                                     <a  class="la la-power-off" href="<?php echo base_url();?>logout" class="dropdown-item logout" style="color: #fff; font-size: 25px;" >  </a>
                                   </div>
                

        </div>
      </nav>
    <!-- </div> -->
  </header>
</div>




       
  <div class="sidebar">
            <div class="menu">
                <ul>
                    <li>
                        <a href="<?php echo base_url();?>dashboard" data-toggle="tooltip" data-placement="right" title="Dashboard">
                            <span><i class="la la-igloo"></i></span>
                        </a>
                    </li>
                    <li><a href="<?php echo base_url();?>exchange" data-toggle="tooltip" data-placement="right" title="Exchange">
                            <span><i class="la la-exchange-alt"></i></span> 
                        </a>
                    </li>
                    <li><a href="<?php echo base_url();?>profile" data-toggle="tooltip" data-placement="right" title="Account">
                            <span><i class="la la-user"></i></span>
                        </a>
                    </li>
                    <li><a href="<?php echo base_url();?>settings" data-toggle="tooltip" data-placement="right" title="Settings">
                            <span><i class="la la-tools"></i></span>
                        </a>
                    </li>


                    <li><a href="<?php echo base_url();?>wallet" data-toggle="tooltip" data-placement="right" title="wallet">
                            <span><i class="la la-database"></i></span>
                        </a>
                    </li>


                    <li><a href="<?php echo base_url();?>history" data-toggle="tooltip" data-placement="right" title="History">
                            <span><i class="la la-history"></i></span>
                        </a>
                    </li>


                    <li><a href="<?php echo base_url();?>kyc" data-toggle="tooltip" data-placement="right" title=" KYC Verification">
                            <span><i class="la la-user-check"></i></span>
                        </a>
                    </li>

                   


                   <!--  <li><a href="<?php echo base_url();?>add_coin" data-toggle="tooltip" data-placement="right" title="Apply for Listing">
                            <span><i class="la la-list"></i></span>
                        </a>
                    </li> --> 


                 <!--    <li><a href="<?php echo base_url();?>wallet" data-toggle="tooltip" data-placement="right" title="Transaction">
                            <span><i class="la la-money-bill-alt"></i></span>
                        </a>
                    </li> -->


                    <li><a href="<?php echo base_url();?>support" data-toggle="tooltip" data-placement="right" title="Support">
                            <span><i class="la la-headphones"></i></span>
                        </a>
                    </li>
                    <!--  <li><a href="<?php echo base_url();?>referral" data-toggle="tooltip" data-placement="right" title="Referral">
                            <span><i class="la la-user-plus"></i></span> 
                        </a> 
                    </li> -->

                    <li><a href="<?php echo base_url();?>logout" data-toggle="tooltip" data-placement="right" title="Logout">
                            <span><i class="la la-sign-out-alt"></i></span>
                        </a>
                    </li>

                </ul>
            </div>
        </div>
 
        <div class="page_title">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="page_title-content">
                            <!-- <p>Welcome Back, -->
                                <!-- <span> <?php echo ucfirst(($users->xabits_username)?$users->xabits_username:'');?></span> -->
                                <!-- <?php echo $activePage;?> -->
                                <p><span><?php echo ($activePage);?></span></p>
                            <!-- </p> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
