<?php $this->load->view('front/user/login_header'); ?>

<div class="page-body">
        <div class="container-xl">
          <div class="row">
            <!--for demo wrap-->
            <!-- <div class="col-2"></div> -->
            <div class="col-12" style="overflow: auto;margin-bottom: 50px;">
                <div class="col-sm-10 login-box">
                    <div class="row">
                        <div class="col-lg-8 col-md-7 log-det">
                           <h2>Sign in</h2>



                            <div class="text-box-cont">
                                <?php 
                            $action = front_url()."login";
                            $attributes = array('id'=>'loginuserFrom','autocomplete'=>"off",'class'=>'auth_form');
                            echo form_open($action,$attributes);
                            ?>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-user"></i></span>
                                    </div>
                                    <input type="email" class="form-control" placeholder="User Email" aria-label="email" aria-describedby="basic-addon1" name="login_detail">
                                </div>
                                 <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-lock"></i></span>
                                    </div>
                                    <input type="password" class="form-control" placeholder="Password" aria-label="Username" aria-describedby="basic-addon1" id="register_password" name="login_password">
                                </div>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-user-secret "></i></span>
                                    </div>
                                    <input type="text" class="form-control" placeholder="2FA Authentication (If Enabled)" aria-label="Username" aria-describedby="basic-addon1" id="login_tfa" name="login_tfa">
                                </div>
                                <div class="row">
                                    <a href="<?php echo base_url();?>forgot_password"><p class="forget-p" style="color: white;">Forget Password ?</p></a>
                                </div>
                                <div class="input-group center mb-3">
                                    <button type="submit" class="btn btn-success btn-round">SIGN IN</button>
                                    <?php echo form_close(); ?>
                                </div>
                            </div>



                        </div>
                        <div class="col-lg-4 col-md-5 box-de">
                            <div class="ditk-inf">
                                <h2 class="w-100 text-white">Don't Have any Account </h2>
                                <p class="text-white">Simply Create your account by clicking the Signup Button</p>
                                <a href="<?php echo base_url();?>signup">
                                <button type="button" id="submit_btn" class="btn btn-outline-light">SIGN UP</button>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

        </div>
        </div>
        </div>
        </div>

        <?php $this->load->view('front/common/footer'); ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.js"></script>
                <script type="text/javascript">
        var base_url='<?php echo base_url();?>';
        var front_url='<?php echo front_url();?>';
        var user_id='<?php echo $user_id;?>';
        var ip_address = '<?php echo $ip_address;?>';
        var get_os = '<?php echo $get_os;?>';

        var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';

        var success = "<?php echo $this->session->flashdata('success')?>";
        var error = "<?php echo $this->session->flashdata('error')?>";
        $(document).ready(function() {
        $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
        if (options.type.toLowerCase() == 'post') {
        options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
        if (options.data.charAt(0) == '&') {
        options.data = options.data.substr(1);
        }
        }
        });

        $( document ).ajaxComplete(function( event, xhr, settings ) {
        if (settings.type.toLowerCase() == 'post') {
        $.ajax({
        url: front_url+"get_csrf_token",
        type: "GET",
        cache: false,
        processData: false,
        success: function(data) {

        $("input[name="+csrfName+"]").val(data);
        }
        });
        }
        });

        });
        $.validator.addMethod("emailcheck", function(value) {
        return (/^\w+([.-]?\w+)@\w+([.-]?\w+)(.\w{2,3})+$/.test(value));
        },"Please enter valid email address");
        $('#loginuserFrom').validate({
        errorClass: 'invalid-feedback',
        rules: {
        login_detail: {
        required: true,
        email:true,
        emailcheck: true,
        },
        login_password: {
        required: true
        },
        login_tfa: {
        number: true,
        minlength: 6
        }
        },
        messages: {
        login_detail: {
        required: "Please enter email",
        email: "Please enter valid email address",
        emailcheck: "Please enter valid email address",
        },
        login_password: {
        required: "Please enter password"
        },
        login_tfa: {
        number: "Please enter valid tfa code",
        minlength:"Enter 6 digit valid tfa code"
        }
        },
        invalidHandler: function(form, validator) {
        if (!validator.numberOfInvalids())
        {
        return;
        }
        else
        {
        var error_element=validator.errorList[0].element;
        error_element.focus();
        }
        },
        highlight: function (element) {
        //$(element).parent().addClass('error')
        },
        unhighlight: function (element) {
        $(element).parent().removeClass('error')
        },
        submitHandler: function(form)
        {
        $('#submit_btn').prop('disabled');
        $('.spinner-border').css('display','inline-block');

        var $form = $(form);
        $.ajax({
        url: front_url+"login_check",
        type: "POST",
        data: $form.serialize(),
        cache: false,
        processData: false,
        success: function(data)
        {
            console.log(data);
        var d = jQuery.parseJSON(data);
        if(d.status==0)
        {
        //toastr.error(d.msg);
         toastr.error(d.msg);
        $('#submit_btn').prop('enabled');
        $('.spinner-border').css('display','none');
        }
        else
        {
        if(d.tfa_status==1)
        {
        $('#submit_btn').prop('enabled');
        $('.spinner-border').css('display','none');
        }
        else
        {
        if(d.login_url=='wallet')
        {
        window.location.href = front_url+"wallet";
        }
        else
        {
        window.location.href = front_url+"wallet";
        }
        }
        toastr.info(d.msg);

        }
        }
        });
        return false;
        // }
        }
        });
        </script>