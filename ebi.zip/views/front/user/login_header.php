<!doctype html>
<html lang="en">
  <head>
    <title>Xabits - The Best Crypto Trading Platform</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- carousel CSS -->
    <link rel="stylesheet" href="<?php echo front_css();?>owl.carousel.min.css">
    <!--header Exchangen CSS -->
    <link rel="Exchangen" href="<?php echo front_css();?>fabExchangen.png">
    <!-- animations CSS -->
    <link rel="stylesheet" href="<?php echo front_css();?>animate.min.css">
    <!-- font-awsome CSS -->
    <link rel="stylesheet" href="<?php echo front_css();?>font-awesome.min.css">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/line-awesome/1.3.0/line-awesome/css/line-awesome.min.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo front_css();?>bootstrap.min.css">
    <!-- mobile menu CSS -->
    <link rel="stylesheet" href="<?php echo front_css();?>slicknav.min.css">
    <!--css animation-->
    <link rel="stylesheet" href="<?php echo front_css();?>animation.css">


    <!--css animation-->
    <!-- <link rel="stylesheet" href="<?php echo front_css();?>material-design-Exchangenic-font.min.css"> -->
    <!-- style CSS -->
    <link rel="stylesheet" href="<?php echo front_css();?>style.css">
    <!-- responsive CSS -->
    <link rel="stylesheet" href="<?php echo front_css();?>responsive.css">
    <link rel="stylesheet" href="<?php echo front_css();?>cryptocoins.css">
    <link href="<?php echo front_css();?>tabler.min.css" rel="stylesheet"/>
    <link href="<?php echo front_css();?>tabler-flags.min.css" rel="stylesheet"/>
    <link href="<?php echo front_css();?>tabler-payments.min.css" rel="stylesheet"/>
    <link href="<?php echo front_css();?>tabler-vendors.min.css" rel="stylesheet"/>
    <link href="<?php echo front_css();?>demo.min.css" rel="stylesheet"/>
    <link href="<?php echo front_css();?>login.css" rel="stylesheet"/>
     <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>toastr.min.css" />
   </head>
  <body>
    <!--header area start-->
    <div class="header-area wow fadeInDown header-absolate" id="nav" data-0="position:fixed;" data-top-top="position:fixed;top:0;" data-edge-strategy="set">
        <div class="container">
            <div class="row">
                <div class="col-4 d-block d-lg-none">
                    <div class="mobile-menu"></div>
                </div>
                <div class="col-4 col-lg-2">
                    <div class="logo-area">
                        <a href="<?php echo base_url();?>home"><img src="<?php echo front_img();?>logo-top.png" alt=""></a>
                    </div>
                </div>
                <div class="col-4 col-lg-10 d-none d-lg-block" style="padding: 10px;">
                    <div class="main-menu text-center">
                        <nav>
                            <ul id="slick-nav">
                              
                                <li><a class="scroll" href="<?php echo base_url();?>market">Market</a> </li>
                                <li><a class="scroll" href="<?php base_url()?>exchange/#/">Exchange</a></li>
                                <li><a class="scroll" href="<?php echo base_url();?>support">Support</a></li>
                               <?php
                               $user_id = $this->session->userdata('user_id');
                                if(isset($user_id) && !empty($user_id)){
                                ?>
                                
                                      <li> <a href="<?php echo base_url();?>profile" class="logibtn gradient-btn">Profile</a></li>
                                       <li> <a href="<?php echo base_url();?>wallet" class="logibtn gradient-btn">Wallet</a></li>
                                     <li> <a href="<?php echo base_url();?>logout" class="logibtn gradient-btn">Logout</a></li>
                                   
                                <?php } else { ?>

                                 <li> <a href="<?php echo base_url();?>login" class="logibtn gradient-btn">login</a></li>
                                     <li> <a href="<?php echo base_url();?>signup" class="logibtn gradient-btn">Get Started</a></li>

                             <?php } ?>
                                
                               
                             
                            </ul>
                          
                        </nav>
                    </div>
                   
                </div>
             

            </div>
        </div>
    </div>