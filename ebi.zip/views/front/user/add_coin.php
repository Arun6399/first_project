<?php 
    $this->load->view('front/user/login_header');
    ?>
    <style type="text/css">
    .file-upload-wrapper:before {

content: "Upload";

}

</style>
 <div class="content-body">
            <div class="container-fluid">
                <div class="row">
                   
                    <div class="col-xl-12 col-md-12">
                        <div class="row">

                            <div class="col-xl-12">
                                <div class="card">
                                    
                                    <div class="card-body" style="z-index: 0">

                <div class="dashboard-section">
                    <?php $attributes=array('id'=>'contact_forms','autocomplete'=>'off');echo form_open_multipart($action,$attributes); ?>
                    <div class="dashboard-box">
                        <div class="dashboard-box-inner pb-0">
                            <h2 class="ticket-head text-center">Select Asset Type</h2>


                            
                            <div class="profile-details">
                                

                                <div class="profile-flex jus-start pad-l-15">
                                <div class="col-12 col-md-12 col-lg-12 col-xl-12">
                                    <div class="row">
                                        <div class="col-12 col-md-12">
                                            <div class="row justify-content-center">

                                                <div class="asset-type">
                                                    <div class="custom-control custom-radio custom-control-inline">
                                                        <input type="radio" id="customRadioInline1" name="coin_type" class="custom-control-input" value="1" checked="">
                                                        <label class="custom-control-label" for="customRadioInline1">COIN</label>
                                                    </div>
                                                    <div class="custom-control custom-radio custom-control-inline">
                                                        <input type="radio" id="customRadioInline2" name="coin_type" class="custom-control-input" value="0">
                                                        <label class="custom-control-label" for="customRadioInline2">TOKEN</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                    <div class="form-row ml-auto mx-auto form-bor   mt-5">
                                        <div class="form-group col-md-6 form-pad-30">
                                            <label for="coin_name">Full Name of your crypto</label>
                                            <input type="text" class="form-control" id="coin_name" name="coin_name" placeholder="ex - Bitcoin, Ethereum">
                                        </div>
                                        <div class="col-12 col-md-6 form-pad-30 form-group">
                                            <label for="priority">Listing Priority</label>
                                            <div class="input-group input-group-sm mb-3">
                                                <select class="form-control" name="priority" id="priority">
                                        <option value="High_<?php echo $prioritys->high_cost?>_<?php echo $prioritys->high_time?>">High(Cost)</option>
                                        <option value="Standard_<?php echo $prioritys->standard_cost?>_<?php echo $prioritys->standard_time?>">Standard (Cost)</option>
                                        <option value="Low_<?php echo $prioritys->low_cost?>_<?php echo $prioritys->low_time?>">Low(Cost)</option>
                                        
                                      </select>
                                            </div>
                                            <p style="font-size: 12px;color: #2196f3;"><span id="priorityH">High </span> Fees:<span id="fees"> <?=$prioritys->high_cost?></span><span id="cointext"> BTC</span>. Time : <span id="days"><?=$prioritys->high_time?></span> Days.</p>
                                        </div>
                                    </div>
                                    <div class="form-row ml-auto mx-auto form-bor">
                                        <div class="form-group col-md-6 form-pad-30">
                                            <label for="coin_symbol">Official Crypto Ticker</label>
                                            <input type="text" class="form-control" id="coin_symbol" name="coin_symbol" placeholder="ex - BTC, ETH, LTC">
                                        </div>
                                        <div class="form-group col-md-6 form-pad-30">
                                            <label for="inputEmail4">Logo of Coin (Transparent PNG 250 *250PX)</label>

                                            

                                             <div class="file-upload-wrapper" data-text="Change Picture">
                                                        <input name="coin_logo" type="file"  class="file-upload-field" id="coin_logo">
                                                    </div>

                                        </div>
                                    </div>
                                
                                <div class="form-row ml-auto mx-auto form-bor">
                                    <div class="form-group col-md-6 form-pad-30">
                                        <label for="max_supply">Maximum Supply</label>
                                        <input type="number" class="form-control" id="max_supply" name="max_supply" placeholder="">
                                    </div>
                                    <div class="form-group col-md-6 form-pad-30">
                                        <label for="crypto_type">Which Blockchain in your crypto based on</label>
                                        <input type="text" class="form-control" id="crypto_type" name="crypto_type" placeholder="ex - ETH, BTC..">
                                    </div>
                                </div>

                                <div class="form-row ml-auto mx-auto form-bor">
                                    <div class="form-group col-md-6 form-pad-30">
                                        <label for="max_supply">Initial Price</label>
                                        <input type="number" class="form-control" id="coin_price" name="coin_price" placeholder="">
                                    </div>
                                    
                                </div>



                            </div>
                        </div>
                    </div>
                    <div class="dashboard-box">
                        <div class="dashboard-box-inner pb-0">
                            <h2 class="ticket-head text-center">COMMUNITY</h2>
                            <div class="profile-details">
                                
                                    <div class="form-row ml-auto mx-auto form-bor">
                                        <div class="form-group col-md-6 form-pad-30">
                                            <label for="marketcap_link">Coin Market Caplink</label>
                                            <input type="text" class="form-control" id="marketcap_link" name="marketcap_link" placeholder="">
                                        </div>
                                        <div class="form-group col-md-6 form-pad-30">
                                            <label for="username">Contact Username</label>
                                            <input type="text" class="form-control" id="username" name="username" placeholder="">
                                        </div>
                                    </div>
                                    <div class="form-row ml-auto mx-auto form-bor">
                                        <div class="form-group col-md-6 form-pad-30">
                                            <label for="inputEmail4">Coin Link</label>
                                            <input type="text" class="form-control" id="coin_link" name="coin_link" placeholder="">
                                        </div>
                                        <div class="form-group col-md-6 form-pad-30">
                                            <label for="email">Email address</label>
                                            <input type="email" class="form-control" id="email" name="email" placeholder="">
                                        </div>
                                    </div>
                                    <div class="form-row ml-auto mx-auto form-bor">
                                        <div class="form-group col-md-6 form-pad-30">
                                            <label for="twitter_link">Official Twitter Link</label>
                                            <input type="text" class="form-control" id="twitter_link" name="twitter_link" placeholder="">
                                        </div>
                                        <div class="form-group col-md-6 form-pad-30">
                                            <p class="asset-type-content">Do not need any funds to any address unless you receive mail from our team.</p>

                                        </div>

                                    </div>


                                    <div class="form-btn">
                                        <button class="btn btn-success btn-sm" type="submit">SUBMIT REQUEST</button>
                                    </div>

                                
                            </div>
                        </div>
                    </div>
<?php echo form_close();?>
                </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


         <?php 
    $this->load->view('front/common/login_footer');
    ?>
    <?php

    $user_id    = $this->session->userdata('user_id');
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $get_os     = $_SERVER['HTTP_USER_AGENT'];
?>

    <script type="text/javascript">

    var base_url='<?php echo base_url();?>';
    var front_url='<?php echo front_url();?>';
    var user_id='<?php echo $user_id;?>';
    var ip_address = '<?php echo $ip_address;?>';
    var get_os     = '<?php echo $get_os;?>';

    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';


    $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
        if (options.type.toLowerCase() == 'post') {
            options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
            if (options.data.charAt(0) == '&') {
                options.data = options.data.substr(1);
            }
        }
    });

    $( document ).ajaxComplete(function( event, xhr, settings ) {
        if (settings.type.toLowerCase() == 'post') {
            $.ajax({
                url: front_url+"get_csrf_token", 
                type: "GET",
                cache: false,             
                processData: false,      
                success: function(data) {

                     $("input[name="+csrfName+"]").val(data);
                }
            });
        }
    });

  $.validator.addMethod("emailcheck", function(value) {
        return (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(value));
    },"<?php echo $this->lang->line('Please enter valid email address');?>"); 

jQuery.validator.addMethod("accept", function(value, element, param) {
  return value.match(new RegExp("." + param + "$"));
});
    
         $('#contact_forms').validate({
        rules: {
            coin_type: {
                required: true
            },
            coin_name: {
                required: true,
                 accept: "[a-zA-Z]+" 
            },
            coin_symbol: {
                required: true
            },
            max_supply: {
                required: true,
                number:true
            },
            coin_price: {
                required: true,
                number:true
            },
            priority: {
                required: true
            },
            username: {
                required: true,
                accept: "[a-zA-Z]+" 
            },
            email: {
                required: true,
                email: true,
                 emailcheck: true
            }
           
        },
        messages: {
            coin_type: {
                required: "<?php echo $this->lang->line('Please choose coin type');?>"
            },
            coin_name: {
                required: "<?php echo $this->lang->line('Please enter coin name');?>",
                 accept : "<?php echo $this->lang->line('Only strings allowed');?>"
            },
            coin_symbol: {
                required: "<?php echo $this->lang->line('Please enter coin symbol');?>"
            },
            max_supply: {
                required: "<?php echo $this->lang->line('Please enter maximum supply');?>",
                 number:'<?php echo $this->lang->line('Should enter only number');?>'

            },
            coin_price: {
                required: "<?php echo $this->lang->line('Please enter coin price');?>",
                number:'<?php echo $this->lang->line('Should enter only number');?>'
            },
            priority: {
                required: "<?php echo $this->lang->line('Please choose priority');?>"
            },
            username: {
                required: "<?php echo $this->lang->line('Please enter username');?>",
                accept : "<?php echo $this->lang->line('Only strings allowed');?>"
            },
            email: {
                required: "<?php echo $this->lang->line('Please enter email');?>",
                email: "<?php echo $this->lang->line('Please enter valid email address');?>",
                 emailcheck:'<?php echo $this->lang->line('Invalid Format Email');?>'
            }            
        },
    });

         $("#coin_symbol").keyup(function(){
            var symbol_pri = $(this).val();
            $("#cointext").html(" "+symbol_pri);
         });

         $("#priority").change(function(){
                var prio_name = $(this).val(); //alert(prio_name);
                var coin = $("#coin_symbol").val();
                if(coin!='') { coin = coin } else {  coin = ' BTC';}
                var prios = prio_name.split("_");
                var seltxt = prios[0];
                var pfees = prios[1];
                var pdays = prios[2];
                $("#priorityH").html(seltxt);
                $("#fees").html(pfees);
                $("#days").html(pdays);
                $("#cointext").html(" "+coin);


         });
    </script>