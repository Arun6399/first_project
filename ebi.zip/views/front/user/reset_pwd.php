<?php $this->load->view('front/user/login_header.php');?>
<div class="token-info-sec">
    <div class="container">
        <div class="sec-title text-center">
        <h1 data-watermark="Reset Password">
                <span>Reset</span> Password
            </h1>
            <!-- <p>Forgot Password</p> -->
        </div>
        <div class="row">
        <div class="col-lg-3"></div>
            <div class="col-lg-6">
                <?php 
                    $action1 ='';$attributes=array('id'=>'reset_pw_user'); 
                    echo form_open($action1,$attributes);
                ?>

                <div class="single-input-box box-1">
                        <input type="password" class="form-control" placeholder="Enter Password" id="reset_password" name="reset_password">
                        <!-- <span class="input-icon">
                            <i class="icofont-ui-user"></i>
                        </span> -->
                    </div>
                    <label id="reset_password" class="error1" for="reset_password" style="color: #ec1111;position: inherit !important;"></label>
                    <div class="single-input-box box-1">
                        <input type="password" class="form-control" placeholder="Confirm Password" id="reset_cpassword" name="reset_cpassword">
                        
                    </div>
                    <label style="color: #ec1111;position: inherit !important;" id="reset_cpassword-error" class="error1" for="reset_cpassword"></label>
                    <br>
                    <button id="submit_btn" class="btn btn-success btn-round" type="submit">Request</button>
               <?php echo form_close();?>

               </div>
            <div class="col-lg-3"></div>
        </div>
    </div>
</div>


<?php
 $this->load->view('front/common/footer.php');
?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.js"></script>
<script type="text/javascript">
        var base_url='<?php echo base_url();?>';
    var front_url='<?php echo front_url();?>';
    var user_id='<?php echo $user_id;?>';
    var ip_address = '<?php echo $ip_address;?>';
    var get_os     = '<?php echo $get_os;?>';

    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';

     var success = "<?php echo $this->session->flashdata('success')?>";
    var error = "<?php echo $this->session->flashdata('error')?>";
  
        if(success!=''){
$.growl.notice({title: "Cripyicexchange", message: success });
//alert(success);
}
if(error!=''){
$.growl.error({title: "Cripyicexchange", message: error });
}


    $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
        if (options.type.toLowerCase() == 'post') {
            options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
            if (options.data.charAt(0) == '&') {
                options.data = options.data.substr(1);
            }
        }
    });

    $( document ).ajaxComplete(function( event, xhr, settings ) {
        if (settings.type.toLowerCase() == 'post') {
            $.ajax({
                url: front_url+"get_csrf_token", 
                type: "GET",
                cache: false,             
                processData: false,      
                success: function(data) {

                     $("input[name="+csrfName+"]").val(data);
                }
            });
        }
    });

    jQuery.validator.addMethod("alphanumeric", function(value, element) {
        return this.optional(element) || /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[A-Za-z\d@$!%*#?&^_-]{8,}$/.test(value);
});

    $.validator.addMethod("emailcheck", function(value) {
        return (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(value));
    },"Please enter valid email address"); 
    
    $.validator.addMethod("emailcheck", function(value) {
        return (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(value));
    },"Please enter valid email address"); 

      $('#reset_pw_user').validate({
    rules: {
      reset_password: {
        required: true,
        minlength: 8,
        alphanumeric : true
      },
      reset_cpassword: {
        required: true,
        equalTo : "#reset_password"
      }
    },
    messages: {
      reset_password: {
        required: "Please enter password",
        minlength: "Minimum 8 characters",
        alphanumeric : "Minimum 8 characters, including UPPER / lower case with numbers & special characters"

      },
      reset_cpassword: {
        required: "Please enter Confirm Password",
        equalTo : "Please enter same password"
      }
    } 
});
    </script>

</body>

</html>

