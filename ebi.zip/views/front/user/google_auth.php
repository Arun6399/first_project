<?php $this->load->view('front/user/login_header'); 
$user_id = $this->session->userdata('user_id');
     $all_currency = $this->common_model->getTableData("currency",array("status"=>1))->result();
      if(count($all_currency))
      {
        $tot_balance = 0;
        foreach($all_currency as $cur)
        {
            $balance = getBalance($user_id,$cur->id);
            $usd_balance = $balance * $cur->online_usdprice;

            $tot_balance += $usd_balance;
        }
      }
?>

<div class="navbar-expand-md" style="margin-top: 100px;">
       
      </div>
      <div class="page-body">
        <div class="container-xl">
          <div class="row row-deck row-cards">

          <div class="col-12">
            <div class="card-trans">
                <div class="card-body py-3">
                  <div class="row">
                    <div class="col-12 col-lg-12">
                      <div class="heading">
                       <h2 style="text-transform: none;">Enable Google 2FA</h2>
                    </div>
                    </div>


                  </div>
                  <hr>

				

					<div class="space-40"></div>
					<div class="row">
						<div class="col-12 col-lg-12 d-flex" >

							<h4 >Scan QR code or enter secret key to link your Google Authenticator to Xabits account.
							</h4>
						</div>
						<div class="space-20"></div>
<div class="col-12 col-md-6 text-center">
                                            <label class="text-capitalize">Scan QR Code In Google Authenticator</label>
                                            <img src="<?php echo $url;?>" class="img-thumbnail" width="100">
                                            <div class="manual-verify">
                                                <p>Or Type The Key Manually</p>
                                                <p><span id="authenticator_key"><?php echo $secret;?></span> <span class="fs-18" style="cursor:pointer;"><i class="far fa-copy" onclick="copyToClipboard('<?php echo $secret;?>')"></i></span></p>
                                            </div>
                                        </div>
							<div class="col-12 col-lg-6" ></div>



					  </div>
					  <div class="space-40"></div>
					<div class="row">
						<div class="col-12 col-lg-12 d-flex" >

							<h4 >3.Enter the 6-digit verification code on your Google Authenticator

							</h4>
						</div>
						<div class="space-20"></div>
						<div class="row">
							<?php 
                              $attributes1=array('id'=>'security_new','class'=>'deposit_form');
                              $action1=base_url().'security_new';
                              echo form_open($action1,$attributes1); 
                              if($users->randcode=='' || $users->randcode=='disable')
                              {
                                $btn_content = $this->lang->line('ENABLE');
                              }
                               else{
                                $btn_content = $this->lang->line('DISABLE');
                              }                                     
                            ?>
                            <input type="hidden" name="latincoin" value="253d521c8b2a4fe7d17412ac5a8b0e1c"> 
							<div class="col-12 col-lg-4" >
						<!-- <input type="password" class="form-control" aria-describedby="emailHelp" placeholder=""> -->


                             <input type="text" class="form-control" id="code" name="code" placeholder="Verification Code">
                               <input type="hidden"  name="secret" id="secret" value="<?php echo $secret;?>">
						<div class="space-20"></div>
						 <button><a  class="logibtn gradient-btn" id="authenticator_key" type="submit"><?php echo $btn_content;?></a></button>
						 <?php echo form_close(); ?>
						</div>
						<div class="col-12 col-lg-8" ></div>

					  </div>


				  <div class="space-40"></div>
              </div>
              </div>

            </div>
          </div>
        </div>
      </div>

      <?php $this->load->view('front/common/footer'); ?>

<script type="text/javascript">
	
var base_url='<?php echo base_url();?>';
    var front_url='<?php echo front_url();?>';
    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';

    $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
        if (options.type.toLowerCase() == 'post') {
            options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
            if (options.data.charAt(0) == '&') {
                options.data = options.data.substr(1);
            }
        }
    });

    $( document ).ajaxComplete(function( event, xhr, settings ) {
        if (settings.type.toLowerCase() == 'post') {
            $.ajax({
                url: front_url+"get_csrf_token", 
                type: "GET",
                cache: false,             
                processData: false,      
                success: function(data) {

                     $("input[name="+csrfName+"]").val(data);
                }
            });
        }
    });


	$('#security_new').validate({
        rules: {
            code: {
                required: true,
                number: true,
                minlength: 6
            }
        },
        messages: {
            code: {
                required: 'Please enter code',
                number: 'Please enter valid code',
                minlength:'Please 6 digit valid code'
            }
        }
    });

	function copyToClipboard(text) {
    var copyText = document.getElementById("authenticator_key");  
    var input = document.createElement("textarea");
    input.value = copyText.textContent;
    document.body.appendChild(input);
    input.select();
    document.execCommand("Copy");
    input.remove();
}
</script>