<?php $this->load->view('front/user/login_header'); ?>
      <div class="navbar-expand-md">
        <div id="navbar-menu">
          <div class="navbar navbar-expand-md navbar-light sticky-top d-print-none">
            <div class="container-xl" style="display: block;">
              <ul class="navbar-nav">
                <li class="nav-item active"> <a class="nav-link" href="<?php echo base_url();?>account" ><span class="nav-link-title"> Account </span> </a> </li>
                <li class="nav-item"> <a class="nav-link" href="<?php echo base_url();?>wallet" ><span class="nav-link-title"> Assets </span> </a> </li>
                <li class="nav-item"> <a class="nav-link" href="<?php echo base_url();?>history" > <span class="nav-link-title"> Fund History </span> </a> </li>
                <!-- <li class="nav-item "> <a class="nav-link" href="trade.html" > <span class="nav-link-title"> Trade History </span> </a> </li> -->
              </ul>

            </div>
          </div>
        </div>
      </div>
      <div class="page-body">
        <div class="container-xl">
          <div class="row row-deck row-cards">

          <div class="col-12">
            <div class="card-trans">
                <div class="card-body py-3">
                  <div class="row">
                    <div class="col-12 col-lg-8">
                      <div class="heading">
                       <h2 style="text-transform: none;color: black;"><?php echo getUserEmail($users->id); ?></h2>
					   <p>Previous login: Device / WEB | Time 2021-10-28 12:49:53 | IP / 2401:4900:5301:7e93:ac0c:9f0f:e549:64f9 </p>
                    </div>
                    </div>
                    <div class="col-12 col-lg-4">
                      <div class="heading">
                        <p></p>
                        <p style="text-align: right; vertical-align: middle;color:#4890fb"> <a href="<?php echo base_url();?>settings">Change Password</a></p>

                      </div>
                    </div>

                  </div>
                  <hr>
				  <div class="heading">
					<h3 style="text-transform: none;color: black;">Security Settings</h3>
				 </div>
				 <hr>
				 <!-- <div class="row">
                    <div class="col-12 col-lg-1">
                      <div class="heading">
						<img src="<?php echo front_img();?>mail.png" style="width:60px">
                    </div>
                    </div>
                    <div class="col-12 col-lg-6">
                      <div class="heading">
                        <h4 style="color:black">Email Verification</h4>
                        <p>Applied to signing in, withdrawing, resetting password and other activities involved in account security.</p>

                      </div>
                    </div>
					<div class="col-12 col-lg-5">
						<div class="heading">

						  <p style="text-align: right;padding-top:30px;color: black;"> <span style="padding-right: 34px;"><?php echo getUserEmail($users->id); ?></span><a href="<?php echo base_url();?>reset_pwd" style="color: #4890fb;">Change</a></p>

						</div>
					  </div>


                  </div> -->
				
				  

				  <div class="space-40"></div>

				   <div class="row">
                    <div class="col-12 col-lg-1">
                      <div class="heading">
						<img src="<?php echo front_img();?>google-03.png" style="width:60px">
                    </div>
                    </div>
                    <div class="col-12 col-lg-6">
                      <div class="heading">
                        <h4 style="color: black;">Google Authenticator</h4>
                        <p >It is strongly recommended to enable Google Authenticator to protect your account.</p>

                      </div>
                    </div>
					<div class="col-12 col-lg-5">
						<div class="heading">

								<?php 
                                           
                                            if($users->randcode=='' || $users->randcode=='disable')
                                            {
                                              $btn_content = $this->lang->line('ENABLE');
                                            }
                                             else{
                                              $btn_content = $this->lang->line('DISABLE');
                                            }                                     
                                          ?>


						  <p style="text-align: right;padding-top:30px"><a href="<?php echo base_url();?>settings_new" class="logibtn gradient-btn"><?php echo $btn_content;?></a></p>

						</div>
					  </div>


                  </div>
				  <div class="space-40"></div>
				  <div class="row">
                    <div class="col-12 col-lg-1">
                      <div class="heading">
						<img src="<?php echo front_img();?>check.png" style="width:60px">
                    </div>
                    </div>
                    <div class="col-12 col-lg-6">
                      <div class="heading">
                        <h4 style="color: black;">KYC</h4>
                        <p >Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum.</p>

                      </div>
                    </div>
					<div class="col-12 col-lg-5">
						<div class="heading">

						  <p style="text-align: right;padding-top:30px"><a href="<?php echo base_url();?>kyc_new" class="logibtn gradient-btn">Set Up</a></p>

						</div>
					  </div>
                  </div>




              </div>
              </div>



            </div>
			<div class="heading">
				<h3 style="text-transform: none;color: black;">Device Logs</h3>
			 </div>
			 <hr>
			 <div class="row">
				<div class="col-12">
					<div class="card"  style="border: none !important;">
					
						<!-- <div class="card-body py-3">
										   <div class="tab-content">
							 

							  <div class="tab-pane show active" id="usd">
								<table class="table card-table table-vcenter text-nowrap datatable">
									<thead>
									  <tr>
										<th class="tabhead">Device name 
										</th>
										<th>Authorization Time</th>
										<th>Location</th>
										<th>IP Address</th>
										<th>Action</th>
									</tr>
									</thead>
									<tbody>
										<tr>
											<td>Chrome 9 V95.0.4638.54 (Windows 10)</td>
											<td>2021-10-24 15:14:16</td>
											<td>Noida, India</td>
											<td>2401:4900:5303:24c1:4475:281c:ad65:5ccb</td>
											<td><a href="#" class="gradient-btn trade" style="border: none;padding: 0px; text-transform: none;">Delete</a></td>


										  </tr>

									</tbody>
								  </table>                      </div>


							  <div class="tab-pane" id="BTC">
								<table class="table card-table table-vcenter text-nowrap datatable">
									<thead>
									  <tr>
										<th class="tabhead">Name 
										</th>
										<th>Price USDT</th>
										<th>USD Price</th>
										<th>24H Change</th>
										<th>24H High</th>
										<th>24H Low</th>
										<th>Volume</th>
										<th>Market</th>
										<th></th>
									  </tr>
									</thead>
									<tbody>
									  <tr>
										<td><img src="https://res.cloudinary.com/akilexchange/image/upload/v1626767394/uploads/currency/uyluzslruxbuftrbgghe.png" alt="" class="table-cryp"> BTC/USD</td>
										<td>55086.94 / 0$</td>
										<td>$3655.23</td>
										<td><span class="grn">1.00%</span></td>
										<td>55113.9</td>
										<td>53392.38</td>
										<td>1131.71614</td>
										<td>
											</td>

											  <td><a href="#" class="gradient-btn trade">Trade</a></td>

									  </tr>

									  <tr>
										<td><img src="https://res.cloudinary.com/dhpmwq4ln/image/upload/v1630925914/uploads/currency/vgizf7dvft1jaxkf5mia.png" width="11%" alt="" class="table-cryp"> ETH/BTC</td>
										<td>0.065596 / 0$</td>
										<td>$856</td>
									  <td><span class="rdn">-0.74%</span></td>
									  <td>0.06723</td>
									  <td>0.065467</td>
									  <td>89181.8069</td>
									  <td>
										</td>

									  <td><a href="#" class="gradient-btn trade">Trade</a></td>
									  </tr>
									  <tr>
										<td><img src="https://res.cloudinary.com/akilexchange/image/upload/v1626767356/uploads/currency/vouwkkkx1v49x1o6xcs7.png" alt="" class="table-cryp"> LTC/BTC</td>
										<td>0.003271 / 0$</td>
										<td>$63</td>
										<td><span class="rdn">-3.60%</span></td>
										<td>0.003433</td>
										<td>0.003259</td>
										<td>158479.189</td>
										<td>
										  </td>

										<td><a href="#" class="gradient-btn trade">Trade</a></td>
									  </tr>


									</tbody>
								  </table>                      </div>
							  <div class="tab-pane" id="eth">
								<table class="table card-table table-vcenter text-nowrap datatable">
									<thead>
									  <tr>
										<th class="tabhead">Name 
										</th>
										<th>Price USDT</th>
										<th>USD Price</th>
										<th>24H Change</th>
										<th>24H High</th>
										<th>24H Low</th>
										<th>Volume</th>
										<th>Market</th>
										<th></th>
									  </tr>
									</thead>
									<tbody>
									  <tr>
										<td><img src="https://res.cloudinary.com/akilexchange/image/upload/v1626767394/uploads/currency/uyluzslruxbuftrbgghe.png" alt="" class="table-cryp"> BTC/USD</td>
										<td>55086.94 / 0$</td>
										<td>$3655.23</td>
										<td><span class="grn">1.00%</span></td>
										<td>55113.9</td>
										<td>53392.38</td>
										<td>1131.71614</td>
										<td>
											</td>

											  <td><a href="#" class="gradient-btn trade">Trade</a></td>

									  </tr>

									  <tr>
										<td><img src="https://res.cloudinary.com/dhpmwq4ln/image/upload/v1630925914/uploads/currency/vgizf7dvft1jaxkf5mia.png" width="11%" alt="" class="table-cryp"> ETH/BTC</td>
										<td>0.065596 / 0$</td>
										<td>$856</td>
									  <td><span class="rdn">-0.74%</span></td>
									  <td>0.06723</td>
									  <td>0.065467</td>
									  <td>89181.8069</td>
									  <td>
										</td>

									  <td><a href="#" class="gradient-btn trade">Trade</a></td>
									  </tr>


									</tbody>
								  </table>                      </div>
							  <div class="tab-pane" id="ltc">
								<table class="table card-table table-vcenter text-nowrap datatable">
									<thead>
									  <tr>
										<th class="tabhead">Name 
										</th>
										<th>Price USDT</th>
										<th>USD Price</th>
										<th>24H Change</th>
										<th>24H High</th>
										<th>24H Low</th>
										<th>Volume</th>
										<th>Market</th>
										<th></th>
									  </tr>
									</thead>
									<tbody>
									  <tr>
										<td><img src="https://res.cloudinary.com/akilexchange/image/upload/v1626767394/uploads/currency/uyluzslruxbuftrbgghe.png" alt="" class="table-cryp"> BTC/USD</td>
										<td>55086.94 / 0$</td>
										<td>$3655.23</td>
										<td><span class="grn">1.00%</span></td>
										<td>55113.9</td>
										<td>53392.38</td>
										<td>1131.71614</td>
										<td>
											</td>

											  <td><a href="#" class="gradient-btn trade">Trade</a></td>

									  </tr>



									</tbody>
								  </table>                      </div>
							  <div class="tab-pane" id="la">
								<table class="table card-table table-vcenter text-nowrap datatable">
									<thead>
									  <tr>
										<th class="tabhead">Name 
										</th>
										<th>Price USDT</th>
										<th>USD Price</th>
										<th>24H Change</th>
										<th>24H High</th>
										<th>24H Low</th>
										<th>Volume</th>
										<th>Market</th>
										<th></th>
									  </tr>
									</thead>
									<tbody>

									  <tr>
										<td><img src="https://res.cloudinary.com/akilexchange/image/upload/v1626767367/uploads/currency/ftjj0yy9tl5pbugzv8gc.png" width="11%" alt="" class="table-cryp"> XRP/ETH</td>
									  <td>0.0002982 / 0$</td>
									  <td>$32.63 </td>
									  <td><span class="rdn">-1.45%</span></td>
									  <td>0.0003049</td>
									  <td>0.0002952</td>
									  <td>4634289</td>
									  <td>
										</td>

									  <td><a href="#" class="gradient-btn trade">Trade</a></td>

									  </tr>

									</tbody>
								  </table>                      </div>



						  </div>
						</div> -->




					  </div>

				  </div>


			  </div>
          </div>
        </div>
      </div>


   
    <?php $this->load->view('front/common/footer');?>
  