<?php $this->load->view('front/user/login_header');
$user_id = $this->session->userdata('user_id');
 ?>

<div class="page-body">
        <div class="container-xl">
          <div class="row row-deck row-cards">
            <div class="heading">

              <div class="space-10"></div>
              <h3 style="text-align: center;color: black;">Upload ID Photos</h3>
          </div>

          <p style="color: #4890fb;">Please fill with authentic information because it can not be changed once verified.</p>
          <p style="color: #4890fb;">Please keep the picture clear and less than 1MB</p>
          <div class="space-40"></div>

 <div class="row">
          <div class="col-12 col-lg-4">

             <?php
                        $attributes=array('id'=>'verification_forms2'); 
                        $action = front_url() . 'address_verification_new';
                        echo form_open_multipart($action,$attributes);
                        $img = front_img().'id.png';
                        if(!empty(trim($users->photo_id_1)) && ($users->photo_1_status==3 || $users->photo_1_status==1)){
                            $img = $users->photo_id_1;
                        }
                     ?> 
            <h4 style="color:black; font-weight: 500;text-align: center;">Front Photo of ID</h4>
            <div class="Neon Neon-theme-dragdropbox">
              <div class="Neon-input-dragDrop"><div class="Neon-input-inner"><div class="Neon-input-icon"><img id="address_proof" src="<?php echo $img;?>"></div></div>
              </div>
              <?php
                     if(($users->photo_1_status==0 || $users->photo_1_status==2)){
                     ?>  
              <input type="hidden"  value="253d521c8b2a4fe7d17412ac5a8b0e1c">    
              <input style="z-index: 999; opacity: 0; width: 320px; height: 200px; position: absolute; right: 0px; left: 0px; margin-right: auto; margin-left: auto;" id="photo_ids_1" type="hidden"  name="photo_ids_1" value="<?php echo $users->photo_id_1;?>">
               <input type="hidden" id="addr_proof" value="">
               <input name="photo_id_1" type="file" id="imageUpload1" class="file-upload-field" >
              

          </div>
          <p style="color:black; font-weight: 500;text-align: center;">Please provide front photo of your ID/Passport</p>
          <div class="form-footer">
            <button><a  class="logibtn gradient-btn" type="submit" id="addr_submit">Upload Front of the Document</a></button>

            <?php } ?>
            <?php   

  if($users->photo_1_status==1 || $users->photo_1_status==0){

    $kyc_status="pending";
  }
  elseif($users->photo_1_status==2){

     $kyc_status="Rejected";

  }
  else{

     $kyc_status="completed";


  }
?>
 <p style="color:black; font-weight: 500;text-align: center;">Please provide front photo of your ID/Passport</p>
               <h4>[Note : Maximum FileSize Should Be Below 3mb]</h4>

              <b><p style="color: aliceblue";>KYC Status : <?=$kyc_status;?></p></b>
                <span class="photo_error">
    <small style="padding-left: 85px;" class="error_msg photo_id_1_error error1"></small>
    </span>
          </div>
           <?php echo form_close();?>
          </div>
          <div class="col-12 col-lg-4">

             <?php
                      $attributes = array('id'=>'verification_forms3'); 
                      $action = front_url() . 'id_verification_new';
                      echo form_open_multipart($action,$attributes);

                      $img1 = front_img().'id.png';
                      if(!empty(trim($users->photo_id_2)) && ($users->photo_2_status==3 || $users->photo_2_status==1)){
                          $img1 = $users->photo_id_2;
                      }
                                  
                                 
                              ?>
            <h4 style="color:black; font-weight: 500;text-align: center;">Back Photo of ID</h4>
            <div class="Neon Neon-theme-dragdropbox">
              <div class="Neon-input-dragDrop"><div class="Neon-input-inner"><div class="Neon-input-icon"><img id="id_proof" src="<?php echo $img1;?>"></div></div></div>
                <?php
                                     if(($users->photo_2_status==0 || $users->photo_2_status==2)){
                                     ?>

                      <input type="hidden" name="latincoin" value="253d521c8b2a4fe7d17412ac5a8b0e1c">
                   <input name="photo_id_2" type="file" id="imageUpload2" class="file-upload-field">
              <input style="z-index: 999; opacity: 0; width: 320px; height: 200px; position: absolute; right: 0px; left: 0px; margin-right: auto; margin-left: auto;" id="photo_ids_2" type="hidden" value="<?php echo $users->photo_id_2;?>">
              
              </div>
              <p style="color:black; font-weight: 500;text-align: center;">Please provide Back photo of your ID/Passport</p>
              <div class="form-footer">
               <button> <a  class="logibtn gradient-btn" type="submit" id="id_submit">Upload Back of the Document</a></button>
                <?php }?>

              <?php   

  if($users->photo_2_status==1 || $users->photo_2_status==0){

    $kyc_status="pending";
  }
  elseif($users->photo_2_status==2){

     $kyc_status="Rejected";

  }
  else{

     $kyc_status="completed";


  }
?>

              <p style="color:black; font-weight: 500;text-align: center;">Please provide Back photo of your ID/Passport</p>
               <h4>[Note : Maximum FileSize Should Be Below 3mb]</h4>
        <b><p style="color: aliceblue";>KYC Status : <?=$kyc_status;?></p></b>    

         <span class="photo_error">
    <small style="padding-left: 85px;" class="error_msg photo_id_1_error error1"></small>
    </span>  
              </div>
                <?php echo form_close();?>
            </div>
            <div class="col-12 col-lg-4">
               <?php
                        $attributes = array('id'=>'verification_forms4'); 
                        $action = front_url() . 'photo_verification_new';
                        echo form_open_multipart($action,$attributes);

                        $img2 = front_img().'id.png';
                        if(!empty(trim($users->photo_id_3)) && ($users->photo_3_status==3 || $users->photo_3_status==1)){
                            $img2 = $users->photo_id_3;
                        }
                        
                    ?>
              <h4 style="color:black; font-weight: 500;text-align: center;">A recent Photo of Yourself</h4>
              <div class="Neon Neon-theme-dragdropbox">
                 <div class="Neon-input-dragDrop"><div class="Neon-input-inner"><div class="Neon-input-icon"><img id="selfie_proof" src="<?php echo $img2; ?>"></div></div></div>
                  <?php
                             if(($users->photo_3_status==0 || $users->photo_3_status==2)){
                             ?>
                               <input name="photo_id_3" type="file" id="imageUpload3" class="file-upload-field" >
                <input style="z-index: 999; opacity: 0; width: 320px; height: 200px; position: absolute; right: 0px; left: 0px; margin-right: auto; margin-left: auto;"id="photo_ids_3" name="photo_ids_3" multiple="multiple" type="hidden">
               
                </div>
                <p style="color:black; font-weight: 500;text-align: center;">Please provide Recent photo of you</p>
                <div class="form-footer">
                    <button> <a id="photo_submit" type="submit" class="logibtn gradient-btn">Upload Your Photo</a></button>

                     <?php } ?>

  
                <?php   

  if($users->photo_3_status==1 || $users->photo_3_status==0){

    $kyc_status="pending";
  }
  elseif($users->photo_3_status==2){

     $kyc_status="Rejected";

  }
  else{

     $kyc_status="completed";


  }
?>
 <p style="color:black; font-weight: 500;text-align: center;">Please provide Recent photo of you</p>
  <h4 >[Note : Maximum FileSize Should Be Below 3mb]</h4>

 <b><p style="color: aliceblue";>KYC Status : <?=$kyc_status;?></p></b>
  <span class="photo_error">
    <small style="padding-left: 85px;" class="error_msg photo_id_1_error error1"></small>
    </span>
                </div>
                 <?php echo form_close();?>
            </div>
          </div>

            </div>
          </div>
        </div>

        <?php $this->load->view('front/common/footer'); ?>

        <script type="text/javascript">


        function readURLProfile(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#img-profile').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }
    $("#imageUpload").change(function() {
        readURLProfile(this);
    });

      $.validator.addMethod('ZipChecker', function() {
    }, 'Invalid zip code');
         $.validator.addMethod("lettersonly", function(value) {
    return (/^[a-zA-Z\s]*$/.test(value));
});

    $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
        if (options.type.toLowerCase() == 'post') {
            options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
            if (options.data.charAt(0) == '&') {
                options.data = options.data.substr(1);
            }
        }
    });

    $( document ).ajaxComplete(function( event, xhr, settings ) {
        if (settings.type.toLowerCase() == 'post') {
            $.ajax({
                url: front_url+"get_csrf_token", 
                type: "GET",
                cache: false,             
                processData: false,      
                success: function(data) {

                     $("input[name="+csrfName+"]").val(data);
                }
            });
        }
    });






    $("#imageUpload1").change(function() {
        readURL1(this);
    });
   $("#imageUpload2").change(function() {
        readURL2(this);
    });

   $("#imageUpload3").change(function() {
        readURL3(this);
    });
    $("#profile-picture").change(function() {
        readURL5(this);
    });


   function readURL1(input) {

        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#address_proof').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }


    function readURL2(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#id_proof').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }



    function readURL3(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#selfie_proof').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }

        function readURL5(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#profile_pic').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }

  
    $("#addr_submit").click(function(){
        var photo_id_2 = $('#imageUpload1').val();       
        var error_msg = '';
        if($.trim(photo_id_2) == '' || $.trim(photo_id_2) == null){
            $('.photo_id_1_error').html('Provide Address Proof').fadeIn(1000).fadeOut(3000);
            $('#imageUpload1').focus();
            return false;
        }else{
            $("#verification_forms2").submit();
            return true;
        }
    });
    $("#address_cancel").click(function(){
        var photo_id_2 = $('#imageUpload1').val(); 
        var error_msg = '';
        if($.trim(photo_id_2) == '' || $.trim(photo_id_2) == null){
            $('.photo_id_1_error').html('No Address Proof to cancel').fadeIn(1000).fadeOut(3000);
            $('#imageUpload1').focus();
            return false;
        }else{

            $('#imageUpload1').val('');
            $('#address_proof').attr('src', base_url+'assets/front/images/id_proof.png');
            return true;
        }
    });

    $("#id_submit").click(function(){
        var photo_id_3 = $('#imageUpload2').val();       
        var error_msg = '';
        //console.log(isEmpty($.trim(photo_id_3)));
        if($.trim(photo_id_3) == '' || $.trim(photo_id_3) == null){
            $('.photo_id_2_error').html('Provide ID Proof').fadeIn(1000).fadeOut(3000);
            $('#imageUpload2').focus();
            return false;
        }else{
            $("#verification_forms3").submit();
            return true;
        }
    });
    $("#id_cancel").click(function(){
        var photo_id_3 = $('#imageUpload2').val();
        var error_msg = '';
        if($.trim(photo_id_3) == '' || $.trim(photo_id_3) == null){
            $('.photo_id_2_error').html('No ID Proof to cancel').fadeIn(1000).fadeOut(3000);
            $('#imageUpload2').focus();
            return false;
        }else{
            $('#imageUpload2').val('');
            $('#id_proof').attr('src', base_url+'assets/front/images/id_proof.png');
            return true;
        }
    });

     $("#selfie_submit").click(function(){
        var photo_id_3 = $('#imageUpload3').val();       
        var error_msg = '';
        //console.log(isEmpty($.trim(photo_id_3)));
        if($.trim(photo_id_3) == '' || $.trim(photo_id_3) == null){
            $('.photo_id_3_error').html('Provide Selfie Photo').fadeIn(1000).fadeOut(3000);
            $('#imageUpload3').focus();
            return false;
        }else{
            $("#verification_forms4").submit();
           
            return true;
        }
    });
    $("#selfie_cancel").click(function(){
        var photo_id_3 = $('#imageUpload3').val();
        var error_msg = '';
        if($.trim(photo_id_3) == '' || $.trim(photo_id_3) == null){
            $('.photo_id_3_error').html('No Photo to cancel').fadeIn(1000).fadeOut(3000);
            $('#imageUpload3').focus();
            return false;
        }else{
            //$("#verification_forms3").submit();
            $('#imageUpload3').val('');
            $('#selfie_proof').attr('src', base_url+'assets/front/images/settings_user.png');
            return true;
        }
    });

    </script>