<?php $this->load->view('front/common/inner_header');
$lang_id = $this->session->userdata('site_lang');
$user_id = $this->session->userdata('user_id');
// $content = $sitelan."_content";
// echo 'lang '.$sitelan;
// echo $home_section->$sitelan.'_content';
if($lang_id!=''){
$title = $lang_id.'_name';
$content = $lang_id.'_content';
$question = $lang_id.'_question';
$description = $lang_id.'_description';
}else{
$title = $site_lang.'_name';
$content = $site_lang.'_content';
$question = $site_lang.'_question';
$description = $site_lang.'_description';
}
?>
<style>
div.dataTables_wrapper div.dataTables_paginate{
        margin-top: 10px;
}
</style>



<div class="token-info-sec">
<div class="container">
<div class="sec-title text-center">
<h1 data-watermark="">
<span>Sign Up to</span> xabits
</h1>
<!-- <p>Sign <ins></ins>to your account again for full access</p> -->
</div>
<div class="row">
<div class="col-lg-3"></div>
<div class="col-lg-6">
<?php $attributes=array('id'=>'register_user','class'=>'auth_form','autocomplete'=>"off");
echo form_open($action,$attributes); $settings = $site_common['site_settings'];
?>
<!-- <div class="single-input-box box-1">
<input type="text" placeholder="Enter Your UserName" name="username">
<span class="input-icon">
<i class="icofont-ui-user"></i>
</span> 
</div> -->
<div class="single-input-box box-1">
<input type="email" placeholder="Enter Your Email Address" id="register_email" name="register_email">
<span class="input-icon">
<i class="icofont-ui-message"></i>
</span>
</div>
<div class="single-input-box box-1">

 <input id="register_password"  placeholder="Enter Your Password" type="password"  name="register_password" value="">
   <!-- <span  class="icofont-eye-alt field-icon toggle-password"></span> -->

<span toggle="#register_password" class="input-icon toggle-password">
<i class="icofont-eye-alt eye-icon"></i>
</span>

</div>
<div class="single-input-box box-1">
<input type="password" placeholder="Enter Your Confirm Password" name="register_cpassword" id="register_cpassword">
<span toggle="#register_cpassword" class="input-icon toggle-password">
<i class="icofont-eye-alt eye-icon"></i>
</span>

</div>
<?php $refferalid = $_GET['ref'];
// echo $refferalid;
?>
<div class="single-input-box box-1">
<input type="text" placeholder="Referral Code(Optional)" id="referral_id" name="referral_id" value="<?php echo $refferalid;?>">
<span class="input-icon">
<i class="icofont-ui-user"></i>
</span>
</div>
<div class="single-select-box box-1 ">
<select class="select-active nice-select" name="country" id="country">
<option value="">Select Country</option>
<?php
if(isset($countries) && !empty($countries)){
foreach($countries as $Country){
?>
<option value="<?php echo $Country->id?>"><?php echo $Country->country_name;?></option>
<?php
}
}
?> 
</select>
</div>
<br>
<button class="btn btn-primary <?=($sitehome=='home' || $sitehome=='')?'home':''?>" type="submit">Create Account</button>
<?php echo form_close();?>
<div class="mt-5">
<p>Already registered?<a href="<?php echo base_url();?>login" class="fw-bold">Login</a></p>
</div>
</div>
<div class="col-lg-3"></div>
</div>
</div>
</div>

<?php $this->load->view('front/common/inner_footer');?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.js"></script>


    <script type="text/javascript">

    var base_url='<?php echo base_url();?>';
    var front_url='<?php echo front_url();?>';

    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';


    $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
        if (options.type.toLowerCase() == 'post') {
            options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
            if (options.data.charAt(0) == '&') {
                options.data = options.data.substr(1);
            }
        }
    });

    $( document ).ajaxComplete(function( event, xhr, settings ) {
        if (settings.type.toLowerCase() == 'post') {
            $.ajax({
                url: front_url+"get_csrf_token", 
                type: "GET",
                cache: false,             
                processData: false,      
                success: function(data) {
                    console.log(data);
                     $("input[name="+csrfName+"]").val(data);
                }
            });
        }
    });
$(document).ready(function () {
    jQuery.validator.addMethod("mail", function(value, element) {
return this.optional(element) || /^([a-zA-Z0-9_.+-])+@(([a-zA-Z0-9-])+.)+([a-zA-Z0-9]{2,4})+$/.test(value);
});

jQuery.validator.addMethod("alphanumeric", function(value, element) {
        return this.optional(element) || /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[A-Za-z\d@$!%*#?&^_-]{8,}$/.test(value);
});


    $('#register_user').validate({
        errorClass: 'invalid-feedback',
            rules: {
                username: {
                required: true
            },
                register_email: {
                    required: true,
                    email: true,
                    mail: true,
               remote: {
                    url: front_url+'email_exist',
                    type: "post",
                    csrf_token : csrfName,
                    data: {
                        email: function() {
                            return $( "#register_email" ).val();
                        }
                    }
                }
            },
           
            register_password: {
                required: true,
                minlength: 8,
                alphanumeric: true
            },
            register_cpassword: {
                required: true,
                equalTo : "#register_password"
            },
            country: {
                required: true
            },
            terms: {
                required:true
            }
        },
        messages: {
            username: {
                required:"Please enter Username"
            },
           register_email: {
                required:"Please enter email",
                email: "Please enter valid email address",
                mail: "Please enter valid Email",
                remote: "Entered Email Address Already Exists"
            },
            register_password: {
                required: "Please enter password",
                 minlength: "Minimum 8 characters",
                alphanumeric: " Password should contains Minimum 8 characters  uppercase,lowecase,special characters and numbers"
            },
            register_cpassword: {
                required: "Please enter Confirm Password",
                equalTo : "Please enter same password"
            },
            country: {
                required: "Please select country"
            }
        },
        invalidHandler: function(form, validator) {
          if(!validator.numberOfInvalids())
          {
            return;
          }
          else
          {
            var error_element=validator.errorList[0].element;
            error_element.focus();
          }
        },
        highlight: function (element) {
          //$(element).parent().addClass('error')
        },
        unhighlight: function (element) {
          $(element).parent().removeClass('error')
        },
        submitHandler: function(form) 
        {
        $('#submit_btn').prop('disabled');
        // $('.spinner-border').css('display','inline-block');

                  var $form = $(form);
                  //alert("ddd")
                  form.submit();
          
        }
    });
});
</script>
<script type="text/javascript">
    $(".toggle-password").click(function() {
      console.log($(this));
  $(this).find('.eye-icon').toggleClass("icofont-eye-blocked");
  var input = $($(this).attr("toggle"));
  if (input.attr("type") == "password") {
    input.attr("type", "text");
  } else {
    input.attr("type", "password");
  }
});
</script>

