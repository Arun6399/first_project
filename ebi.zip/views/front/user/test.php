<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Common</title>
</head>
<style type="text/css">
	.row
	{
		text-align: center;
		padding: 10px;
	}
	.hed{
		text-align: center;

	}
</style>
<body>
	<h3 class="hed">Form</h3>
			<div class="container">

				<img src="<?php echo front_img();?>OCI-Discovery-Assesment-and-Planning.html">
				<form action="test" method="POST" id="mape">
					
				<div class="row">
					<input type="text" name="username" id="username" class="form-control"> 
				</div>
				<div class="row">
					<input type="text" name="email" id="email" class="form-control"> 
				</div>
				<div class="row">
					<input type="password" name="password" id="password" class="form-control"> 
				</div>

				<div class="row">
					<button type="submit">Send</button>
				</div>
				</form>

			</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>

			<script type="text/javascript">


				$(document).ready(function (){

					$('#mape').validate({
						rules: {

						   username : {
						   	required :true
						   },
						   email : {
						   	required : true
						   },
						   password : {
						   	required : true
						   }

						},
						messages : {
							username : {
								required :"Please enter username"
							},
							email : {
								required : "Please enter email"
							},
							password : {
								required : "Please enter password"
							}
						}

					})
				});
			</script>
</body>
</html>