<?php
    $this->load->view('front/user/wallet_header');
    $user_id = $this->session->userdata('user_id');
     $all_currency = $this->common_model->getTableData("currency",array("status"=>1))->result();
      if(count($all_currency))
      {
        $tot_balance = 0;
        foreach($all_currency as $cur)
        {
            $balance = getBalance($user_id,$cur->id);
            $usd_balance = $balance * $cur->online_usdprice;

            $tot_balance += $usd_balance;
        }
      }
?>
<style type="text/css">
   .cryptorio-main-form
   {
    overflow:none !important; 
   } 

</style>
<div class="content-body">
            <div class="container-fluid">
                <div class="row">
                   
                    <div class="col-xl-12 col-md-12">
                        <div class="row">

                            <div class="col-xl-12">
                                <div class="card">
                                    
                                    <div class="card-body">
      <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="dashboard-section">
                    <div class="dashboard-box">
                        <div class="history-tabs">
                            <ul class="nav nav-pills pt-3 justify-content-center" id="pills-tab" role="tablist">
                                <li class="nav-item">
                                    <a class="mytableclass nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">Deposit History</a>
                                </li>
                                <li class="nav-item">
                                    <a class="mytableclass nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">Withdraw History</a>
                                </li>
                             <!--    <li class="nav-item">
                                    <a class="mytableclass nav-link" id="pills-crypto-tab" data-toggle="pill" href="#pills-crypto" role="tab" aria-controls="pills-crypto" aria-selected="false">Instant Buy  History</a>
                                </li> -->

                               <!--  <li class="nav-item">
                                    <a class="mytableclass nav-link" id="pills-login-tab" data-toggle="pill" href="#pills-login" role="tab" aria-controls="pills-login" aria-selected="false">Login History</a>
                                </li> -->

                                <li class="nav-item">
                                    <a class="mytableclass nav-link" id="pills-referral-tab" data-toggle="pill" href="#pills-referral" role="tab" aria-controls="pills-referral" aria-selected="false">Referral History</a>
                                </li>

                            </ul>
                            <div class="tab-content" id="pills-tabContent">
                                <div class="tab-pane fade active show" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                                    <div class="section-head">
                                       Deposit History
                                    </div>
                                    <div class="cryptorio-forms cryptorio-main-form pb-5" >
                          
                         <table id="example" class="table display table-striped" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>S.no</th>
                                                <th>Date & Time</th>
                                                <th>Currency</th>
                                                <th>Transaction ID</th>
                                                <th>Description</th>
                                                <th>Amount</th>
                                               <!--  <th>Address</th> -->
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody class="opnOdrTblScroll">
                                            <?php
                                                if(isset($deposit_history) && !empty($deposit_history))
                                                {
                                                    $a=0;
                                                    foreach($deposit_history as $deposit)
                                                    {
                                                        $a++;
                                                        if($deposit->transaction_id == '')
                                                        {
                                                          $transaction_id = '-';
                                                        }
                                                        else
                                                        {
                                                          $transaction_id = $deposit->transaction_id;
                                                        } 

                                                        $cur_de = getcoindetail($deposit->currency_id);

                                            ?>
                                                        <tr>
                                                            <td><?php echo $a;?></td>
                                                            <td><?php echo date('d-M-Y H:i',$deposit->datetime);?></td>
                                                            <td><i class="cc <?php echo strtoupper($cur_de->currency_symbol);?> mr-3"></i>  <?php echo strtoupper(getcryptocurrency($deposit->currency_id));?></td>
                                                            <td>#<?php echo $transaction_id;?></td>
                                                            <td><?php echo $deposit->description;?></td> 
                                                            <td><?php echo number_format($deposit->amount,8);?></td>
                                                            
                                                            
                                                            <!-- <td><?php echo $deposit->crypto_address;?></td> -->
                                                            <?php if($deposit->status =='Completed')
                                                            {
                                                                $clr_class = 'text-green';
                                                            }
                                                            else
                                                            {
                                                                $clr_class = 'text-red';
                                                            } ?>                   

                                                            <td class="<?php echo $clr_class;?>"><?php echo $deposit->status;?></td>
                                                        </tr>
                                            <?php 
                                                    }
                                                }   
                                                ?>
                                        </tbody>
                                    </table>



                          </div>
                                </div>
                                <div class="tab-pane fade pb-5" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" >
                                    <div class="section-head">
                                        Withdraw History
                                    </div>
                                    <table id="example" class="table display table-striped" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>S.no</th>
                                                <th>Date & Time</th>
                                                <th>Currency</th>
                                                <th>Sent Amount</th>
                                                <th>Fees</th>
                                                <th>Receive Amount</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody class="tradeHistoryTblScroll">
                                            <?php
                                                if(isset($withdraw_history) && !empty($withdraw_history))
                                                {
                                                    $b=0;
                                                    foreach($withdraw_history as $withdraw)
                                                    {
                                                        $b++;
                                            ?>
                                                        <tr>
                                                            <td><?php echo $b;?></td> 
                                                            <td><?php echo date('d-M-Y H:i',strtotime($withdraw->datetime));?></td>
                                                            <td><?php echo strtoupper(getcryptocurrency($withdraw->currency_id));?></td>
                                                            <td><?php echo number_format($withdraw->amount,8);?></td>
                                                            <td><?php echo number_format($withdraw->fee,8);?></td>
                                                            <td><?php echo number_format($withdraw->transfer_amount,8);?></td>
                                                            <?php 
                                                                if($withdraw->status =='Completed')
                                                                {
                                                                    $elmt_class = 'text-green';

                                                                }
                                                                else
                                                                {
                                                                    $elmt_class = 'text-red';
                                                                } 
                                                            ?> 
                                                            <td class="<?php echo $elmt_class; ?>"><?php echo $withdraw->status;?></td>
                                                        </tr>
                                            <?php 
                                                    } 
                                                }
                                               
                                            ?>
                                            
                                        </tbody>
                                    </table>
                                </div>
                                <!-- -->

                                <div class="tab-pane fade pb-5" id="pills-crypto" role="tabpanel" aria-labelledby="pills-crypto-tab" >
                                    <div class="section-head">
                                        Instant Buy  History
                                       
                                   </div>
                                    
                                   <table id="example" class="table display table-striped" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>S.no</th>
                                                <th>Date & Time</th>
                                                <th>Currency</th>
                                                <th>Sent Amount</th>
                                                <!-- <th><?php echo $this->lang->line('Fees')?></th> -->
                                                <th>Receive Amount</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody class="tradeHistoryTblScroll">
                                            <?php
                                                if(isset($instantbuy_history) && !empty($instantbuy_history)){
                                                    $c=0;
                                                    foreach($instantbuy_history as $instant_buy){
                                                        $c++;
                                            ?>
                                                        <tr>
                                                            <td><?php echo $c;?></td>
                                                            <td><?php echo date('d-M-Y H:i',strtotime($instant_buy->datetime));?></td>
                                                            <td><?php echo strtoupper(getcryptocurrency($instant_buy->currency_id));?></td>
                                                            <td><?php echo number_format($instant_buy->amount,8);?></td>
                                                            <!-- <td><?php echo number_format($instant_buy->fee,8);?></td> -->
                                                            <td><?php echo number_format($instant_buy->transfer_amount,8);?></td>
                                                            <?php 
                                                                if($instant_buy->status =='Completed')
                                                                {
                                                                    $elmt_class = 'text-green';

                                                                }
                                                                else
                                                                {
                                                                    $elmt_class = 'text-red';
                                                                } 
                                                            ?> 
                                                            <td class="<?php echo $elmt_class; ?>"><?php echo $instant_buy->status;?></td>
                                                        </tr>
                                            <?php 
                                                    } 
                                                }
                                            ?>
                                                    
                                        </tbody>
                                    </table>

                                    </div>


                                <div class="tab-pane fade pb-5" id="pills-login" role="tabpanel" aria-labelledby="pills-login-tab">
                                    <div class="section-head"> 
                                       <?php echo $this->lang->line('Login History')?>                                   </div>
                                   
                                    <div class="cryptorio-forms">

                                    <table id="example" class="table display table-striped" style="width:100%">

                                        <thead>
                                            <tr>
                                                 <th>S.no</th>
                                                <th>Date & Time</th>
                                                <th>IP Address </th>
                                                <th>Browser</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody class="opnOdrTblScroll">
                                            <?php
                                                if(isset($login_history) && !empty($login_history)){
                                                    $d=0;
                                                    foreach($login_history as $login){
                                                        $d++;
                                            ?>

                                                        <tr>
                                                            <td><?php echo $d;?></td>
                                                            <td><?php echo date('d-m-Y h:i a',$login->date);?></td>
                                                            <td><?php echo $login->ip_address;?></td>
                                                            <td><?php echo $login->browser_name?><?php //echo $login->browser_name;?></td>
                                                          
                                                             <td><?php echo $this->lang->line($login->activity);?></td>
                                                        </tr>  
                                            <?php
                                                    }
                                                } 
                                            ?>
                                                
                                          
                                        </tbody>
                                    </table>


                               </div> 


                                </div>



                                <div class="tab-pane fade pb-5" id="pills-referral" role="tabpanel" aria-labelledby="pills-referral-tab">
                                  <div class="section-head">
                                        Referral  History
                                       
                                   </div>
                                   
                                    <div class="cryptorio-forms">

                                    <table id="example" class="table display table-striped" style="width:100%">

                                        <thead>
                                            <tr>
                                                <th>S.no</th>
                                                <th>Date & Time</th>
                                                <th>Referral Mail</th>
                                                <th>Amount</th>
                                                <th>Currency</th>
                                            </tr>
                                        </thead>
                                        <tbody class="opnOdrTblScroll">
                                            <?php
                                                if(isset($referral_history) && !empty($referral_history)){
                                                    $r=0;
                                                    foreach($referral_history as $referral){

                                                       $userrecs = $this->common_model->getTableData('users',array('id'=>$this->session->userdata('user_id')))->row();
                                                        $referral_recs = $this->common_model->getTableData('users',array('parent_referralid'=>$userrecs->referralid))->row();

                                                        $ref_mail = getUserEmail($referral_recs->id);
 
                                                        $r++;
                                            ?>

                                                        <tr>
                                                            <td><?php echo $r;?></td>
                                                            <td><?php echo $referral->datetime;?></td>
                                                             <td><?php echo $ref_mail;?></td>
                                                            <td><?php echo $referral->amount;?></td>
                                                            <td><?php echo strtoupper(getcryptocurrency($referral->currency));?></td>
                                                          
                                                        </tr>   
                                            <?php
                                                    }
                                                } 
                                            ?>
                                                
                                        </tbody>
                                    </table>
                               </div> 
                            </div>




                            </div>
                        </div>
                    </div>
                </div>
            </div>
</div>
</div>
</div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>  


      <!-- --------------------------------------------slide navbar--------------------------------- -->
      <!-- ---------------------tab panel end---------------------------- -->
      <!-- ---------------------footer---------------------------- -->

<?php 
    $this->load->view('front/common/footer');

?>
    <!--- Data Tables  --->
     <script src="<?php echo front_js();?>datatables.bootstrap4.min.js"></script>
     <script src="<?php echo front_js();?>dataTables.min.js"></script>
     <script src="<?php echo front_js();?>datatables.bootstrap4.js"></script>

<script type="text/javascript">
$(document).ready(function() {

  var language = '<?php echo  $lang_id = $this->session->userdata('site_lang'); ?>';

  if(language=='spanish')
  {

    $('table.display').DataTable( {

       "language": {
              
            "sProcessing": "Procesando ...",
            "sLengthMenu": "Show _MENU_ registros",
            "sZeroRecords": "No se han encontrado resultados",
            "sEmptyTable": "No hay datos disponibles en esta tabla.",
            "sInfo": "Showing registros from _START_ to _END_ of a total of _TOTAL_ registros",
            "sInfoEmpty": "Mostrando registros de 0 to 0 out of a total of 0 registros",
            "sInfoFiltered": "(filtrando un total de _MAX_ registros)",
            "sInfoPostFix": "",
            "sSearch": "búsqueda:",
            "sUrl": "",
            "sInfoThousands": ",",
            "sLoadingRecords": "Cargando ...",
            "oPaginate": {
              "sFirst": "Primera",
              "sLast": "Última",
              "sNext": "Próxima",
              "sPrevious": "Previa"
            },
            "oAria": {
              "sSortAscending": ": Activate to sort the column in ascending order",
              "sSortDescending": ": Activate to sort the column in descending order"
            }


        }
    } );

  }
  else if(language=='italic')
  {
     $('table.display').DataTable( {
       "language": {
              
            "sProcessing": "in lavorazione ...",
            "sLengthMenu": "Mostra _MENU_ inserimenti",
            "sZeroRecords": "nessun risultato trovato",
            "sEmptyTable": "Nessun dato disponibile in questa tabella",
            "sInfo": "Visualizzazione del inserimenti da _START_ a _END_ di un totale di _TOTAL_ inserimenti",
            "sInfoEmpty": "Mostra inserimenti da 0 a 0 su un totale di 0 inserimenti",
            "sInfoFiltered": "(filtrando un totale di _MAX_ inserimenti)",
            "sInfoPostFix": "",
            "sSearch": "ricerca:",
            "sUrl": "",
            "sInfoThousands": ",",
            "sLoadingRecords": "Caricamento in corso ...",
            "oPaginate": {
              "sFirst": "Primo",
              "sLast": "Ultimo",
              "sNext": "Prossimo",
              "sPrevious": "Precedente"
            },
            "oAria": {
              "sSortAscending": ": Activate to sort the column in ascending order",
              "sSortDescending": ": Activate to sort the column in descending order"
            }


        }

    });

  }

  else
  {

    $('table.display').DataTable();


  }


} );

</script>


   </body>
</html> 