<?php
    $this->load->view('front/user/login_header');
    $user_id = $this->session->userdata('user_id');
?>
<style type="text/css">
  .popup th, .popup td {
  padding: 0px !important;
  font-weight: 600 !important;
}
</style>
<div class="content-body">
    <section class="container-fluid p-0 mt-5">
          <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="inner-page-header">
                        <h2>Deposit </h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="dash-profile-body background-grey">
                        <form class="deposit_form">
                            <div class="d-flex align-items-center justify-content-center row">
                                <div class="deposit_form_div col-md-5 ml-auto">
                                    <div class="form-group text-left">
                                        <label for="formGroupExampleInput">Select Coin</label>
                                            <select class="custom-select" onChange="change_address(this)">
                                                        <?php
                                                        if(count($all_currency) > 0)
                                                        {
                                                            foreach ($all_currency as $currency) 
                                                            {
                                                        ?>
                                              <option value="<?php echo $currency->id.'#'.$currency->type;?>" <?=($sel_currency->id == $currency->id)?'selected':''?>>
                                              <?=$currency->currency_symbol?>
                                              </option>
                                              <?php } } ?>
                                            </select>
                                    </div>

                                    <div class="form-group text-left cryp_add" <?php if($sel_currency->type == 'fiat'){ ?> style="display: none;" <?php } ?>>
                                        <label for="formGroupExampleInput">Address</label>
                                        <input type="text" class="form-control" readonly="" value="<?php echo $crypto_address;?>" id="crypto_address">
                                    </div>



                                </div>
                                <div class=" col-md-2 mr-auto">
                                  <?php                                 
                                  if($sel_currency->type=='digital')
                                    $style = 'display:block';
                                  else
                                    $style = 'display:none';
                                   ?>
                                    <img class="qr-code" id="qr_img" style="height: 200px;height: 200px;<?=$style;?>" src="<?php echo $First_coin_image;?>"> 
                                </div>
                                <!-- <div class=" col-md-2 mr-auto" id="cryp_img" style="display: none;">
                                    <img class="qr-code" id="qr_img" style="height: 200px;height: 200px;" src="<?php echo $First_coin_image;?>"> 
                                </div> -->
                            </div>
                             <div class="col-md-6 mr-auto deposit-address fiat_deposit" <?php if($sel_currency->type != 'fiat'){?> style="display: none;" <?php } ?>>
                            <?php
                            if(trim($user->verify_level2_status)=='Completed')
                                            {
                                    ?>
                            <div class="text-center">
                              <!-- <a  class="btn btn-success waves-effect waves-light button" href="javascript:;" style="margin-right:20px;"  data-toggle="modal" data-target="#paypal_deposit" data-dismiss="modal" aria-label="Close">Paypal</a> -->

                              <a  class="btn btn-success waves-effect waves-light button" href="javascript:;" style="margin-right:20px;"  data-toggle="modal" data-target="#bankwire" data-dismiss="modal" aria-label="Close">Bank Wire</a> 

                              <!-- <a  class="btn btn-success waves-effect waves-light button" href="javascript:;" style="margin-right:20px;"  data-toggle="modal" data-target="#paypro" data-dismiss="modal" aria-label="Close">Paypro</a>  -->


                            </div>



                            <?php } else {  ?>

                                <div class="text-center mt-3 mb-2">Please Complete KYC<a  class="btn btn-danger" style="margin-left: 30px;" href="<?php echo base_url();?>kyc"> Click here</a></div><?php } ?>
                                </div>

                        <!-- </form> -->
                    </div>
                </div>

                <?php 

                // print_r($admin_bankdetails);

                ?>

                <div class="col-lg-12">
                    <div class="table_panel" style="padding-top: 20px;">
                        <div class="table_panel_heading justify-content-between align-items-center disp">
                            <h4>Deposit History</h4>
                            <input type="text" class="form-control search_input input-wid" id="search" placeholder="Search" >
                        </div>
                        <div class="table_panel_body">
                            <div class="table-responsive">
                              <table class="table table-borderless">
                                <thead>
                                  <tr>
                                    <th>Coin</th>
                                    <th>Date&Time</th>
                                    <th>Transaction ID</th>
                                    <th>Description</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <?php if($sel_currency->id == 7){?>
                                    <th class="fiat_div">Update</th>
                                    <?php
                                  }
                                    ?>
                                  </tr>
                                </thead>
                                <tbody class="table_scroll">
                                  <?php
                                                            if(isset($deposit_history) && !empty($deposit_history))
                                                            {
                                                                $a=0;
                                                                foreach($deposit_history as $deposit)
                                                                {
                                                                    $a++;
                                                                    if(empty($deposit->transaction_id))
                                                                    {
                                                                      $transaction_id = '-';
                                                                    }
                                                                    else
                                                                    {
                                                                      $transaction_id = $deposit->transaction_id;
                                                                    }     
                                                        ?>
                                  <tr>
                                    <td><?php echo strtoupper(getcryptocurrency($deposit->currency_id));?></td>
                                    <td><?php echo date('d-M-Y H:i',$deposit->datetime);?></td>
                                    <!-- <td class="address"> --><td><?php echo $transaction_id;?></td>

                                    <td><?php echo $deposit->description;?></td>
                                    <td><?php echo number_format($deposit->amount,8);?></td>
                                    <?php if($deposit->status =='Completed')
                                                                {
                                                                    $clr_class = 'green';
                                                                }
                                                                else
                                                                {
                                                                    $clr_class = 'red';
                                                                } ?>
                                    <td id="dep<?php echo encryptIt($deposit->trans_id);?>"><span class="<?php echo $clr_class;?>"><?php echo $deposit->status;?></span></td>
                                    <?php if($sel_currency->id == 7){
                                      if($deposit->status=='Pending'){
                                      ?>

                                    <td class="fiat_div"><i class="fa fa-refresh" aria-hidden="true"  style="cursor: pointer;"></i></td>
                                    <?php
                                  }
                                  else{
                                    ?>
                                    <td class="fiat_div">-</td>
                                    <?php
                                  }
                                  }
                                    ?>
                                  </tr>
                                  <?php 
                                                                } 
                                                            }else{ 
                                                        ?>
                                  <tr>
                                    <td colspan="6" style="text-align: center;">No records found !!!</td>
                                  </tr>
                                  <?php } ?>
                                </tbody>
                              </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </section>
</div>

<div class="modal fade right" id="bankwire" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true"> 
  
  <!-- Add class .modal-full-height and then add class .modal-right (or other classes from list above) to set a position to the modal -->
  <div class="modal-dialog modal-full-height modal-right iks-popup" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background: #7B6FFF;">
        <h4 class="modal-title w-100" id="myModalLabel">Bankwire Deposit</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
      </div>
      <div class="modal-body" style="background: #00084d;"> 
        <div class="col-sm-12">
              <div class="row">
                <div class="col-sm-12 deposit-address bank_wire">
                  <?php  $action = base_url()."deposit";
       $attributes = array('id'=>'deposit_fiat','autocomplete'=>"off"); 
        echo form_open($action,$attributes); 
                                        ?>     
                  <input type="hidden" name="currency" id="banwire_id" class="currency" value="<?php echo $sel_currency->id;?>" >
                  <div class="form-row"> 
                    <table class="table popup">
                      <tr>
                        <th>Account Number</th>
                        <td><strong><?=$admin_bankdetails->bank_account_number?></strong></td>
                      </tr>
                      <tr>
                        <th>Account CODE</th>
                        <td><strong><?=$admin_bankdetails->bank_swift?></strong></td>
                      </tr>
                      <tr>
                        <th>Account Name</th>
                        <td><strong><?=$admin_bankdetails->bank_account_name?></strong></td>
                      </tr>
                      
                      <tr>
                        <th>Bank Name</th>
                        <td><strong><?=$admin_bankdetails->bank_name?></strong></td>
                      </tr>
                      <tr>
                        <th>POSTAL Code</th>
                        <td><strong><?=$admin_bankdetails->bank_postalcode?></strong></td>
                      </tr>
                    </table>
 
                    
                      <input type="hidden"  name="account_number" value="<?=$admin_bankdetails->bank_account_number ;?>">
                      <input type="hidden"  name="account_name" value="<?=$admin_bankdetails->bank_account_name;?>">
                       <input type="hidden"  name="bank_name" value="<?=$admin_bankdetails->bank_name;?>">
                        <input type="hidden"  name="bank_swift_code" value="<?=$admin_bankdetails->bank_swift;?>">
                         <input type="hidden"  name="bank_country" value="<?=$admin_bankdetails->bank_country;?>">
                         <input type="hidden"  name="bank_city" value="<?=$admin_bankdetails->bank_city;?>">
                         <input type="hidden"  name="bank_postalcode" value="<?=$admin_bankdetails->bank_postalcode;?>">
                          <input type="hidden"  name="bank_address" value="<?=$admin_bankdetails->bank_address;?>">

                     <div class="row">
                        <div class="col-12 col-md-12">
                          <label for="basic-url">Enter amount<span style="color: #fff;">*</span></label>
                          <div class="mb-3">
                            <input type="text"  required="" style="border: 1px solid #7b6fff;" class="form-control input_anim" aria-label="Small" aria-describedby="inputGroup-sizing-sm" name="amount">
                          </div>
                        </div>


                         <div class="col-12 col-md-12">
                          <label for="basic-url">Description<span style="color: #fff;">*</span></label>
                          <div class="mb-3">

                            <?php
                            $permitted_chars = 'GTILGDE7980493WTIAYXQJ804761';
                            $random=substr(str_shuffle($permitted_chars), 0, 10);
                            ?>

                            <input type="text" readonly="" style="border: 1px solid #7b6fff;" class="form-control input_anim" aria-label="Small" aria-describedby="inputGroup-sizing-sm" name="description" value="<?=$random;?>"  id="description"> 


                          </div>
                        </div> 
                     
                      </div>    

                    <div class="col-12 col-md-12">
                      <div class="row">
                        <div class="col-12 col-md-12">
                          <div class="profile-flex border-0 pt-4 pull-left">
                            <div class="text-center">
                              <button name="deposit_bank" id="deposit_bank" class="btn btn-success waves-effect waves-light button" type="submit"> Deposit </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <?php echo form_close();?> </div>
              </div>
            </div>
       </div>
    
    </div>
  </div>
</div>
<!-- Deposit End Bank Wire modal -->




<!--Deposit paypro modal -->
<!-- <div class="modal fade right" id="paypro" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true"> 
  
  
  <div class="modal-dialog modal-full-height modal-right iks-popup" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background: #7B6FFF;">
        <h4 class="modal-title w-100" id="myModalLabel">Paypro Deposit</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
      </div>
      <div class="modal-body" style="background: #00084d;">
        <div class="col-sm-12">
              <div class="row">
                <div class="col-sm-12 deposit-address paypro_payment">
                  <?php  $action = base_url()."paypro_payment";
       $attributes = array('id'=>'paypro_form','autocomplete'=>"off"); 
        echo form_open($action,$attributes); 
                                        ?>     
                  <input type="hidden" name="currency" id="paypro_cur" class="currency" value="<?php echo $sel_currency->id;?>" >
                  <div class="form-row">
                    <div class="col-8 col-md-8">
                      <div class="row">

                         <div class="col-12 col-md-12">
                          <label for="basic-url">Balance  : <strong> <?php echo $balance = getBalance($user->id,$fiat_currency->id,'fiat')." ".$fiat_currency->currency_symbol; ?></strong></label>
                          
                        </div>


                        <div class="col-12 col-md-12 ">
                          <label for="basic-url">Enter amount<span style="color: #fff;">*</span></label>
                          <div class="mb-3">
                            <input type="text" style="border: 1px solid #7b6fff;" oninput="process(this)"  class="form-control input_anim" aria-label="Small" aria-describedby="inputGroup-sizing-sm" id="paypro_amount" name="amount" required="">
                          </div>
                        </div>

                        <div class="col-12 col-md-12 mt-5">
                          <label for="basic-url">Select Payment<span style="color: #fff;">*</span></label>
                          <div class="mb-3">
                            <select class="custom-select" name="payment_mode" required="">
                              <option value="ideal/ABNANL2A">Ideal</option>
                              <option value="bancontact/mrcash">Bancontact</option>
                            </select>
                          </div>
                        </div>


                      </div>
                    </div>
                    <div class="col-12 col-md-12">
                      <div class="row">
                        <div class="col-12 col-md-12">
                          <div class="profile-flex border-0 pt-4 pull-left">
                            <div class="text-center">
                              <button name="deposit_paypro" id="deposit_paypro" class="btn btn-success waves-effect waves-light button" type="submit"> Deposit </button>
                            </div>
                          </div>
                        </div>
                      </div> 
                    </div>
                  </div>
                  <?php echo form_close();?> </div>
              </div>
            </div>
       </div>
    
    </div>
  </div>
</div> -->




    </section>

<?php 


    $this->load->view('front/common/footer');
     $default_coin = $sel_currency->type;

    ?>
 <script type="text/javascript">

// $(document).ready(function() {
// if(success!=''){
//     toastr.success('xabits! '+success);
// }
// if(error!=''){
// toastr.error('xabits! '+error);
// }
// }); 


         var base_url='<?php echo base_url();?>';
    var front_url='<?php echo front_url();?>';

         var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';


        $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
            if (options.type.toLowerCase() == 'post') {
                options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
                if (options.data.charAt(0) == '&') {
                    options.data = options.data.substr(1);
                }
            }
        });

        $( document ).ajaxComplete(function( event, xhr, settings ) {
            if (settings.type.toLowerCase() == 'post') {
                $.ajax({
                    url: front_url+"get_csrf_token", 
                    type: "GET",
                    cache: false,             
                    processData: false,      
                    success: function(data) {
                            var dataaa = $.trim(data);
                         $("input[name="+csrfName+"]").val(dataaa);
                    }
                });
            }
        });


 




        function copy_function() 
        {
            var copyText = document.getElementById("crypto_address");
            copyText.select();
            document.execCommand("COPY");
            $('.copy_but').html("COPIED");
        }

        function change_address(sel)
        {
            var arr1 = sel.value;
            var arr = arr1.split('#');
            var currency_id = arr[0];
            var type = arr[1];
            if(type=='fiat')
            {
                //alert(arr[0]);
                $(".grey-box").css('display','none');
                $(".cryp_add").css('display','none');
                $(".fiat_amt").css('display','block');
                $(".dig_button").css('display','none');
                $(".fiat_div").css('display','block');
                $(".fiat_deposit").css('display','block');
                $("#qr_img").css('display','none');
                
                $.ajax({
                    url: base_url+"change_address",
                    type: "POST",
                    data: "currency_id="+currency_id,
                    success: function(data) {
                        var res = jQuery.parseJSON(data);
                       
                        $('#minimum_deposit').html(res.minimum_deposit);
                    }
                });
                $("#currency").val(currency_id);
                $(".currency").val(currency_id);
                 $("#paypro_cur").val(currency_id);
            }
            else
            { 
              // console.log(currency_id);
              $(".grey-box").css('display','block');
                $(".fiat_div").css('display','none');
                $(".fiat_amt").css('display','none');
                $(".cryp_add").css('display','block');
                $(".fiat_deposit").css('display','none');
                $('.bank_wire').css('display','none');
                $('.paypal_form').css('display','none');
                $(".dig_button").css('display','block');
                $("#wallet_deposit").css('display','none');               
                 $("#qr_img").css('display','block');
                $.ajax({
                    url: base_url+"change_address",
                    type: "POST",
                    data: "currency_id="+currency_id,
                    success: function(data) {
                        var res = jQuery.parseJSON(data);
                        $('#crypto_address').val(res.address);
                        $("#qr_img").attr("src",res.img);
                        $('.det_tag').css('display','none');
                        $('#minimum_withdrawal').html(res.minimum_deposit);
                        $('.syname').html(res.coin_name);
                        // $('.sym').html(res.coin_symbol);
                        
                        console.log(currency_id);
                        // if(currency_id == '5'){
                        //   console.log(currency_id);
                        //   $("#qr_img").css('display','none');
                        // } else{
                        //   // console.log(currency_id);
                        //   $("#qr_img").css('display','block');
                        // }
                       

                    }
                });
            }
        }

       
        function show_paypal(){
            $(".bank_wire").css("display","none");
            $('.paypal_form').css('display','');
        }


        $('#deposit_fiat').validate(
        {
            rules: {
             
                amount: {
                  required: true,
                  number: true,
                },
                description: {
                   required: true
                }
            },
            messages: {
              
              amount: {
                    required: "Please enter amount",
                    number: "Only enter numbers as decimal or float"
                },
                description: {
                    required: "Please enter Description"
                }

            },
            invalidHandler: function(form, validator) {
                if (!validator.numberOfInvalids())
                {
                    return;
                }
                else
                {
                    var error_element=validator.errorList[0].element;
                    error_element.focus();
                }
            },
            highlight: function (element) {
                //$(element).parent().addClass('error')
            },
            unhighlight: function (element) {
                $(element).parent().removeClass('error')
            },
            submitHandler: function(form) 
            { 
                form.submit();
            }
        });

        $('#deposit_mollie').validate(
        {
            rules: {
             
                amount: {
                  required: true,
                  number: true,
                }
            },
            messages: {
              
              amount: {
                    required: "Please enter amount",
                    number: "Only enter numbers as decimal or float"
                }

            },
            invalidHandler: function(form, validator) {
                if (!validator.numberOfInvalids())
                {
                    return;
                }
                else
                {
                    var error_element=validator.errorList[0].element;
                    error_element.focus();
                }
            },
            highlight: function (element) {
                //$(element).parent().addClass('error')
            },
            unhighlight: function (element) {
                $(element).parent().removeClass('error')
            },
            submitHandler: function(form) 
            { 
                form.submit();
            }
        });


        $('#paypro_form').validate(
        {
            rules: {
             
                paypro_amount: {
                  required: true,
                  number: true,
                }
            },
            messages: {
              
              paypro_amount: {
                    required: "Please enter amount",
                    number: "Only enter numbers as float",
                }
            },
            invalidHandler: function(form, validator) {
                if (!validator.numberOfInvalids())
                {
                    return;
                }
                else
                {
                    var error_element=validator.errorList[0].element;
                    error_element.focus();
                }
            },
            highlight: function (element) {
                //$(element).parent().addClass('error')
            },
            unhighlight: function (element) {
                $(element).parent().removeClass('error')
            },
            submitHandler: function(form) 
            { 
                form.submit();
            }
        });




    </script>
    
<script type="text/javascript">
function process(input){
let value = input.value;
let numbers = value.replace(/[^0-9]/g, "");
input.value = numbers;
}
</script>


</body>
</html>