<?php
    $this->load->view('front/user/login_header');
    $user_id = $this->session->userdata('user_id');
     $all_currency = $this->common_model->getTableData("currency",array("status"=>1))->result();
      if(count($all_currency))
      {
        $tot_balance = 0;
        foreach($all_currency as $cur)
        {
            $balance = getBalance($user_id,$cur->id);
            $usd_balance = $balance * $cur->online_usdprice;

            $tot_balance += $usd_balance;
        }
      }
?>
<style type="text/css">
    .file-upload-wrapper:before {

content: "Upload";

}

</style>
      <!-- Page Content -->
<div class="content-body">
            <div class="container-fluid">
                <div class="row">
                   
                    <div class="col-xl-12 col-md-12" >
                        <div class="">

                            <div class="">
                                <div class="card">
                                    
                                    <div class="card-body" style="z-index: 0"> 
         <div class="dashboard-section">
                    <div class="dashboard-box">
                        <div class="dashboard-box-inner pb-0">
                            <h2 class="text-center">Support Ticket</h2>

                           <?php
                                $attributes=array('id'=>'support_form',"autocomplete"=>"off","class"=>"mt-4");
                                $action = front_url() . 'support';
                                echo form_open_multipart($action,$attributes);
                            ?> 
 
                                <div class="profile-flex">

                                    <div class="col-12 col-md-12 col-lg-6 col-xl-6 ml-auto mx-auto">
                                        <div class="row">
                                            <div class="col-12 col-md-12">
                                                <label for="basic-url">Subject</label>
                                                <div class=" mb-3">
                                                   <input type="text" class="form-control" id="subject" name="subject" placeholder="">  
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-12" style="padding-top: 20px;">
                                                <label for="basic-url">Category</label>
                                                <div class=" mb-3">
                                                     <select name="category" class="form-control"  id="category" style="height: auto;">
                                                <?php foreach ($category as $category_value) { ?>
                                                        <option value="<?php echo $category_value->id; ?>"><?php echo ($category_value->name); ?></option>             
                                                <?php } ?>

                                        </select>
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-12">
                                                <div class="form-group">
                                                    <label for="message">Message</label>
                                                    <textarea class="form-control" id="message" name="message" rows="3"></textarea>
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-12">
                                                <div class="custom-file">
                                                  
                                                    <div class="file-upload-wrapper" data-text="Upload Photo">
                                                        <input name="image"  for="imgInp4" type="file" class="file-upload-field" id="imgInp4" accept=".png, .jpg, .jpeg, .doc,.docx, .pdf, .mp4">
                                                    </div>



                                                </div>
                                                <img id="support_img" src=""  alt="Support Img" style="display:none;width:55px" class="img-fluid mb-6 proof_img">
                                                <span class="custom-text pl-2 error" id="img_error"></span>


                                            </div>

                                          <!--    <div class="col-12 col-md-12">
                                                <div class="form-group">
                                                    <label for="message">Captcha</label>
                                                   <div class="g-recaptcha" id="g-recaptcha" data-sitekey="6LfgHUocAAAAAMnFxVDdNS08qZngqnqIczEWNhtq"></div>
                                                </div>
                                                <p id="cp_error" style="color: red;"></p>
                                            </div> -->


                                            <div class="form-btn col-md-12 text-center mt-3">
                                                <button class="btn btn-success waves-effect waves-light button" name="submit_tick" type="submit" id="submit_btn">Submit                                                   <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true" style="display: none;"></span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php echo form_close();?>                        </div>
                    </div><br> 

                    <div class="dashboard-box p-a-15" style="overflow: auto;">
                        <div class="dashboard-box-inner">
                            <h2 class="text-center">Support History</h2>
                            <div class="tab" style="padding:30px">
                                         <table class="historyTable table table-striped table-bordered dt-responsive nowrap" style="width:100%">
                                            <thead class="">
                                        <tr>
                                        <th class="address">Ticket ID</th>
                                        <th>Date & Time</th>
                                        <th>Subject</th>
                                        <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                          <?php
                                if(isset($support) && !empty($support))
                                {
                                    $a=0;
                                    $username = UserName($this->session->userdata('user_id'), $prefix.'username');
/*
                                    echo "<pre>";
                                    print_r($support);die;*/
                                    foreach(array_reverse($support) as $support_list)
                                    {
                                        $a++;
                                        if($support_list->close==0){
                                            $ticket_type = "open-black";
                                        }else{
                                            $ticket_type = "close-red";
                                        }
                                        ?>
                                        <tr>
                                            <td class="address"><?php echo $support_list->ticket_id;?></td>
                                            <td><?php echo date("m/d/Y h:i a",$support_list->created_on);?></td>
                                            <td><?php echo $support_list->subject; ?> <?php echo $support_list->close; ?></td>
                                            <td class="<?php echo $ticket_type; ?>">
                                              <?php
                                              if($support_list->close==0){
                                                echo '<a  class="btn btn-sm btn-clr-blue waves-effect waves-light"  href='.base_url().'support_reply/'.$support_list->ticket_id.'>'.$this->lang->line('Open').'</a>';
                                              }
                                              else{
                                                echo "Closed";                   
                                              }
                                              ?>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                }else{ ?>
                                     <tr>
                                        <td colspan="5">
                                            <div class="alert alert-danger text-center">No records Found!!!</div>
                                        </td>
                                     </tr>
                                <?php }
                            ?>     
                                                                               
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                  </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>  

<?php 
    $this->load->view('front/common/footer');
    ?>
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>    
<script src="https://www.google.com/recaptcha/api.js" async defer></script>    
    <script type="text/javascript">
    var base_url='<?php echo base_url();?>';
    var front_url='<?php echo front_url();?>';
    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';

    $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
        if (options.type.toLowerCase() == 'post') {
            options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
            if (options.data.charAt(0) == '&') {
                options.data = options.data.substr(1);
            }
        }
    });

    $( document ).ajaxComplete(function( event, xhr, settings ) {
        if (settings.type.toLowerCase() == 'post') {
            $.ajax({
                url: front_url+"get_csrf_token", 
                type: "GET",
                cache: false,             
                processData: false,      
                success: function(data) {

                     $("input[name="+csrfName+"]").val(data);
                }
            });
        }
    });

    function readURL4(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#support_img').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }


    $('#imgU4').click(function(){

      $("#imgInp4").trigger("click");

   });
    $("#imgInp4").change(function() {
      //document.getElementById("support_img").style.display = "block";
        readURL4(this);
    });


 $('#support_form').validate({
        rules: {
            subject: {
                required: true
            },
            message: {
                required: true
            }
        },
        messages: {
            subject: {
                required: "Please enter subject"
            },
            message: {
                required: "Please enter message"
            }
        },
        submitHandler: function(form) {
                var response = grecaptcha.getResponse(); 
               // console.log(response);

                //recaptcha failed validation
                if (response.length == 0 || response.length=='') {
                    $('#cp_error').css('display','block');
                    $('#cp_error').html('Please Verify here');
                    return false; 
                }
                //recaptcha passed validation
                else {
                    $('#cp_error').html('');
                    form.submit();
                }
                //
            }

    });
    </script>
