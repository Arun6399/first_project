<?php $this->load->view('front/user/login_header'); 
 $user_id = $this->session->userdata('user_id');
     $all_currency = $this->common_model->getTableData("currency",array("status"=>1))->result();
      if(count($all_currency))
      {
        $tot_balance = 0;
        foreach($all_currency as $cur)
        {
            $balance = getBalance($user_id,$cur->id);
            $usd_balance = $balance * $cur->online_usdprice;

            $tot_balance += $usd_balance;
        }
      }
?>
<style type="text/css">
    .file-upload-wrapper:before {

content: "Upload";

}

</style>

<div class="page-body" >
        <div class="container-xl">
          <div class="row row-deck row-cards">
            <div class="heading">

              <div class="space-10"></div>
              <h3 style="text-align: center;color: black;">Support</h3>
          </div>

          <div class="col-12 col-lg-6 offset-md-3">

            <div class="card" style="border: none;">
             
              <div class="card-body">
               <?php
                                $attributes=array('id'=>'support_form',"autocomplete"=>"off","class"=>"mt-4");
                                $action = front_url() . 'support';
                                echo form_open_multipart($action,$attributes);
                            ?> 

                 <div class="row">
                  <div class="col-12 col-md-12">
                 <!--  <div class="form-group mb-3 ">
                    <label class="form-label required">Name</label>
                    <div>
                      <input type="text" class="form-control" aria-describedby="emailHelp" placeholder="Enter your Name">

                    </div>
                  </div> -->
                 

                  <div class="form-group mb-3 ">
                    <label class="form-label required">Subject</label>
                    <div>
                      <input type="text" name="subject" name="Subject" class="form-control" aria-describedby="emailHelp" placeholder="Enter Subject">

                    </div>
                  </div>

                   <div class="form-group mb-3 ">
                    <label class="form-label required">Category</label>
                    <div>
                    <select name="category" class="form-control"  id="category">
                                                <?php foreach ($category as $category_value) { ?>
                                                        <option value="<?php echo $category_value->id; ?>"><?php echo ($category_value->name); ?></option>             
                                                <?php } ?>

                                        </select>
                    </div>
                  </div>

                    <div class="form-group mb-3 ">
                    <label class="form-label required">Comments</label>
                    <div>
                      <textarea type="textarea" class="form-control" aria-describedby="emailHelp" placeholder="Enter your Comments" style="height: 120px;"></textarea>

                    </div>
                  </div>

                  <div class="mb-3">
                    <div class="form-label">Screenshot</div>
                    <input type="file" class="form-control" placeholder="Upload File">
                  </div>
                  
                </div>


                </div>

                <div class="form-footer">
                  <a href="#" class="logibtn gradient-btn" style="background: #4890fb;color: white;padding: 8px 160px;" data-bs-toggle="modal" data-bs-target="#support">Submit</a>
                </div>


                </form>
              </div>
              
            </div>




            </div>

            </div>
          </div>
        </div>

        <?php $this->load->view('front/common/footer'); ?>