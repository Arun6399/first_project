<?php
    $this->load->view('front/user/login_header');
      $settings = $site_common['site_settings']; 
      $usermail = getUserEmail($users->id);
      $user_id = $this->session->userdata('user_id');
      $referrallink=base_url()."invite?"."ref=".$users->referralid;
?>

      <div class="page-body">
        <div class="container-xl">
          <div class="row row-deck row-cards">

          <div class="col-12">
            <div class="card-trans">
                <div class="card-body py-3">
                  <div class="row">
                    <div class="col-12 col-lg-6">
                      <div class="heading">
                       <h1 style="text-transform: none;">Invite Friends.<br>Earn Commission</h1>
					   <div class="space-40"></div>
					   <h3> Your Referral Account </h3>
					   <div class="row">
						   <div class="col-12 col-lg-9">
							   <h5>Spot</h5>
							   <div class="row">
								   <div class="col-12 col-lg-6">
									   <p style="color: rgb(176, 244, 253);">Direct/Sub Referees</p>
									   <h3>30% / 10%</h3>
								   </div>
								   <div class="col-12 col-lg-6">
									<p style="color: rgb(176, 244, 253);">Total Reward(BTC)</p>
									<h3>0</h3>
								</div>
							   </div>
						   </div>
						   <div class="col-12 col-lg-3">
							<h5>Spot</h5>
							<p style="color: rgb(176, 244, 253);">Invitation</p>
							<h3>0</h3>
						</div>
					   </div>

                    </div>
                    </div>
                    <div class="col-12 col-lg-6">
                      <div class="heading">
                        <img src="<?php echo front_img()?>ref.png">
                      </div>
                    </div>

                  </div>
                  <hr style="color: white;">

				 <div class="row">
              <div class="col-12 col-lg-8">
              	<?php 
                                    $attributes=array('id'=>'verification_form',"autocomplete"=>"off"); 
                                      $action = front_url() . 'invite';
                                    echo form_open_multipart($action,$attributes); 
                                ?>
               <div class="heading">
						<h3>My Sharing Method</h3>
						<div class="row">
							<div class="col-12 col-md-3">
								<p style="color: rgb(176, 244, 253);">Referral ID</p>
								<div class="input-icon mb-3">
									<input type="text" class="form-control" placeholder="Referral" name="code" value="<?php echo $users->referralid;?>" readonly>

								  </div>

							</div>
							<div class="col-12 col-md-9">
								<p style="color: rgb(176, 244, 253);">Referral Link</p>
								<div class="row">
									<div class="col-12 col-md-8">
										<div class="input-icon mb-3">
											<input type="text" class="form-control" id="Commision" name="Commision" placeholder="Referral" value=" ">
											
										</div>
									 <div class="form-footer">
                                                        <button type="submit" class="Neon-input-choose-btn blue">Submit</button>
                                                        
                                    </div>
                                      <?php echo form_close(); ?>
									
									</div>
									
								</div>

							</div>

						</div>
                    </div>
                    </div>
                    

                  </div>

              </div>
              </div>

            </div>
          </div>
        </div>
      </div>


    <!--community area start-->
    <div class="community-area wow fadeInUp section-padding" id="contact">
      <div class="container">
          <div class="row">
              <div class="col-12 text-center">
                  <div class="heading">
                      <h5>GReat Community</h5>
                      <div class="space-10"></div>
                      <h1>Our Community </h1>
                  </div>
              <div class="space-60"></div>
              </div>
          </div>
          <div class="row">

              <div class="col-12 col-lg d-flex justify-content-center">
                  <div class="single-community mid-social">
                      <a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a>
                  </div>

                  <div class="single-community mid-social">
                      <a class="twitter" href="#"><i class="fa fa-twitter"></i></a>
                  </div>
                  <div class="single-community mid-social">
                      <a class="youtube" href="#"><i class="fa fa-youtube-play"></i></a>
                  </div>
                  <div class="single-community mid-social">
                      <a class="facebook" href="#"><i class="fa fa-facebook"></i></a>
                  </div>
                  <div class="single-community mid-social">
                      <a class="telegram" href="#"><i class="fa fa-telegram"></i></a>
                  </div>


                  <!-- <div class="single-community">
                      <a class="dribbble" href="#"><i class="fa fa-dribbble"></i></a>
                  </div> -->
              </div>

          </div>
      </div>
  </div>
  <!--community area end-->

  <?php 
    $this->load->view('front/common/login_footer');

?>
<script type="text/javascript">
  
  $('#verification_form').validate({
      rules: {
              Commision: {
          required: true
        }
        
    },
     messages: {
               Commision: {
          required: "Please enter New Password"
        }
       
    }
}); 

</script>
