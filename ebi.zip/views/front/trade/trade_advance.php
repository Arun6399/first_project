<?php $this->load->view('front/trade/trade_header'); ?>
<?php
$lang_id = $this->session->userdata('site_lang');
if($lang_id!=''){
$title = $lang_id.'_heading';
$content = $lang_id.'_content';
}else{
$title = $site_lang.'_name';
$content = $site_lang.'_content';
}

$user_id = $this->session->userdata('user_id');
$theme_mode = $_COOKIE['theme-mode'];
$pairId = $pair_id;

$token_chart = $this->common_model->customQuery("SELECT * FROM xabits_trade_pairs WHERE id='".$pairId."'")->row();
if($token_chart->priceChangePercent>=0){
    $class1="clr-green";
    $b21 =  rtrim($token_chart->priceChangePercent,'0');
    if($b21!=0){
    $b21 = '+'.number_format(rtrim($b21,'.'),2).'%';
}
else{
    $b21 = '+0 '.'%';
}
$arrow = 'up';
}
else{
    $class1="clr-red";
    $b21 =  rtrim($token_chart->priceChangePercent,'0');
    $b21 = '-'.number_format(rtrim($b21,'.'),2).'%';
    $arrow = 'down';
}

$prefix = get_prefix();
$url = $this->uri->segment(3);
$Exp = explode('_', $url);
$First_Currency = $Exp[0];
$Second_Currency = $Exp[1];
?>
</div>
<!-- TradingView Widget END -->
<section class="main_body" id="body">
 <div class="container-fluid mtb15 no-fluid">
    <div class="row sm-gutters">
      <div class="col-md-3">
      <div class="market-pairs">
 <!--          <div class="input-group">
            <div class="input-group-prepend">
              <span class="input-group-text" id="inputGroup-sizing-sm"><i class="fa fa-search"></i></span>
            </div>
            <input type="text" class="form-control" placeholder="Search" aria-describedby="inputGroup-sizing-sm">
          </div> -->
          <ul class="nav nav-pills" role="tablist">
            <li class="nav-item">
              <a class="nav-link active" data-toggle="pill" href="#STAR" role="tab" aria-selected="true"><i class="fa fa-star"></i></a>
            </li>
            <?php if(count($pairs_currency)>0) { foreach($pairs_currency as $pairs) {
                $to_currency_det = getcryptocurrencydetail($pairs->to_symbol_id);
                $to_symbol = strtoupper($to_currency_det->currency_symbol);
                $active_assets=0;
                if ($Second_Currency==$to_symbol) {
                    $active_assets=1;
                }
                if($to_symbol !="")
                {
          ?>
          <li class="nav-item">
              <a href="<?php echo '#'.$to_symbol.'_pair';?>" data-toggle="tab" 
                  class="nav-link "><?php echo $to_symbol;?></a>
          </li>
          <?php } } } ?>
          </ul>
          <div class="tab-content">
            <div class="tab-pane fade show active" id="STAR" role="tabpanel">
              <table class="table">
                <thead>
                  <tr>
                    <th><?php echo $this->lang->line('Pairs');?></th>
                    <th><?php echo $this->lang->line('Price');?></th>
                    <th><?php echo $this->lang->line('Change');?></th>
                  </tr>
                </thead>
                <tbody >
                  <?php
                  
                  if(count($Site_Pairs)>0) { foreach($Site_Pairs as $fav) { 
                  if($fav['change'] >= 0)
                    {
                      $color = 'green';
                    }
                    else
                    {
                      $color = 'red';
                    }
                    ?>
                <tr onclick="window.location='<?=base_url('trade_advance/'.preg_replace('/[\W\s\/]+/', '_',$fav['currency_pair']) )?>'">
                    <td> <?php echo $fav['currency_pair'];?></td>
                    <td ><?php echo number_format($fav['price'],8);?></td>
                    <td class="<?php echo $color;?> change_val"><?php echo number_format($fav['change'],2).'%';?></td>
                </tr>
                <?php } } ?>
               </tbody>
              </table>
            </div>
          <?php if(count($pairs_currency)>0) { foreach($pairs_currency as $pairs1) { 
                            $to_cur_det  = getcryptocurrencydetail($pairs1->to_symbol_id);
                            $to_sym = strtoupper($to_cur_det->currency_symbol);
                            $to_id = $to_cur_det->id;
                            $act_assets=0;
                            if ($Second_Currency==$to_sym) {
                                $act_assets=1;
                            }
                            else
                            {
                              $act_assets=0;
                            }
                          ?>
            <div class="tab-pane fade " id="<?php echo $to_sym.'_pair';?>" role="tabpanel">
              <table class="table" id="pair_<?php echo strtolower($to_sym);?>">
                <thead>
                  <tr>
                    <th><?php echo $this->lang->line('Pairs');?></th>
                    <th><?php echo $this->lang->line('Price');?></th>
                    <th><?php echo $this->lang->line('Change');?></th>
                  </tr>
                </thead>
                <tbody class="pair_<?php echo $to_sym;?>">
                <?php 
                $pairs_from = $this->common_model->customQuery("select * from xabits_trade_pairs where to_symbol_id='".$to_id."' and status = 1")->result();
                $i=1;
                if(count($pairs_from)>0) { foreach($pairs_from as $pairss) {
                $pairs_id = $pairss->id;
                $coin_price = tradeprice($pairs_id);
                $from_curr_dets = getcryptocurrencydetail($pairss->from_symbol_id);
                $to_curr_dets = getcryptocurrencydetail($pairss->to_symbol_id);
                $per_24hrs = pricechangepercent($pairs_id);
                $volumes = volume($pairs_id);
                $pairurl = $from_curr_dets->currency_symbol."_".$to_curr_dets->currency_symbol;
                if($per_24hrs >= 0)
                {
                  $color = 'green';
                }
                else
                {
                  $color = 'red';
                } ?>
                  <tr onclick="window.location='<?=base_url();?>trade_advance/<?php echo $pairurl?>'" style="cursor: pointer;">
                    <td><?php echo $from_curr_dets->currency_symbol.'/'.$to_curr_dets->currency_symbol;?></td>
                    <td><?php echo number_format($coin_price,8);?></td>
                    <td class="<?php echo $color;?>"><?php echo number_format($per_24hrs,2)."%";?></td>
                  </tr>
                  <?php $i++; } } ?>

                </tbody>
              </table>
            </div>
            <?php } } ?>
          </div>
        </div>
          <div class="market-history">
          <ul class="nav nav-pills" role="tablist">
            <li class="nav-item">
              <a class="nav-link active" data-toggle="pill" href="#recent-trades" role="tab" aria-selected="true"><?php echo $this->lang->line('Recent Trades');?></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-toggle="pill" href="#market-depth" role="tab" aria-selected="false"><?php echo $this->lang->line('Market Depth');?></a>
            </li>
          </ul>
          <div class="tab-content">
            <div class="tab-pane fade show active" id="recent-trades" role="tabpanel">
              <table class="table" id="market_trade_table" style="width: 100%;">
                <thead>
                  <tr>
                    <th style="width: 60px !important";><?php echo $this->lang->line('Amount');?></th>
                    <th style="width: 60px !important";><?php echo $this->lang->line('Price');?>(BTC)</th>
                    <th style="width: 28px !important";><?php echo $this->lang->line('Type');?></th>
                  </tr>
                </thead>
                <tbody class="market_trade"> 
                </tbody>
              </table>
            </div>
            <div class="tab-pane fade" id="market-depth" role="tabpanel">
            <div class="depth-chart-container">
                <div class="depth-chart-inner">
                  <div id="darkDepthChart"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-6">
           <div class="col-lg-12">
                            <div class="p-1">
                                <div class="currency_details d-flex align-items-center justify-content-between mb-2">
                                   
                                    <ul class="currency_status" id="<?=($theme_mode=='dark')?'dark-list':'light-list'?>">
                                        <li>
                                            <h5>Last Price
                                                <span class="text-green trade_price"><?php echo $token_chart->lastPrice;?></span></h5>
                                        </li>
                                        <li>
                                            <h5>24h Change
                                                <?php
                                                if($token_chart->priceChangePercent>=0){
                                                    $Cls='green';
                                                }
                                                else{
                                                    $Cls='red';
                                                }
                                                ?>
                                                <span id="change" class="<?php echo $Cls;?>" ><?php echo number_format($token_chart->priceChangePercent,2);?>%</span></h5>
                                        </li>
                                        <li>
                                            <h5>24h High
                                                <span id="high"><?php echo TrimTrailingZeroes($token_chart->change_high);?></span></h5>
                                        </li>
                                        <li>
                                            <h5>24h Low
                                                <span id="low"><?php echo TrimTrailingZeroes($token_chart->change_low);?></span></h5>
                                        </li>
                                        <li>
                                            <h5>24h Volume
                                                <span id="volume"><?php echo TrimTrailingZeroes($token_chart->volume);?></span></h5>
                                        </li>
                                    </ul>
                                    
                                </div>
                            </div>
                        </div>
        <div class="main-chart mb15">
          <!-- TradingView Widget BEGIN -->
          <div class="tradingview-widget-container">
            <div id="tv_container_chart"></div>
            
          </div>
          <!-- TradingView Widget END -->
        </div>
        <div class="market-trade">
          <ul class="nav nav-pills" role="tablist">
            <li class="nav-item">
              <a class="nav-link active" data-toggle="pill" href="#pills-trade-limit" role="tab" aria-selected="true"><?php echo $this->lang->line('Limit');?></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-toggle="pill" href="#pills-market" role="tab" aria-selected="false"><?php echo $this->lang->line('Market');?></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-toggle="pill" href="#pills-stop-limit" role="tab" aria-selected="false"><?php echo $this->lang->line('Stop');?>
                </a>
            </li>
          </ul>
          <div class="tab-content">
            <div class="tab-pane fade active show" id="pills-trade-limit" role="tabpanel">
              <div class="d-flex justify-content-between">
              <input type="hidden" class="tradeactions" id="tradeactions" value="limit"/>
                <div class="market-trade-buy">
                <div class="input-group">
                    <input type="number" class="form-control" placeholder="<?php echo $this->lang->line('Amount');?>" name="limit_buy_amount" id="limit_buy_amount" onkeyup="calculation('buy','limit')">
                    <div class="input-group-append">
                      <span class="input-group-text"><?php echo $this->lang->line('Amount');?></span>
                    </div>
                  </div>
                  <div class="input-group">
                    <input type="number" class="form-control" name="limit_buy_price" id="limit_buy_price" onkeyup="calculation('buy','limit')" placeholder="<?php echo $this->lang->line('Price');?>">
                    <div class="input-group-append">
                      <span class="input-group-text"><?php echo $this->lang->line('Price');?></span>
                    </div>
                  </div>
               
                  <ul class="market-trade-list">
                  <li><a href="javascript:void(0);" onclick="change_buytrade('buy','25','limit');">25%</a></li>
                  <li><a href="javascript:void(0);" onclick="change_buytrade('buy','50','limit');">50%</a></li>
                  <li><a href="javascript:void(0);" onclick="change_buytrade('buy','75','limit');">75%</a></li>
                  <li><a href="javascript:void(0);" onclick="change_buytrade('buy','100','limit');">100%</a></li>
                  </ul>
                  <div class="input-group">
                    <input type="number" class="form-control" placeholder="" name="limit_buy_tot" id="limit_buy_tot">
                    <div class="input-group-append">
                      <span class="input-group-text"><?php echo $this->lang->line('Total');?></span>
                    </div>
                  </div>
                  <p><?php echo $this->lang->line('Buy');?> (<?=$First_Currency?>) : <span class="buy_bal"><?=$to_cur?> <?=$Second_Currency?></span></p>
                  <p><?php echo $this->lang->line('Fee');?>: <span><?php echo TrimTrailingZeroes($this->maker);?>%</span></p>
                  <?php
                if(isset($user_id) && !empty($user_id)){
                ?>
                <button type="button" class="btn buy" id="buy_btn" onclick="order_placed('buy','limit')"><?php echo $this->lang->line('Buy');?></button>
                <?php
            }
            else{
                ?>
                <button type="button" class="btn buy" onclick="location.href = '<?php echo base_url();?>login';"><?php echo $this->lang->line('Login');?></button>
                <?php
            }
                ?>
 <input type="hidden" id="buy_order_type" name="buy_order_type" value="limit"/>
<input type="hidden" name="current_currency" id="current_currency" value="<?php echo $Second_Currency; ?>">
<input type="hidden" id="from_currency_value" name="from_currency_value" value="<?php echo str_replace(",","",$from_cur);?>">
<input type="hidden" id="to_currency_value" name="to_currency_value" value="<?php echo str_replace(",","",$to_cur);?>">
                </div>
                <div class="market-trade-sell">
                  <div class="input-group">
                    <input type="number" class="form-control" name="limit_sell_amount" id="limit_sell_amount" onkeyup="calculation('sell','limit')" placeholder="<?php echo $this->lang->line('Amount');?>">
                    <div class="input-group-append">
                      <span class="input-group-text"><?php echo $this->lang->line('Amount');?></span>
                    </div>
                  </div>
                  <div class="input-group">
                    <input type="number" class="form-control" name="limit_sell_price" id="limit_sell_price" onkeyup="calculation('sell','limit')" placeholder="<?php echo $this->lang->line('Price');?>">
                    <div class="input-group-append">
                      <span class="input-group-text"><?php echo $this->lang->line('Price');?></span>
                    </div>
                  </div>
                  <ul class="market-trade-list">
                  <li><a href="javascript:void(0);" onclick="change_selltrade('sell','25','limit');">25%</a></li>
                  <li><a href="javascript:void(0);" onclick="change_selltrade('sell','50','limit');">50%</a></li>
                  <li><a href="javascript:void(0);" onclick="change_selltrade('sell','75','limit');">75%</a></li>
                  <li><a href="javascript:void(0);" onclick="change_selltrade('sell','100','limit');">100%</a></li>
                  </ul>
                  <div class="input-group">
                    <input type="number" class="form-control" placeholder="" name="limit_sell_tot" id="limit_sell_tot">
                    <div class="input-group-append">
                      <span class="input-group-text"><?php echo $this->lang->line('Total');?></span>
                    </div>
                  </div>
                  <p><?php echo $this->lang->line('Sell');?> (<?php echo $First_Currency;?>) : <span class="sell_bal"><?=$from_cur?> <?=$First_Currency?></span></p>
                  <p><?php echo $this->lang->line('Fee');?>: <span><?php echo TrimTrailingZeroes($this->taker);?>%</span></p>
                  <?php
                if(isset($user_id) && !empty($user_id)){
                ?>
                <button type="button" class="btn sell" id="sell_btn" onclick="order_placed('sell','limit')"><?php echo $this->lang->line('Sell');?></button>
                <?php
            }
            else{
                ?>
                <button type="button" class="btn sell" onclick="location.href = '<?php echo base_url();?>login';"><?php echo $this->lang->line('Login');?></button>
                <?php
            }
                ?>
                </div>
              </div>
            </div>
            <div class="tab-pane fade" id="pills-market" role="tabpanel">
              <div class="d-flex justify-content-between">
                <div class="market-trade-buy">
                <div class="input-group">
                    <input type="number" class="form-control" placeholder="<?php echo $this->lang->line('Amount');?>" name="instant_buy_amount" id="instant_buy_amount" onkeyup="calculation('buy','instant')">
                    <div class="input-group-append">
                      <span class="input-group-text"><?php echo $this->lang->line('Amount');?></span>
                    </div>
                  </div>
                  <div class="input-group">
                    <input type="number" class="form-control" placeholder="<?php echo $this->lang->line('Price');?>" name="instant_buy_price" readonly="rr" id="instant_buy_price" value="<?php echo $token_chart->lastPrice;?>">
                    <div class="input-group-append">
                      <span class="input-group-text"><?php echo $this->lang->line('Price');?></span>
                    </div>
                  </div>
                  <ul class="market-trade-list">
                    <li><a href="javascript:void(0);" onclick="change_buytrade('buy','25','instant');">25%</a></li>
                    <li><a href="javascript:void(0);" onclick="change_buytrade('buy','50','instant');">50%</a></li>
                    <li><a href="javascript:void(0);" onclick="change_buytrade('buy','75','instant');">75%</a></li>
                    <li><a href="javascript:void(0);" onclick="change_buytrade('buy','100','instant');">100%</a></li>
                  </ul>
                  <div class="input-group">
                    <input type="number" class="form-control" placeholder="" name="instant_buy_tot" id="instant_buy_tot">
                    <div class="input-group-append">
                      <span class="input-group-text"><?php echo $this->lang->line('Total');?></span>
                    </div>
                  </div>
                  <p><?php echo $this->lang->line('Buy');?> (<?=$First_Currency?>) : <span class="buy_bal"><?=$to_cur?> <?=$Second_Currency?></span></p>
                  <p><?php echo $this->lang->line('Fee');?>: <span><?php echo TrimTrailingZeroes($this->maker);?>%</span></p>
                  <?php
                if(isset($user_id) && !empty($user_id)){
                ?>
                  <button type="button" class="btn buy" id="buy_btn" onclick="order_placed('buy','instant')"><?php echo $this->lang->line('Buy');?></button>
                  <?php
              }
              else{
                  ?>
                  <button type="button" class="btn buy" onclick="location.href = '<?php echo base_url();?>login';"><?php echo $this->lang->line('Login');?></button>
                  <?php
              }
                  ?>
                <input type="hidden" id="buy_order_type" name="buy_order_type" value="instant"/>
                <input type="hidden" name="current_currency" id="current_currency" value="<?php echo $Second_Currency; ?>">
                <input type="hidden" id="from_currency_value" name="from_currency_value" value="<?php echo str_replace(",","",$from_cur);?>">
                <input type="hidden" id="to_currency_value" name="to_currency_value" value="<?php echo str_replace(",","",$to_cur);?>">
                </div>
                <div class="market-trade-sell">
                <div class="input-group">
                    <input type="number" class="form-control" name="instant_sell_amount" id="instant_sell_amount" onkeyup="calculation('sell','instant')" placeholder="<?php echo $this->lang->line('Amount');?>">
                    <div class="input-group-append">
                      <span class="input-group-text"><?php echo $this->lang->line('Amount');?></span>
                    </div>
                  </div>
                  <div class="input-group">
                    <input type="number" class="form-control" placeholder="<?php echo $this->lang->line('Price');?>" name="instant_sell_price" id="instant_sell_price" readonly="rdr" value="<?php echo $token_chart->lastPrice;?>">
                    <div class="input-group-append">
                      <span class="input-group-text"><?php echo $this->lang->line('Price');?></span>
                    </div>
                  </div>
                  <ul class="market-trade-list">
                    <li><a  href="javascript:void(0);" onclick="change_selltrade('sell','25','instant');">25%</a></li>
                    <li><a href="javascript:void(0);" onclick="change_selltrade('sell','50','instant');">50%</a></li>
                    <li><a href="javascript:void(0);" onclick="change_selltrade('sell','75','instant');">75%</a></li>
                    <li><a href="javascript:void(0);" onclick="change_selltrade('sell','100','instant');">100%</a></li>
                  </ul>
                  <div class="input-group">
                    <input type="number" class="form-control" placeholder="" name="instant_sell_tot" id="instant_sell_tot">
                    <div class="input-group-append">
                      <span class="input-group-text"><?php echo $this->lang->line('Total');?></span>
                    </div>
                  </div>
                  <p><?php echo $this->lang->line('Sell');?> (<?php echo $First_Currency;?>) : <span class="sell_bal"><?=$from_cur?> <?=$First_Currency?></span></p>
                  <p><?php echo $this->lang->line('Fee');?>: <span><?php echo TrimTrailingZeroes($this->taker);?>%</span></p>
                  <?php
                if(isset($user_id) && !empty($user_id)){
                ?>
                <button type="button" class="btn sell" id="sell_btn" onclick="order_placed('sell','instant')"><?php echo $this->lang->line('Sell');?></button>
                <?php
            }
            else{
                ?>
                <button type="button" class="btn sell" onclick="location.href = '<?php echo base_url();?>login';"><?php echo $this->lang->line('Login');?></button>
                <?php
            }
                ?>
                </div>
              </div>
            </div>
            <div class="tab-pane fade" id="pills-stop-limit" role="tabpanel">
              <div class="d-flex justify-content-between">
                <div class="market-trade-buy">
                  <div class="input-group">
                    <input type="number" class="form-control" placeholder="<?php echo $this->lang->line('Amount');?>" name="stop_buy_amount" id="stop_buy_amount" onkeyup="calculation('buy','stop')">
                    <div class="input-group-append">
                      <span class="input-group-text"><?php echo $this->lang->line('Amount');?></span>
                    </div>
                  </div>
                  <div class="input-group">
                    <input type="number" class="form-control" placeholder="<?php echo $this->lang->line('Price');?>" name="stop_buy_price" id="stop_buy_price" onkeyup="calculation('buy','stop')">
                    <div class="input-group-append">
                      <span class="input-group-text"><?php echo $this->lang->line('Price');?></span>
                    </div>
                  </div>
                  <div class="input-group">
                    <input type="number" class="form-control" placeholder="" name="stop_buy_tprice" id="stop_buy_tprice" onkeyup="calculation('buy','stop')">
                    <div class="input-group-append">
                      <span class="input-group-text"><?php echo $this->lang->line('Trigger Price');?></span>
                    </div>
                  </div>
                  <ul class="market-trade-list">
                  <li><a href="javascript:void(0);" onclick="change_buytrade('buy','25','stop');">25%</a></li>
                  <li><a href="javascript:void(0);" onclick="change_buytrade('buy','50','stop');">50%</a></li>
                  <li><a href="javascript:void(0);" onclick="change_buytrade('buy','75','stop');">75%</a></li>
                  <li><a href="javascript:void(0);" onclick="change_buytrade('buy','100','stop');">100%</a></li>
                  </ul>
                  <div class="input-group">
                    <input type="number" class="form-control" placeholder="" name="stop_buy_tot" id="stop_buy_tot">
                    <div class="input-group-append">
                      <span class="input-group-text"><?php echo $this->lang->line('Total');?></span>
                    </div>
                  </div>
                  <p><?php echo $this->lang->line('Buy');?> (<?=$First_Currency?>) : <span class="buy_bal"><?=$to_cur?> <?=$Second_Currency?></span></p>
                  <p><?php echo $this->lang->line('Fee');?>: <span><?php echo TrimTrailingZeroes($this->maker);?>%</span></p>
                  <?php
                if(isset($user_id) && !empty($user_id)){
                ?>
                <button type="button" class="btn buy" id="buy_btn" onclick="order_placed('buy','stop')"><?php echo $this->lang->line('Buy');?></button>
                <?php
            }
            else{
                ?>
                <button type="button" class="btn buy" onclick="location.href = '<?php echo base_url();?>login';"><?php echo $this->lang->line('Login');?></button>
                <?php
            }
                ?>
                <input type="hidden" id="buy_order_type" name="buy_order_type" value="stop"/>
                </div>
                <div class="market-trade-sell">
                  <div class="input-group">
                    <input type="number" class="form-control" placeholder="<?php echo $this->lang->line('Amount');?>"  name="stop_sell_amount" id="stop_sell_amount" onkeyup="calculation('sell','stop')">
                    <div class="input-group-append">
                      <span class="input-group-text"><?php echo $this->lang->line('Amount');?></span>
                    </div>
                  </div>
                  <div class="input-group">
                    <input type="number" class="form-control" placeholder="<?php echo $this->lang->line('Price');?>" name="stop_sell_price" id="stop_sell_price" onkeyup="calculation('sell','stop')">
                    <div class="input-group-append">
                      <span class="input-group-text"><?php echo $this->lang->line('Price');?></span>
                    </div>
                  </div>
                  <div class="input-group">
                    <input type="number" class="form-control" placeholder="" name="stop_sell_tprice" id="stop_sell_tprice" onkeyup="calculation('sell','stop')">
                    <div class="input-group-append">
                      <span class="input-group-text"><?php echo $this->lang->line('Trigger Price');?></span>
                    </div>
                  </div>
                  <div class="input-group">
                    <input type="number" class="form-control" placeholder="" name="stop_sell_tot" id="stop_sell_tot" >
                    <div class="input-group-append">
                      <span class="input-group-text"><?php echo $this->lang->line('Total');?></span>
                    </div>
                  </div>
                  <ul class="market-trade-list">
                  <li><a href="javascript:void(0);" onclick="change_selltrade('sell','25','stop');">25%</a></li>
                  <li><a href="javascript:void(0);" onclick="change_selltrade('sell','50','stop');">50%</a></li>
                  <li><a href="javascript:void(0);" onclick="change_selltrade('sell','75','stop');">75%</a></li>
                  <li><a href="javascript:void(0);" onclick="change_selltrade('sell','100','stop');">100%</a></li>
                  </ul>
                  <p><?php echo $this->lang->line('Sell');?> (<?php echo $First_Currency;?>) : <span class="sell_bal"><?=$from_cur?> <?=$First_Currency?></span></p>
                  <p><?php echo $this->lang->line('Fee');?>: <span><?php echo TrimTrailingZeroes($this->taker);?>%</span></p>
                  <?php
                if(isset($user_id) && !empty($user_id)){
                ?>
                <button type="button" class="btn sell"  onclick="order_placed('sell','stop')"><?php echo $this->lang->line('Sell');?></button>
                <?php
            }
            else{
                ?>
                <button type="button" class="btn sell" onclick="location.href = '<?php echo base_url();?>login';"><?php echo $this->lang->line('Login');?></button>
                <?php
            }
                ?>
                <input type="hidden" id="buy_order_type" name="buy_order_type" value="stop"/>
                </div>
              </div>
            </div>
           
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="order-book1 mb15">
          <h2 class="heading"><?php echo $this->lang->line('Order Book');?></h2>
          <table class="table order_table">
            <thead>
              <tr>
              <th><?php echo $this->lang->line('Price');?>(<?=$First_Currency?>)</th>
                <th><?php echo $this->lang->line('Amount');?>(<?=$Second_Currency?>)</th>
                <th><?php echo $this->lang->line('Total');?>(<?=$Second_Currency?>)</th>
              </tr>
            </thead>
            <tbody class="sell_order">
            </tbody>
                 <tbody class="ob-heading">
                <tr>
                    <td class="text-center">
                   <span><?php echo $this->lang->line('BUY');?>  <?php echo $this->lang->line('Orders');?></span>
                    <span style="color: #26de81;"><?php echo $token_chart->lastPrice;?> <i class="fa fa-long-arrow-alt-up"></i>
                      <small style="color:<?=($theme_mode=='dark')?'#fff;':'#000;'?>"><?php echo $token_chart->lastPrice;?></small>
                    </span>
                    </td>
                    
                </tr>
          </tbody>
          
    <tbody class="buy_order">
           </tbody>
          </table>
        </div>
       <!--  <div class="market-history">
          <ul class="nav nav-pills" role="tablist">
            <li class="nav-item">
              <a class="nav-link active" data-toggle="pill" href="#recent-trades" role="tab" aria-selected="true"><?php echo $this->lang->line('Recent Trades');?></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-toggle="pill" href="#market-depth" role="tab" aria-selected="false"><?php echo $this->lang->line('Market Depth');?></a>
            </li>
          </ul>
          <div class="tab-content">
            <div class="tab-pane fade show active" id="recent-trades" role="tabpanel">
              <table class="table" id="market_trade_table" style="width: 100%;">
                <thead>
                  <tr>
                    <th><?php echo $this->lang->line('Time');?></th>
                    <th><?php echo $this->lang->line('Price');?>(BTC)</th>
                    <th><?php echo $this->lang->line('Amount');?>(ETH)</th>
                  </tr>
                </thead>
                <tbody class="market_trade"> 
                </tbody>
              </table>
            </div>
            <div class="tab-pane fade" id="market-depth" role="tabpanel">
            <div class="depth-chart-container">
                <div class="depth-chart-inner">
                  <div id="darkDepthChart"></div>
                </div>
              </div>
            </div>
          </div>
        </div> -->
      </div>
      <div class="col-md-3">
        <div class="market-news mt15">
          <h2 class="heading"><?php echo $this->lang->line('Market News');?></h2>
          <ul>
          <?php foreach($news as $news_content){?>
        <li><a href="#!">
        <strong><?php echo $news_content->$title;?></strong>
        <?php echo $news_content->$content;?>
        <span><?php echo date("Y-m-d h:i:s", $news_content->created);?></span>
        </a></li>
        <?php } ?>
    </ul>
        </div>
      </div>
      <div class="col-md-9">
        <div class="market-history market-order mt15">
          <ul class="nav nav-pills" role="tablist">
            <li class="nav-item">
              <a class="nav-link active" data-toggle="pill" href="#open-orders" role="tab" aria-selected="true"><?php echo $this->lang->line('Open Orders');?></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-toggle="pill" href="#order_history" role="tab" aria-selected="true"><?php echo $this->lang->line('Order History');?></a>
            </li>
          </ul>
          <div class="tab-content" style="overflow: auto;">
            <div class="tab-pane fade show active" id="open-orders" role="tabpanel">
            <table class="table">
            <thead><tr style="float:none;">
            <th><?php echo $this->lang->line('Date');?></th>
            <th><?php echo $this->lang->line('Pair');?></th>
            <th><?php echo $this->lang->line('Type');?></th>
            <th><?php echo $this->lang->line('Price');?></th>
            <th><?php echo $this->lang->line('Amount');?></th>
            <th><?php echo $this->lang->line('Total');?></th>
            <th> <?php echo $this->lang->line('Cancel');?> </th>
            </tr></thead>
            <tbody class="open_orders">
            </tbody>
          </table>

            </div>
               <div class="tab-pane fade" id="order_history" role="tabpanel">
            <table class="table">
            <thead><tr>
            <th><?php echo $this->lang->line('Date');?></th>
            <th><?php echo $this->lang->line('Pair');?></th>
            <th><?php echo $this->lang->line('Type');?></th>
            <th><?php echo $this->lang->line('Price');?></th>
            <th><?php echo $this->lang->line('Amount');?></th>
            <th><?php echo $this->lang->line('Total');?></th>
            <th> <?php echo $this->lang->line('Status');?> </th>
            </tr></thead>
            <tbody class="transactionhistory">
            </tbody>
          </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<?php $this->load->view('front/trade/trade_footer'); ?>
