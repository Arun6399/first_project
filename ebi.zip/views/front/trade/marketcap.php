<?php $this->load->view('front/trade/trade_header'); ?>
<?php
$user_id = $this->session->userdata('user_id');
$all_currency = $this->common_model->getTableData("currency",array("status"=>1))->result();
if(count($all_currency))
{
  $tot_balance = 0;
  foreach($all_currency as $cur)
  {
      $balance = getBalance($user_id,$cur->id);
      $usd_balance = $balance * $cur->online_usdprice;

      $tot_balance += $usd_balance;
  }
}
?>
<div class="markets-capital pt70 pb40">
    <div class="container">
      <div class="row">
        <input type="hidden" id="mode" value="<?=($theme_mode=='dark')?'Dark':'Light'?>">
         <?php
             $chart_array_data = array();

                  if(isset($pairs) && !empty($pairs)){
                          foreach($pairs as $pair_details ){
                            
                  $from_currency = $this->common_model->getTableData('currency',array('id' => $pair_details->from_symbol_id))->row();
                  $to_currency = $this->common_model->getTableData('currency',array('id' => $pair_details->to_symbol_id))->row();
                  $pair_symbol = $from_currency->currency_symbol.'/'.$to_currency->currency_symbol;
                  $pair_url = $from_currency->currency_symbol.'_'.$to_currency->currency_symbol;
                  $chart_array_data[] = array('pair_url'=>$pair_url,'last_price'=>TrimTrailingZeroes($pair_details->lastPrice));
                  $currency = getcryptocurrencydetail($from_currency->id);
                  if(isset($from_currency) && isset($to_currency)){?>
        <div class="col-md-4">
          <div class="markets-container">
            <div class="markets-content">
              <h2><?=$pair_symbol?></h2>
              <p><?php echo TrimTrailingZeroes($pair_details->lastPrice);?></p>
              <span class="<?php echo($pair_details->priceChangePercent>0)?'green':'red';?>"><?php echo number_format($pair_details->priceChangePercent,2);   ?>%</span>
            </div>
            <div class="markets-chart">
            <div id="marketsChart<?=$pair_url?><?=($theme_mode=='dark')?'Dark':'Light'?>"></div>
            </div>
          </div>
        </div>
        <?php  } } } ?>
                <input type="hidden" id="chart_data" value='<?=json_encode($chart_array_data)?>'>
      </div>
    </div>
  </div>
<?php 
$lang_id = $this->session->userdata('site_lang');
$title = $lang_id.'_title';
$content = $lang_id.'_content';

$site_common = site_common();
$copy_right = $site_common['site_settings']->copy_right_text;
$from_currency_id = $this->common_model->customQuery("select * from xabits_currency where currency_symbol='".$pair[0]."'")->row('id');
$to_currency_id = $this->common_model->customQuery("select * from xabits_currency where currency_symbol='".$pair[1]."'")->row('id');
if ($this->user_id != 0) {
  $from_cur = to_decimal($this->user_balance[$pair_details->from_symbol_id], 8);
  $to_cur = to_decimal($this->user_balance[$pair_details->to_symbol_id], 8);
} else {
  $from_cur = 0;
  $to_cur = 0;
}
  $url = $this->uri->segment(2);
    $Exp = explode('_', $url);
    $First_Currency = $Exp[0];
    $Second_Currency = $Exp[1];
?>
</body>
<!--jquery-->
<script src="<?php echo front_js();?>jquery-3.4.1.min.js"></script>

<!--popper-->
<script src="<?php echo front_js();?>popper.min.js"></script>

<!--bootstrap-->
<script src="<?php echo front_js();?>bootstrap.min.js"></script>

<!--owl-carousel-->
<script src="<?php echo front_js();?>owl.carousel.min.js"></script>

<!--jquery cookie-->
<script src="<?php echo front_js();?>jquery-cookie.js"></script>

<!--bootstrap-select-->
<script src="<?php echo front_js();?>bootstrap-select.min.js"></script>
<!-- <script src="<?php echo front_js();?>jquery.mCustomScrollbar.js"></script> -->
<script src="<?php echo front_js();?>amcharts-core.min.js"></script>
  <script src="<?php echo front_js();?>amcharts.min.js"></script>
  <script src="<?php echo front_js();?>Chart.bundle.min.js"></script>
  <script src="<?php echo front_js();?>custom.js"></script>
  <script src="<?php echo front_js();?>toastr.min.js"></script>

<!--datatables-->
<script type="text/javascript" src="<?php echo front_js();?>datatables.min.js"></script>
<script>
            $('.trade-loader').hide();
          var mode = '<?=($_COOKIE['theme-mode']=='dark-mode')?'dark':'light'?>';
    function toggleDarkLight() {
      document.cookie = "theme-mode=NULL";
       if(document.getElementsByTagName('body')[0].id=='light'){
       document.cookie = "theme-mode=dark";
       // tradingview_chart('chart_library_dark','#181B1F');
      location.reload();
      } 
      else if(document.getElementsByTagName('body')[0].id=='dark'){
        document.cookie = "theme-mode=light";
        // tradingview_chart('chart_library','#FFF');
        location.reload();
}


    }
var chart_data = JSON.parse($('#chart_data').val());
var mode = $('#mode').val();
if(chart_data){
  $.each(chart_data, function(key, value) { 
    if(parseInt(value.last_price)>0){
      var color = '#00cc93';
    }else{
      var color = '#ff231f';
    }

  if (document.getElementById('marketsChart'+value.pair_url+mode)) {
          var chartData = [];
          var dynamicChartData = [];
          // current date

          // and generate 500 data items
    fetch(`<?=base_url()?>newtradechart_check/`+value.pair_url)
            .then(res => res.json())
            .then(data => {
              var i = 0;
              var prices = 0;
              var datetime = data['t'];
               var count = datetime.length;
                var value = data['c'];
                var time_data = [];
                 while (i < count) {
                  dynamicChartData.push({
              date: unixTime(datetime[i]),
              prices: value[i],
            });
                i++;
            }
          amdynamicChart(dynamicChartData);
        // return dynamicChartData;
            }) 

function amdynamicChart(object){
      am4core.ready(function () {

        // Create chart
        var chart = am4core.create('marketsChart'+value.pair_url+mode, am4charts.XYChart);
    
        chart.data = object;
        var dateAxis = chart.xAxes.push(new am4charts.DateAxis());
        dateAxis.baseInterval = {
          timeUnit: 'minute',
          count: 1,
        };
        dateAxis.tooltip.disabled = true;
        dateAxis.renderer.grid.template.disabled = true;
        dateAxis.renderer.labels.template.disabled = true;
        dateAxis.renderer.ticks.template.disabled = true;
        dateAxis.renderer.paddingBottom = 15;
  
        var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
        valueAxis.tooltip.disabled = true;
        valueAxis.renderer.grid.template.disabled = true;
        valueAxis.renderer.labels.template.disabled = true;
        valueAxis.renderer.ticks.template.disabled = true;
  
        var series = chart.series.push(new am4charts.LineSeries());
        series.dataFields.dateX = 'date';
        series.dataFields.valueY = 'prices';
        series.tooltipText = 'prices: [bold]{valueY}[/]';
        series.fillOpacity = 0.1;
        series.fill = am4core.color(color);
        series.stroke = am4core.color(color);
        series.tooltip.getFillFromObject = false;
        series.tooltip.background.fill = am4core.color('#2a2e39');
        series.tooltip.background.stroke = am4core.color('#2a2e39');
  
        chart.cursor = new am4charts.XYCursor();
        chart.cursor.lineY.opacity = 1;
        dateAxis.start = 0;
        dateAxis.keepSelection = true;
        chart.zoomOutButton.background.fill = am4core.color(
          'rgba(0, 0, 0, 0.09)'
        );
        chart.zoomOutButton.icon.stroke = am4core.color('rgba(0, 0, 0, 0.40)');
        chart.zoomOutButton.background.states.getKey(
          'hover'
        ).properties.fill = am4core.color('#00cc93');
      });
      }

    }
});
}
function unixTime(unixtime) {

var u = new Date(unixtime*1000);
return u;
};


    </script>
</body>

</html>