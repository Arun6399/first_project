  <?php

$user_id = $this->session->userdata('user_id');
$site_common = site_common();
$site_name = $site_common['site_settings']->site_name;
$Logo = $site_common['site_settings']->site_logo;
$DarkLogo = $site_common['site_settings']->site_dark_logo;
$fav_icon = $site_common['site_settings']->site_favicon;
$users = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
$theme_mode = $_COOKIE['theme-mode'];
$trade_pairs = $this->common_model->customQuery("SELECT * FROM xabits_trade_pairs WHERE id='".$pair_id."'")->row();
 $from_currency_det  = getcryptocurrencydetail($trade_pairs->from_symbol_id);
  $to_currency_det  = getcryptocurrencydetail($trade_pairs->to_symbol_id);
?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>xabits</title>

    <!-- Favicons -->
  <link href="<?php echo $fav_icon;?>" rel="icon">
  

    <!-- <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>bootstrap.min.css" /> -->

    <!-- <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>animate.min.css" /> -->
    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>hover-min.css" />

     <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>owl.carousel.min.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>owl.theme.default.min.css" />

    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>fontawesome-all.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>flag-icon.css" />

    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>datatables.min.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>toastr.min.css" />



    <link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Rajdhani:300,400,500,600,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i"
        rel="stylesheet">
  
     <link rel="icon" type="image/png" href="<?php echo $favicon;?>" />

    <title><?php if($meta_content): echo $meta_content->$title; else: echo 'xabits'; endif;?></title>
    <!-- CSS Files -->
    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>home_two/base-style.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>home_two/style.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>toastr.min.css" />
    <link rel="stylesheet" href="<?php echo front_css();?>style_home.css">
    <link rel="stylesheet" href="<?php echo front_css();?>ionicons.min.css">
    <link rel="stylesheet" href="<?php echo front_css();?>font-awesome.min.css" >



   
    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>style_trade.css" />
</head>

<body id="<?=($theme_mode=='dark')?'dark':'light'?>">
<div class="trade-loader">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="loader">
                    <div class="loader-inner"></div>
                    <div class="loader-inner"></div>
                    <div class="loader-inner"></div>
                    <div class="loader-inner"></div>
                    <div class="loader-inner"></div>
                    <div class="loader-circle"></div>
                </div>
            </div>
        </div>
    </div>
</div>



<header class="header_wrap fixed-top">
  <div class="container-fluid">
    <nav class="navbar navbar-expand-lg"> 
       <a class="navbar-brand" href="<?php echo base_url();?>home"><img src="<?=$Logo?>" alt="logo" width="100px";></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#headerMenu" aria-controls="headerMenu" aria-expanded="false" aria-label="Toggle navigation">
        <i class="icon ion-md-menu"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav m-auto">
                    <li class="dropdown animation" data-animation="fadeInDown" data-animation-delay="1.1s">
            <a  class="nav-link page-scroll nav_item" href="<?=base_url('home')?>">Home</a>
            
                    </li>
                   
                    <li class="animation" data-animation="fadeInDown" data-animation-delay="1.2s"><a class="nav-link page-scroll nav_item" href="<?=base_url('cms/about-us')?>">About Us</a></li>
                 
                    <li class="dropdown animation" data-animation="fadeInDown" data-animation-delay="1.1s">
            <a  class="nav-link page-scroll nav_item" href="<?=base_url('market')?>">MARKET</a></li>
           
                    <li class="dropdown animation" data-animation="fadeInDown" data-animation-delay="1.1s">
            <a data-toggle="dropdown" class="nav-link dropdown-toggle" href="#">Exchange</a>
              <div class="dropdown-menu">
                    <ul class="list_none">
                                   <li><a class="dropdown-item nav-link nav_item" href="<?=base_url('trade/basic')?>">Basic</a></li>
                                   <li><a class="dropdown-item nav-link nav_item" href="<?php echo base_url();?>trade_advance">Advance</a></li>
                            </ul>
                          </div>   
                    </li>

                </ul>



                <ul class="navbar-nav nav_btn align-items-center">
                 
                    <?php
                                if(isset($user_id) && !empty($user_id)){
                                ?>
                    <li class="animation" data-animation="fadeInDown" data-animation-delay="1.4s"><a class="nav-link page-scroll nav_item" href="<?php echo base_url();?>dashboard">Dashboard</a></li>
                    <li class="animation" data-animation="fadeInDown" data-animation-delay="1.5s"><a class="nav-link page-scroll nav_item" href="<?php  echo base_url();?>logout">Logout </a></li>
                    <?php } else { ?>
                    <li class="animation" data-animation="fadeInDown" data-animation-delay="1.6s"><a class="btn btn-default btn-radius nav_item" href="<?php echo base_url();?>signup">Register</a></li>
                     <li class="animation" data-animation="fadeInDown" data-animation-delay="1.7s"><a class="btn btn-default btn-radius nav_item" href="<?php echo base_url();?>login">Login</a></li>
                    <?php } ?>
                </ul>

      </div>
    </nav>
  </div>
</header>


<!-- <header class="<?=($theme_mode=='dark')?'dark':'light'?>-bb">
    <nav class="navbar navbar-expand-lg">
      <a class="navbar-brand" href="<?php echo base_url();?>home"><img src="<?=$Logo?>" alt="logo"></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#headerMenu" aria-controls="headerMenu" aria-expanded="false" aria-label="Toggle navigation">
        <i class="icon ion-md-menu"></i>
      </button>

      <div class="collapse navbar-collapse" id="headerMenu">
        <ul class="navbar-nav mr-auto">
                <li class="dropdown animation" data-animation="fadeInDown" data-animation-delay="1.1s">
            <a  class="nav-link page-scroll nav_item" href="<?=base_url('home')?>">Home</a>
            
                    </li>
                   
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
              Exchange
            </a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="<?=base_url();?>trade">Basic</a>
              <a class="dropdown-item" href="<?php echo base_url();?>trade_advance">Advance</a>
            </div>
          </li>
          <li class="dropdown animation" data-animation="fadeInDown" data-animation-delay="1.1s">
            <a  class="nav-link page-scroll nav_item" href="<?=base_url('market')?>">MARKET</a></li>

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <?php echo $this->lang->line('Dashboard')?>
            </a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="<?php echo base_url();?>profile">Profile</a>
              <a class="dropdown-item" href="<?php echo base_url();?>wallet">Wallet</a>
              <a class="dropdown-item" href="<?php echo base_url();?>settings">Settings</a>
            </div>
          </li>
        </ul>
        <ul class="navbar-nav ml-auto">
        <li class="nav-item header-switch-icon">
                <input type="checkbox" class="switch_checkbox" id="checkbox" <?=($_COOKIE['theme-mode']=='dark')?'checked':''?> onclick="toggleDarkLight()">
              <label for="checkbox" class="switch_labal">
                <i class="fas fa-moon"></i>
                <i class='fas fa-sun'></i>
                <div class='switch_ball'>
              </label>
            </li>
          <li class="nav-item header-custom-icon">
            <a class="nav-link" href="#" id="clickFullscreen">
              <i class="fa fa-expand"></i>
            </a>
          </li>
          <?php if(isset($user_id) && !empty($user_id)){?>
          <li class="nav-item dropdown header-img-icon">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <img src="<?=front_img().'user.png'?>" alt="avatar">
            </a>
            <div class="dropdown-menu">
              <div class="dropdown-header d-flex flex-column align-items-center">
               
                <div class="info text-center">
                  <p class="name font-weight-bold mb-0"><?php echo ucfirst(($users->xabits_username)?$users->xabits_username:'');?></p>
                  <p class="email text-muted mb-3"><?php echo ucfirst(($users->xabits_email)?getUserEmail($users->id):'');?></p>
                </div>
              </div>
              <div class="dropdown-body">
                <ul class="profile-nav">
                  <li class="nav-item">
                    <a href="<?php echo base_url();?>profile" class="nav-link">
                      <i class="icon ion-md-person"></i>
                      <span>Profile</span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="<?php echo base_url();?>wallet" class="nav-link">
                      <i class="icon ion-md-wallet"></i>
                      <span>Balances</span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="<?php echo base_url();?>settings" class="nav-link">
                      <i class="icon ion-md-settings"></i>
                      <span>Settings</span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="<?php echo base_url();?>history" class="nav-link">
                      <i class="icon ion-md-time"></i>
                      <span>History</span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="<?php echo base_url();?>logout" class="nav-link red">
                      <i class="icon ion-md-power"></i>
                      <span>Logout</span>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </li>
          <?php }else{ ?>
            <li class="nav-item">
                    <a href="<?php echo base_url();?>login" class="nav-link">
                      <span>Login</span>
                    </a>
                  </li>
            <?php }?>
        </ul>
      </div>
    </nav>
  </header> -->
    