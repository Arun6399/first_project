<link rel="stylesheet" type="text/css" href="<?php echo front_css();?>style_trade.css" />
<?php $this->load->view('front/user/login_header');?>
<?php
$user_id = $this->session->userdata('user_id');
$all_currency = $this->common_model->getTableData("currency",array("status"=>1))->result();
if(count($all_currency))
{
  $tot_balance = 0;
  foreach($all_currency as $cur)
  {
      $balance = getBalance($user_id,$cur->id);
      $usd_balance = $balance * $cur->online_usdprice;

      $tot_balance += $usd_balance;
  }
}
$theme_mode = $_COOKIE['theme-mode'];
?>
<style>
.active .show {
  color: #007bff;
} 
.markets-chart {
    position: absolute;
    top: 40px;
    width: 100%;
    left: 0;
}
.markets-container {
    position: relative;
    overflow: hidden;
    height: 159px;
    border: 1px solid rgba(0, 0, 0, 0.02);
    box-shadow: 0 2px 16px 0 rgb(0 0 0 / 4%);
    border-radius: 5px;
    margin-bottom: 30px;
}
.mt-5 {
    margin-top: 3rem !important;
}
.markets-pair-list-1 td img {
    width: 18px;
    vertical-align: text-top;
    margin-right: 5px;
}
.markets-content h2 {
    font-size: 14px;
    top: 14px;
    position: absolute;
    left: 15px;
    color: #4a4a4a;
} 
.markets-content span.red {
    background: #ef5350;
    color: #fff!important;
}
.markets-content span.red {
    position: absolute;
    right: 0;
   
    top: 15px;
    padding: 3px 12px;
    border-top-left-radius: 50px;
    border-bottom-left-radius: 50px;
    font-weight: 600;
}
</style>
<div class="markets ptb70">
    <div class="container">
      <div class="row">
       <?php
             $chart_array_data = array();

                  if(isset($chartpairs) && !empty($chartpairs)){
                          foreach($chartpairs as $pair_details ){
                            
                  $from_currency = $this->common_model->getTableData('currency',array('id' => $pair_details->from_symbol_id,'status'=>1))->row();
                  $to_currency = $this->common_model->getTableData('currency',array('id' => $pair_details->to_symbol_id,'status'=>1))->row();
                  $pair_symbol = $from_currency->currency_symbol.'/'.$to_currency->currency_symbol;
                  $pair_url = $from_currency->currency_symbol.'_'.$to_currency->currency_symbol;
                  $chart_array_data[] = array('pair_url'=>$pair_url,'last_price'=>TrimTrailingZeroes($pair_details->lastPrice));
                  $currency = getcryptocurrencydetail($from_currency->id);
                  if(isset($from_currency) && isset($to_currency)){?>
        <input type="hidden" id="mode" value="<?=($theme_mode=='dark')?'Dark':'Light'?>">
        <div class="col-md-4">
          <div class="markets-container">
            <div class="markets-content mt-8">
              <h2><?=$pair_symbol?></h2>
              <p><?php echo TrimTrailingZeroes($pair_details->lastPrice);?></p>
              <span class="<?php echo($pair_details->priceChangePercent>0)?'green':'red';?>"><?php echo number_format($pair_details->priceChangePercent,2);   ?>%</span>
            </div>
            <div class="markets-chart">
            <div id="marketsChart<?=$pair_url?><?=($theme_mode=='dark')?'Dark':'Light'?>"></div>
            </div>
          </div>
        </div>
        <?php  } } } ?>
      <input type="hidden" id="chart_data" value='<?=json_encode($chart_array_data)?>'>
        <div class="col-md-12">
          <div class="markets-pair-list-1">
            <ul class="nav nav-pills" style="width: auto;" id="pills-tab" role="tablist">

             <li class="nav-item" style="width:50px;">
                <a style="color: #4a4a4a" class="nav-link active" data-toggle="pill" href="#ALL" role="tab" aria-selected="false"><i class=""></i> All</a>
              </li>
              <?php if(count($pairs)>0)
              $arr_pair = array();
               { foreach($pairs as $pair_details) {
                $to_currency_det = getcryptocurrencydetail($pair_details->to_symbol_id);
                $to_symbol = strtoupper($to_currency_det->currency_symbol);
                $arr_pair[] =  $to_symbol;
                
                if($to_symbol !="")
                {

                  } }
                  }
                  $unique_symbol_array = array_unique($arr_pair);
                if($unique_symbol_array): foreach($unique_symbol_array as $unique_sym){
          ?>
          <li class="nav-item" style="width:50px;">
              <a style="color: #4a4a4a" href="<?php echo '#'.$unique_sym.'_pair';?>" data-toggle="tab" 
                  class="nav-link "><?php echo $unique_sym;?></a>
          </li>
          <?php } endif; ?>
            </ul>
            <div class="tab-content" style="overflow: auto;">
              <div class="tab-pane fade show active" id="ALL" role="tabpanel">
                <table class="table">
                  <thead>
                    <tr>
                      <th>Pair</th>
                      <th>Coin</th>
                      <th>Last Price</th>
                      <th>Change</th>
                      <th>24H High</th>
                      <th>24H Low</th>
                      <th>24h Volume</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php
                  if(isset($pairs) && !empty($pairs)){
                  foreach($pairs as $pair_details){
                  $from_currency = $this->common_model->getTableData('currency',array('id' => $pair_details->from_symbol_id,'status'=>1))->row();
                  $to_currency = $this->common_model->getTableData('currency',array('id' => $pair_details->to_symbol_id,'status'=>1))->row();
                  $pair_symbol = $from_currency->currency_symbol.'/'.$to_currency->currency_symbol;
                  $pair_url = $from_currency->currency_symbol.'_'.$to_currency->currency_symbol;
                  $currency = getcryptocurrencydetail($from_currency->id);
                  if(isset($from_currency) && isset($to_currency)){
                    ?>  
                    <tr>
                      <td><a href="<?php echo base_url()?>exchange/#/<?=$pair_url?>" style="color: #646464;"><i class=""></i> <?=$pair_symbol?></a></td>
                      <td><img src="<?=$from_currency->image?>" width="50px" alt="coin"><?=$from_currency->currency_symbol?></td>
                      <td><?php echo TrimTrailingZeroes($pair_details->lastPrice);?> </td>
                      <td class="<?php echo($pair_details->priceChangePercent>0)?'green':'red';?>"><?php echo number_format($pair_details->priceChangePercent,2);   ?>%</td>
                      <td><?php echo TrimTrailingZeroes($pair_details->change_high);?></td>
                      <td><?php echo TrimTrailingZeroes($pair_details->change_low);?></td>
                      <td><?php echo TrimTrailingZeroes($pair_details->volume);?></td>
                    </tr>
                    <?php } } }?>
                  </tbody>
                </table>
              </div>
      <?php if(count($pairs)>0) { foreach($pairs as $pair_details) { 
                    $to_cur_det  = getcryptocurrencydetail($pair_details->to_symbol_id);
                    $to_sym = strtoupper($to_cur_det->currency_symbol);
                    $to_id = $to_cur_det->id;

                  ?>
             <div class="tab-pane fade show" id="<?php echo $to_sym.'_pair';?>" role="tabpanel">
                <table class="table">
                  <thead>
                    <tr>
                    <th>Pair</th>
                      <th>Coin</th>
                      <th>Last Price</th>
                      <th>Change</th>
                      <th>24H High</th>
                      <th>24H Low</th>
                      <th>24h Volume</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php                
                     $pairs_from = $this->common_model->customQuery("select * from xabits_trade_pairs where to_symbol_id='".$to_id."' or from_symbol_id='".$to_id."'  and status = 1")->result();
                     $i=1;
                    if(count($pairs_from)>0) { foreach($pairs_from as $pairss) {
                    $pairs_id = $pairss->id;
                    $coin_price = tradeprice($pairs_id);
                    $from_curr_dets = getcryptocurrencydetail($pairss->from_symbol_id);
                    $to_curr_dets = getcryptocurrencydetail($pairss->to_symbol_id);
                    $per_24hrs = pricechangepercent($pairs_id);
                    $page_url = $from_curr_dets->currency_symbol.'_'.$to_curr_dets->currency_symbol;
                    $volumes = volume($pairs_id);
                   ?>

                    <tr>
                      <td><a href="<?php echo base_url()?>exchange"><i class=""></i> <?php echo $from_curr_dets->currency_symbol.'/'.$to_curr_dets->currency_symbol;?></a></td>


                      <td><img src="<?=$from_curr_dets->image?>" alt="coin" width="50px"> 
                      <?=$from_curr_dets->currency_symbol?></td>
                      <td><?php echo TrimTrailingZeroes($pairss->lastPrice);?></td>
                      <td class="<?php echo($pairss->priceChangePercent>0)?'green':'red';?>"><?php echo number_format($pairss->priceChangePercent,2);   ?>%</td>
                      <td><?php echo TrimTrailingZeroes($pairss->change_high);?></td>
                      <td><?php echo TrimTrailingZeroes($pairss->change_low);?></td>
                      <td><?php echo TrimTrailingZeroes($pairss->volume);?></td>
                    </tr>
                    <?php $i++; } } ?>
                  </tbody>
                </table>
              </div>
              <?php } } ?>
            </div>
            <!-- <div class="text-center">
              <a href="#" class="load-more btn">Load More <i class="icon ion-md-arrow-down"></i></a>
            </div> -->
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php 
$lang_id = $this->session->userdata('site_lang');
$title = $lang_id.'_title';
$content = $lang_id.'_content';

$site_common = site_common();
$copy_right = $site_common['site_settings']->copy_right_text;
$from_currency_id = $this->common_model->customQuery("select * from xabits_currency where currency_symbol='".$pair[0]."'")->row('id');
$to_currency_id = $this->common_model->customQuery("select * from xabits_currency where currency_symbol='".$pair[1]."'")->row('id');
if ($this->user_id != 0) {
  $from_cur = to_decimal($this->user_balance[$pair_details->from_symbol_id], 8);
  $to_cur = to_decimal($this->user_balance[$pair_details->to_symbol_id], 8);
} else {
  $from_cur = 0;
  $to_cur = 0;
}
  $url = $this->uri->segment(2);
    $Exp = explode('_', $url);
    $First_Currency = $Exp[0];
    $Second_Currency = $Exp[1];
?>


<?php $this->load->view('front/common/footer');?>



    <script src="<?php echo front_js();?>amcharts-core.min.js"></script>
  <script src="<?php echo front_js();?>amcharts.min.js"></script>
  <script src="<?php echo front_js();?>Chart.bundle.min.js"></script>
   <script src="https://cdn.datatables.net/1.11.1/js/jquery.dataTables.min.js"></script>

  <script src="https://cdn.datatables.net/1.11.1/js/dataTables.bootstrap4.min.js"></script>

<script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>

<script src="https://cdn.datatables.net/responsive/2.2.9/js/responsive.bootstrap4.min.js"></script>
<!--datatables-->
<script type="text/javascript" src="<?php echo front_js();?>datatables.min.js"></script>
<script>
  $('.trade-loader').hide();
        var mode = '<?=($_COOKIE['theme-mode']=='dark-mode')?'dark':'light'?>';
    function toggleDarkLight() {
      document.cookie = "theme-mode=NULL";
       if(document.getElementsByTagName('body')[0].id=='light'){
       document.cookie = "theme-mode=dark";
       // tradingview_chart('chart_library_dark','#181B1F');
      location.reload();
      } 
      else if(document.getElementsByTagName('body')[0].id=='dark'){
        document.cookie = "theme-mode=light";
        // tradingview_chart('chart_library','#FFF');
        location.reload();
}


    }
var chart_data = JSON.parse($('#chart_data').val());
var mode = $('#mode').val();
// console.log(chart_data);
if(chart_data){
  $.each(chart_data, function(key, value) { 
    if(parseInt(value.last_price)>0){
      var color = '#00cc93';
    }else{
      var color = '#ff231f';
    }

  if (document.getElementById('marketsChart'+value.pair_url+mode)) {
          var chartData = [];
          var dynamicChartData = [];
          // current date

          // and generate 500 data items
    fetch(`<?=base_url()?>newtradechart_check/`+value.pair_url)
            .then(res => res.json())
            .then(data => {
              var i = 0;
              var prices = 0;
              var datetime = data['t'];
               var count = datetime.length;
                var value = data['c'];
                var time_data = [];
                 while (i < count) {
                  dynamicChartData.push({
              date: unixTime(datetime[i]),
              prices: value[i],
            });
                i++;
            }
          amdynamicChart(dynamicChartData);
        // return dynamicChartData;
            }) 

function amdynamicChart(object){
      am4core.ready(function () {

        // Create chart
        var chart = am4core.create('marketsChart'+value.pair_url+mode, am4charts.XYChart);
    
        chart.data = object;
        var dateAxis = chart.xAxes.push(new am4charts.DateAxis());
        dateAxis.baseInterval = {
          timeUnit: 'minute',
          count: 1,
        };
        dateAxis.tooltip.disabled = true;
        dateAxis.renderer.grid.template.disabled = true;
        dateAxis.renderer.labels.template.disabled = true;
        dateAxis.renderer.ticks.template.disabled = true;
        dateAxis.renderer.paddingBottom = 15;
  
        var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
        valueAxis.tooltip.disabled = true;
        valueAxis.renderer.grid.template.disabled = true;
        valueAxis.renderer.labels.template.disabled = true;
        valueAxis.renderer.ticks.template.disabled = true;
  
        var series = chart.series.push(new am4charts.LineSeries());
        series.dataFields.dateX = 'date';
        series.dataFields.valueY = 'prices';
        series.tooltipText = 'prices: [bold]{valueY}[/]';
        series.fillOpacity = 0.1;
        series.fill = am4core.color(color);
        series.stroke = am4core.color(color);
        series.tooltip.getFillFromObject = false;
        series.tooltip.background.fill = am4core.color('#2a2e39');
        series.tooltip.background.stroke = am4core.color('#2a2e39');
  
        chart.cursor = new am4charts.XYCursor();
        chart.cursor.lineY.opacity = 1;
        dateAxis.start = 0;
        dateAxis.keepSelection = true;
        chart.zoomOutButton.background.fill = am4core.color(
          'rgba(0, 0, 0, 0.09)'
        );
        chart.zoomOutButton.icon.stroke = am4core.color('rgba(0, 0, 0, 0.40)');
        chart.zoomOutButton.background.states.getKey(
          'hover'
        ).properties.fill = am4core.color('#00cc93');
      });
      }

    }
});
}
function unixTime(unixtime) {

var u = new Date(unixtime*1000);
return u;
};

    </script>
</body>

</html>