  <?php
//require 'webs/vendor/autoload.php';
//require 'webs/includes/config.php';
$user_id = $this->session->userdata('user_id');
$site_common = site_common();
$site_name = $site_common['site_settings']->site_name;
$Logo = $site_common['site_settings']->site_logo;
$DarkLogo = $site_common['site_settings']->site_dark_logo;
$fav_icon = $site_common['site_settings']->site_favicon;
$users = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
$theme_mode = $_COOKIE['theme-mode'];
$trade_pairs = $this->common_model->customQuery("SELECT * FROM xabits_trade_pairs WHERE id='".$pair_id."'")->row();
 $from_currency_det  = getcryptocurrencydetail($trade_pairs->from_symbol_id);
  $to_currency_det  = getcryptocurrencydetail($trade_pairs->to_symbol_id);
?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>xabits</title>

    <!-- Favicons -->
  <link href="<?php echo $fav_icon;?>" rel="icon">
  

    <!--bootstrap-->
    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>bootstrap.min.css" />

    <!--animation-->
    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>animate.min.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>hover-min.css" />

    <!--carousel-->
     <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>owl.carousel.min.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>owl.theme.default.min.css" />

    <!--font-icons-->
    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>fontawesome-all.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>flag-icon.css" />

    <!--datatables-->
    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>datatables.min.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>toastr.min.css" />


    <!--bootstrap-select-->

    <!--sitefonts-->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Rajdhani:300,400,500,600,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i"
        rel="stylesheet">

    <!--styles-->
    <!-- <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>jquery.mCustomScrollbar.css" />  -->
    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>style_trade.css" />
</head>

<body id="<?=($theme_mode=='dark')?'dark':'light'?>">
<div class="trade-loader">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="loader">
                    <div class="loader-inner"></div>
                    <div class="loader-inner"></div>
                    <div class="loader-inner"></div>
                    <div class="loader-inner"></div>
                    <div class="loader-inner"></div>
                    <div class="loader-circle"></div>
                </div>
            </div>
        </div>
    </div>
</div>
<header class="<?=($theme_mode=='dark')?'dark':'light'?>-bb">
    <nav class="navbar navbar-expand-lg">
      <a class="navbar-brand" href="<?php echo base_url();?>home"><img src="<?=($theme_mode=='dark')?$Logo:$DarkLogo?>" alt="logo"></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#headerMenu" aria-controls="headerMenu" aria-expanded="false" aria-label="Toggle navigation">
        <i class="icon ion-md-menu"></i>
      </button>

      <div class="collapse navbar-collapse" id="headerMenu">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <?php echo $this->lang->line('Home')?> 
            </a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="<?=base_url()?>"><?php echo $this->lang->line('Home 1')?></a>
              <a class="dropdown-item" href="<?=base_url('home-two')?>"><?php echo $this->lang->line('Home 2')?></a>
            </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
              <?php echo $this->lang->line('Exchange')?>
            </a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="<?=base_url();?>trade"><?php echo $this->lang->line('Basic')?></a>
              <a class="dropdown-item" href="<?php echo base_url();?>trade_advance"><?php echo $this->lang->line('Advance')?></a>
            </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <?php echo $this->lang->line('Markets')?>
            </a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="<?=base_url();?>market"><?php echo $this->lang->line('Markets')?></a>
              <a class="dropdown-item" href="<?=base_url();?>marketcap"><?php echo $this->lang->line('Markets Capital')?></a>
            </div>
          </li>

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <?php echo $this->lang->line('Dashboard')?>
            </a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="<?php echo base_url();?>profile"><?php echo $this->lang->line('Profile')?></a>
              <a class="dropdown-item" href="<?php echo base_url();?>wallet"><?php echo $this->lang->line('Wallet')?></a>
              <a class="dropdown-item" href="<?php echo base_url();?>settings"><?php echo $this->lang->line('Settings')?></a>
            </div>
          </li>
        </ul>
        <ul class="navbar-nav ml-auto">
        <li class="nav-item header-switch-icon">
                <input type="checkbox" class="switch_checkbox" id="checkbox" <?=($_COOKIE['theme-mode']=='dark')?'checked':''?> onclick="toggleDarkLight()">
              <label for="checkbox" class="switch_labal">
                <i class="fas fa-moon"></i>
                <i class='fas fa-sun'></i>
                <div class='switch_ball'>
              </label>
            </li>
          <li class="nav-item header-custom-icon">
            <a class="nav-link" href="#" id="clickFullscreen">
              <i class="fa fa-expand"></i>
            </a>
          </li>
          <?php if(isset($user_id) && !empty($user_id)){?>
          <li class="nav-item dropdown header-img-icon">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <img src="<?=front_img().'user.png'?>" alt="avatar">
            </a>
            <div class="dropdown-menu">
              <div class="dropdown-header d-flex flex-column align-items-center">
                <!-- <div class="figure mb-3">
                  <img src="<?=front_img().'user.png'?>" alt="">
                </div> -->
                <div class="info text-center">
                  <p class="name font-weight-bold mb-0"><?php echo ucfirst(($users->xabits_username)?$users->xabits_username:'');?></p>
                  <p class="email text-muted mb-3"><?php echo ucfirst(($users->xabits_email)?getUserEmail($users->id):'');?></p>
                </div>
              </div>
              <div class="dropdown-body">
                <ul class="profile-nav">
                  <li class="nav-item">
                    <a href="<?php echo base_url();?>profile" class="nav-link">
                      <i class="icon ion-md-person"></i>
                      <span><?php echo $this->lang->line('Profile')?></span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="<?php echo base_url();?>wallet" class="nav-link">
                      <i class="icon ion-md-wallet"></i>
                      <span><?php echo $this->lang->line('Balances')?></span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="<?php echo base_url();?>settings" class="nav-link">
                      <i class="icon ion-md-settings"></i>
                      <span><?php echo $this->lang->line('Settings')?></span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="<?php echo base_url();?>history" class="nav-link">
                      <i class="icon ion-md-time"></i>
                      <span><?php echo $this->lang->line('History')?></span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="<?php echo base_url();?>logout" class="nav-link red">
                      <i class="icon ion-md-power"></i>
                      <span><?php echo $this->lang->line('Logout')?></span>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </li>
          <?php }else{ ?>
            <li class="nav-item">
                    <a href="<?php echo base_url();?>login" class="nav-link">
                      <span><?php echo $this->lang->line('Login')?></span>
                    </a>
                  </li>
            <?php }?>
        </ul>
      </div>
    </nav>
  </header>
    