
<div id="content" class="content">
	<?php 
		$error = $this->session->flashdata('error');
		if($error != '') {
			echo '<div class="alert alert-danger">
			<button aria-hidden="true" data-dismiss="alert" class="close" type="button">&#10005;</button>'.$error.'</div>';
		}
		$success = $this->session->flashdata('success');
		if($success != '') {
			echo '<div class="alert alert-success">
			<button aria-hidden="true" data-dismiss="alert" class="close" type="button">&#10005;</button>'.$success.'</div>';
		} 
	?>
	
	<ol class="breadcrumb pull-right">
		<li><a href="<?php echo admin_url();?>">Home</a></li>
		<li class="active">User Bank Details</li>
	</ol>
	
	<h1 class="page-header">Add User Bank Details</h1>
	<p class="text-right m-b-10"></p>
	
	<div class="row">
		<div class="col-md-12">
	      
            <div class="panel panel-inverse">
                <div class="panel-heading">
                    <div class="panel-heading-btn">
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-danger" data-click="panel-remove"><i class="fa fa-times"></i></a>
                    </div>
                    <h4 class="panel-title">edit User Details</h4>
                </div>
				
						<div class="panel-body">
							<?php 
								$attributes=array('class'=>'form-horizontal','id'=>'edit_user');
								echo form_open_multipart($action,$attributes); 

								// print_r($bank);
							?>
                        		<fieldset>
                          			<div class="form-group">
		                                <label class="col-md-4 control-label">User email</label>
		                                <div class="col-md-4">
					 						<input type="text" readonly name="bank_account_number" id="bank_account_number" class="form-control" placeholder="Bank Account Number" value="<?php echo $usermail = getUserEmail($bank->id);?>" />
					 				

                                		</div>
                            		</div>


									  <div class="form-group">
                                        <label class="col-md-4 control-label">First Name</label>
                                        <div class="col-md-4">
										<input type="text" name="xabits_fname" id="xabits_fname" class="form-control" placeholder="First Name" value="<?php echo $bank->xabits_fname; ?>" />
                                        </div>
                                    </div>
							
									<div class="form-group">
                                        <label class="col-md-4 control-label">Last Name</label>
                                        <div class="col-md-4">
										<input type="text" name="xabits_lname" id="xabits_lname" class="form-control" placeholder="Last Name" value="<?php echo $bank->xabits_lname; ?>" />
                                        </div>
                                    </div>
								<div class="form-group">
                                        <label class="col-md-4 control-label">Addess</label>
                                        <div class="col-md-4">
										<input type="text" name="street_address" id="street_address" class="form-control" placeholder="Addess" value="<?php echo $bank->street_address; ?>" />
                                        </div>
                                    </div>
		                          	<div class="form-group">
                                        <label class="col-md-4 control-label">City</label>
                                        <div class="col-md-4">
										<input type="text" name="city" id="city" class="form-control" placeholder="city" value="<?php echo $bank->city; ?>" />
                                        </div>
                                    </div>
		                           <!--  <div class="form-group">
                                        <label class="col-md-4 control-label">Phone Number</label>
                                        <div class="col-md-4">
										<input type="text" name="bank_address" id="bank_address" class="form-control" placeholder="Bank Address" value="<?php echo $bank->bank_address; ?>" />
                                        </div>
                                    </div> -->
		                            <div class="form-group">
                                        <label class="col-md-4 control-label">Postal Code</label>
                                        <div class="col-md-4">
										<input type="text" name="postal_code" id="postal_code" class="form-control" placeholder="Postal Code" value="<?php echo $bank->postal_code; ?>" />
                                        </div>
                                    </div>
                                    
                                    <!-- <div class="form-group">
		                                <label class="col-md-4 control-label">Country</label>
		                                <div class="col-md-4 control-label text-left">
		                             <select class="form-control" name="country" id="country">
                                                     <option>Select Country</option>
                                        <?php if($countries) {
                                            foreach($countries as $co) {
                                              ?>
                                              <option <?php if($co->id==$bank->bank_country) { echo "selected"; } ?>
                                              value ="<?php echo $co->id; ?>"><?php echo $co->country_name; ?></option>
                                              <?php
                                            }
                                          } ?>
                                    </select>
		                                </div>
                        			</div> -->
			                        
			                    
			                        <div class="form-group">
                                        <div class="col-md-8 col-md-offset-4">
                                            <button type="submit" class="btn btn-sm btn-primary m-r-5">Submit</button>
                                        </div>
                                    </div>
                        		</fieldset>
                    		<?php echo form_close(); ?>
                		</div>
			
            </div>
          
        </div>
	</div>

 
</div>
<!-- end #content -->
<!-- ================== BEGIN BASE JS ================== -->
<script src="<?php echo admin_source();?>/plugins/jquery/jquery-1.9.1.min.js"></script>
<script src="<?php echo admin_source();?>/plugins/jquery/jquery-migrate-1.1.0.min.js"></script>
<script src="<?php echo admin_source();?>/plugins/jquery-ui/ui/minified/jquery-ui.min.js"></script>
<script src="<?php echo admin_source();?>/plugins/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo admin_source();?>/plugins/ckeditor/ckeditor.js"></script>

<script src="<?php echo admin_source();?>/plugins/slimscroll/jquery.slimscroll.min.js"></script>
<script src="<?php echo admin_source();?>/plugins/jquery-cookie/jquery.cookie.js"></script>
<!-- ================== END BASE JS ================== -->
<!-- ================== BEGIN PAGE LEVEL JS ================== -->
<script src="<?php echo admin_source();?>/plugins/gritter/js/jquery.gritter.js"></script>
<script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.min.js"></script>
<script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.time.min.js"></script>
<script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.resize.min.js"></script>
<script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script> 
    <script src="https://cdn.datatables.net/responsive/2.2.6/js/dataTables.responsive.min.js"></script>
<script src="<?php echo admin_source();?>/js/jquery.validate.min.js"></script>
<script src="<?php echo admin_source();?>/js/apps.min.js"></script>
<!-- ================== END PAGE LEVEL JS ================== -->
<script type="text/javascript">
	$(document).ready(function() {
		App.init();
	});
</script>
<script type="text/javascript">
	$(document).ready(function() 
	{
		$('#cms').validate({
			rules: {
				bank_account_number: {
					required: true
				},
				bank_swift: {
					required: true
				},
				bank_account_name: {
					required: true,
				},
				bank_name: {
					required: true
				},
				bank_city: {
					required: true,
				},
				bank_country: {
					required: true,
				},
				bank_postalcode: {
					required: true,
				},
				bank_address: {
					required: true,
				},
				currency: {
					required: true,
				}
			},
			highlight: function (element) {
				//$(element).parent().addClass('error')
			},
			unhighlight: function (element) {
				$(element).parent().removeClass('error')
			}
		});
	});
</script> 
 <script async
src="https://www.googletagmanager.com/gtag/js?id=G-FDX8TJF8SG"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', 'G-FDX8TJF8SG');
</script>
<script type="text/javascript">
  
    var admin_url='<?php echo admin_url(); ?>';
		
$(document).ready(function() {
    $('#datas-table').DataTable( {
    	responsive : true,
        "processing" : true,
        "pageLength" : 10,
        "serverSide": true,
        "order": [[0, "asc" ]],
        "searching": true,
        "ajax": admin_url+"admin/userbank_ajax"
    });
        });
      
</script>