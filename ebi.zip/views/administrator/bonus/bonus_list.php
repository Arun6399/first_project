<div class="panel-body">
    <div class="table-responsive">
        <table id="datas-table" class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th class="text-center">S.No</th>
                    <th class="text-center">Username</th>
                    <th class="text-center">User Email</th>                    
                    <th class="text-center">Signup Bonus</th>
                    <th class="text-center">Used Bonus</th>                    
                    <th class="text-center">Referral</th>
                </tr>
            </thead>
            <tbody>               
            </tbody>
        </table>
    </div>
</div>