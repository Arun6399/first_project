#!/usr/bin/env python3
import time
import json
import base64
import hashlib
import hmac
import requests
import sys
import json


def gen_sig_helper(secret, data):
  secret_bytes = base64.b64decode(secret.encode('utf8'))
  return base64.b64encode(hmac.new(secret_bytes, data.encode('utf8'), digestmod = hashlib.sha512).digest()).decode('utf8')

def v3_gen_sig(secret, path, body_str = None):
  data = path
  if body_str != None:
    data = data + chr(0) + body_str
  return gen_sig_helper(secret, data)

def v3_mk_request(method, path, body = {}):
  tonce = int(time.time() * 1000 * 1000)
  body['tonce'] = tonce
  body_str = json.dumps(body)
  headers = {
    'Rest-Key': key,
    'Rest-Sign': v3_gen_sig(secret, path, body_str),
    'Content-Type': 'application/json'
  }
  response = requests.request(method, base_url + '/' + path, headers = headers, data = body_str)
  response_json = response.json()
  #pprint.pprint(response_json)
  response.raise_for_status()
  return response_json


base_url = 'https://trade-sg.oslsandbox.com'
key = 'ce785f66-3b73-4e7d-8ab3-10bc1d0c5817'
secret = 'Q2Ah0IFy9BYUibMzyQWA9D9umycrvqj7MqVIWzS6STra4mYW5cI3Byn5uYIidDJ03mUe1l7ULUqBcifwbJUQAw=='
ccy=sys.argv[1]
address = sys.argv[2]
amount = sys.argv[3]
send_v3 = v3_mk_request('POST', 'api/3/send', {'ccy':ccy,'address' : address,'amount': amount})
stud_obj = json.dumps(send_v3)
print(stud_obj)

