#!/usr/local/bin/python3
import sys
input1=sys.argv[1]
input2=sys.argv[2]
print (input1)
print (input2)