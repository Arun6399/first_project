import time
import json
import base64
import hashlib
import hmac
import requests
import pprint
import pandas as pd
import time

def gen_sig_helper(secret, data):
  secret_bytes = base64.b64decode(secret.encode('utf8'))
  return base64.b64encode(hmac.new(secret_bytes, data.encode('utf8'), digestmod = hashlib.sha512).digest()).decode('utf8')

def v4_gen_sig(secret, method, path, expires, body_str = None):
    data = method + path + str(expires)
    if body_str != None:
        data = data + body_str
    print(data)
    return gen_sig_helper(secret, data)

def v4_mk_request(key,secret,base_url,method, path, body = None):
  print('=> ' + method + ' ' + path)
  tonce = int(time.time()) + 10
  body_str = None
  if body:
    body_str = json.dumps(body)
  headers = {
    'api-key': key,
    'api-signature': v4_gen_sig(secret, method, path, tonce, body_str),
    'api-expires': str(tonce),
  }

  if body:
    headers['Content-Type'] = 'application/json'

  response = requests.request(method, base_url + path, headers = headers, data = body_str)
  print(response)
  print(response.headers)
  
  try:
    response_json = response.json()
    pprint.pprint(response_json)
    response.raise_for_status()
    return response_json

  except:
    print("")


#PROD AM env.
base_url = 'https://trade-am.oslsandbox.com'
key = 'f6f12321-87f9-4e16-ad42-fce117b4f699'
secret = 'jj+waNe7CS/pQzCXKfoQrPU0rjFyzMwcWXdU+kp4upzZiOJQAupWmvN1Dw9WCZ+H+Lz0LK6iE1MGwnJ0Lb8qhA=='


print(f'API Key: {key}')  
print(f'API Secret: {secret}')  
get_instrument = v4_mk_request(key,secret,base_url,'GET', '/api/v4/orderBook/L2?symbol=BTCUSD',{})


# print(get_instrument)



