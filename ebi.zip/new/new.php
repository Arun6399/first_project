<!-- <?php
$command = escapeshellcmd('python /var/www/html/new/restv3.py');
$output = shell_exec($command);
echo $output;
?>
 -->
<!--  <?php 					
	
	$ccy = "BTC";
	$address = "2MySAcsscZJwRuPGGaQMATcMkBW6aaPcoKP";
	$amount = "1";
	$arg = escapeshellarg( '/var/www/html/new/vij.py '.$ccy);
$exit = '2>&1';
$cmd = '/usr/bin/python3 '.$arg.' '.$exit;
echo  shell_exec( $cmd );


?>  -->
 <?php
	$ccy = "BTC";
	$address = '2MySAcsscZJwRuPGGaQMATcMkBW6aaPcoKP';
	$amount = 1;
$command = escapeshellcmd("/var/www/html/new/restv3.py $ccy $address $amount");
$exit = '2>&1';
$cmd = '/usr/bin/python3 '.$command.' '.$exit;
echo  shell_exec( $cmd );
?> 